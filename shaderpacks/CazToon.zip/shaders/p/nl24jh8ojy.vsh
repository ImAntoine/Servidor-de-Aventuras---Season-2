
#include "/settings.glsl"
#include "/include/hovering.glsl"
#include "/include/shadow.glsl"
#include "/include/water_waves.glsl"

const float ambientOcclusionLevel = 0.0;

uniform mat4 gbufferModelView;
uniform mat4 gbufferModelViewInverse;
uniform mat4 shadowModelView;
uniform mat4 shadowProjection;
uniform vec3 cameraPosition;
uniform float sunAngle;
uniform float frameTimeCounter;
uniform int frameCounter;

out vec2 texcoord;
out vec4 glcolor;
out float viewDistance;
out float postMask;
out float isWater;
out float isHologram;
out vec3 worldPos;
out vec3 viewPos;
out vec3 normal;
out float skylight;
out float blocklight;
out vec3 waveNormal; // Pass wave normal to fragment shader
out vec4 shadowPos;
flat out float isIce;  // 1.0 = ice block (for SSR)
flat out float isHeatSource;
#ifdef PBR_ENABLED
out vec3 tangentVec;
out vec3 binormalVec;
#endif

attribute vec4 mc_Entity;
#ifdef PBR_ENABLED
attribute vec4 at_tangent;
#endif

void main() {
	texcoord = (gl_TextureMatrix[0] * gl_MultiTexCoord0).xy;
	glcolor = gl_Color;
	
	viewPos = (gl_ModelViewMatrix * gl_Vertex).xyz;
	vec3 scenePos = (gbufferModelViewInverse * vec4(viewPos, 1.0)).xyz;
	vec3 world_pos = scenePos + cameraPosition;
	
	// Check if this is water early for wave application
	int block_id_raw = int(mc_Entity.x);
	bool has_block_properties_id = (block_id_raw >= 10000);
	int block_id = has_block_properties_id ? (block_id_raw - 10000) : 0;
	bool water = (has_block_properties_id && block_id == 1);
	
	// Apply water waves
	#ifdef WATER_WAVES_ENABLED
	waveNormal = vec3(0.0, 1.0, 0.0); // Default up
	if (water) {
		float waveHeight = waterGetWaveHeight(world_pos.xz, frameTimeCounter);
		world_pos.y += waveHeight;
		vec3 wNormal = waterCalcWaveNormal(world_pos.xz, frameTimeCounter);
		// Transform world-space normal to view-space
		waveNormal = normalize(mat3(gbufferModelView) * wNormal);
	}
	#else
	waveNormal = vec3(0.0, 1.0, 0.0);
	#endif
	
	// Apply hovering zone offset - ALWAYS apply transform for consistency
	float hoverOffset = getHoverOffset(world_pos);
	world_pos.y += hoverOffset;
	scenePos = world_pos - cameraPosition;
	viewPos = (gbufferModelView * vec4(scenePos, 1.0)).xyz;
	gl_Position = gl_ProjectionMatrix * vec4(viewPos, 1.0);
	
	worldPos = world_pos;
	viewDistance = length(viewPos);
	
	normal = normalize(gl_NormalMatrix * gl_Normal);
	#ifdef PBR_ENABLED
	tangentVec = normalize(gl_NormalMatrix * at_tangent.xyz);
	binormalVec = normalize(cross(normal, tangentVec) * at_tangent.w);
	#endif

	// Block ID 1 = water, 8 = ice, 14 = slime/honey
	isWater = water ? 1.0 : 0.0;
	bool iceBlock = (has_block_properties_id && block_id == 8);
	isIce = iceBlock ? 1.0 : 0.0;
	bool isSlime = (has_block_properties_id && block_id == 14);
	postMask = (isWater > 0.5) ? 0.0 : 1.0;
	// Everything that's not water/ice/slime in gbuffers_water is glass/translucent
	isHologram = (isWater < 0.5 && !iceBlock && !isSlime) ? 1.0 : 0.0;
	bool isHeat = (block_id == 20 || block_id == 21 || block_id == 22 || block_id == 36 || block_id == 39 || block_id == 40);
	isHeatSource = (has_block_properties_id && isHeat) ? 1.0 : 0.0;
	
	// Lightmap from both channels
	vec2 lmcoord = (gl_TextureMatrix[1] * gl_MultiTexCoord1).xy;
	blocklight = clamp(lmcoord.x, 0.0, 1.0);
	skylight = clamp(lmcoord.y, 0.0, 1.0);

	// Shadow position for cast shadows
	shadowPos = vec4(0.0);
	#ifdef SHADOWS_ENABLED
	vec4 shadowClipPos4 = shadowProjection * shadowModelView * vec4(scenePos, 1.0);
	vec3 shadowClipPosXYZ = shadowClipPos4.xyz;
	float bias = computeBias(shadowClipPosXYZ);
	vec3 distorted = distortShadowClipPos(shadowClipPosXYZ);
	shadowPos.xyz = distorted * 0.5 + 0.5;
	// Normal bias to reduce shadow acne
	vec4 shadowNormalVec = shadowProjection * vec4(mat3(shadowModelView) * (mat3(gbufferModelViewInverse) * normal), 1.0);
	shadowPos.xyz += shadowNormalVec.xyz / shadowNormalVec.w * bias;
	shadowPos.w = 1.0; // Mark as valid
	#endif
}
