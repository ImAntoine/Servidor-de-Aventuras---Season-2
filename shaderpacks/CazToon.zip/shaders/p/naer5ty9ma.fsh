/* RENDERTARGETS: 0,1,3 */

#include "/settings.glsl"
#include "/include/biome_overrides.glsl"
#include "/include/hovering.glsl"

uniform sampler2D gtexture;
uniform float alphaTestRef;
uniform float sunAngle;
uniform vec3 fogColor;
uniform int biome_category;
uniform float fogStart;
uniform float fogEnd;
uniform int isEyeInWater;
uniform float frameTimeCounter;
uniform vec3 cameraPosition;

#include "/include/lighting.glsl"

in vec2 texcoord;
in vec4 glcolor;
in vec3 worldPos;
in vec3 normal;
in float isHologram;
in float skylight;
in float blocklight;
in float viewDistance;

// Get view-independent fog color based on time of day
vec3 getTimeBasedFogColor() {
    float angle = fract(sunAngle);
    float isDay = smoothstep(0.02, 0.08, angle) * smoothstep(0.48, 0.42, angle);
    float twilight = smoothstep(0.40, 0.46, angle) * smoothstep(0.58, 0.52, angle)
                   + smoothstep(0.94, 1.0, angle) + smoothstep(0.06, 0.0, angle);
    float blueHour = smoothstep(0.50, 0.56, angle) * smoothstep(0.66, 0.60, angle);
    float isNight = smoothstep(0.58, 0.64, angle) * smoothstep(0.98, 0.92, angle);
    float totalWeight = max(isDay + twilight + blueHour + isNight, 0.001);
    isDay /= totalWeight; twilight /= totalWeight; blueHour /= totalWeight; isNight /= totalWeight;
    if (isForcedNetherBiome(biome)) {
        return getForcedBiomeFogColorCat(biome, biome_category, fogColor);
    }    float biomeDayGate = smoothstep(0.18, 0.78, isDay + twilight * 0.30);
    float biomeBlendStrength = SKY_BIOME_BLEND * biomeDayGate;
    float biomeTintDay = biomeBlendStrength;
    float biomeTintTwilight = biomeBlendStrength * 0.55;
    float biomeTintBlueHour = biomeBlendStrength * 0.40;
    float biomeTintNight = biomeBlendStrength * 0.20;
    vec3 biomeFogOverride = getForcedBiomeFogColorCat(biome, biome_category, fogColor);
    vec3 dayFog = mix(vec3(DAY_HORIZON_R, DAY_HORIZON_G, DAY_HORIZON_B), biomeFogOverride, biomeTintDay) * DAY_BRIGHTNESS;
    vec3 sunsetFog = mix(vec3(SUNSET_HORIZON_R, SUNSET_HORIZON_G, SUNSET_HORIZON_B), biomeFogOverride, biomeTintTwilight) * SUNSET_BRIGHTNESS;
    vec3 blueFog = mix(vec3(BLUEHOUR_HORIZON_R, BLUEHOUR_HORIZON_G, BLUEHOUR_HORIZON_B), biomeFogOverride, biomeTintBlueHour) * BLUEHOUR_BRIGHTNESS;
    vec3 nightFog = mix(vec3(NIGHT_HORIZON_R, NIGHT_HORIZON_G, NIGHT_HORIZON_B), biomeFogOverride, biomeTintNight) * NIGHT_BRIGHTNESS;
    return dayFog * isDay + sunsetFog * twilight + blueFog * blueHour + nightFog * isNight;
}

float random(float x) {
	return fract(sin(x * 12.9898) * 43758.5453);
}

void main() {
	vec4 color = texture(gtexture, texcoord) * glcolor;
	
	// Texture palette limiting
	#ifdef TEXTURE_PALETTE_ENABLED
	{
		float levels = float(TEXTURE_PALETTE_LEVELS);
		color.rgb = floor(color.rgb * levels) / levels;
	}
	#endif
	
	if (color.a < alphaTestRef) {
		discard;
	}

	vec3 rawColor = color.rgb;
	float emissive = 0.0;

	// Apply lighting (time of day + lightmap)
	color.rgb = applyLightingEmissive(color.rgb, sunAngle, skylight, blocklight, emissive);
	#ifdef HANDHELD_LIGHT_ENABLED
	if (emissive < 0.5) color.rgb += getHandheldLightBoost(worldPos, rawColor, color.rgb);
	#endif
	color.rgb *= TERRAIN_BRIGHTNESS;

	// Apply sky fog (but not to emissive and not underwater)
	if (emissive < 0.5 && isEyeInWater != 1) {
		float denom = max(fogEnd - fogStart, 0.0001);
		float fogFactor = clamp((fogEnd - viewDistance) / denom, 0.0, 1.0);
		color.rgb = mix(getTimeBasedFogColor(), color.rgb, fogFactor);
	}

	gl_FragData[0] = color;
	gl_FragData[1] = vec4(1.0, emissive, skylight, 0.0);

	// Output colored light for bloom
	vec3 lightColor = vec3(0.0);
	if (emissive > 0.5) {
		lightColor = color.rgb * EMISSIVE_BRIGHTNESS;
	}
	gl_FragData[2] = vec4(lightColor, 1.0);
}




