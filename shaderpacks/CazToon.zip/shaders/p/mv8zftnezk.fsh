/* RENDERTARGETS: 0,1,2,3,5 */

#include "/settings.glsl"
#include "/include/biome_overrides.glsl"
#include "/include/shadow.glsl"
#include "/include/hovering.glsl"

uniform sampler2D gtexture;
uniform sampler2D shadowtex0;
#ifdef PBR_ENABLED
uniform sampler2D normals;   // Normal map from PBR resource pack (_n textures)
uniform sampler2D specular;  // Specular map from PBR resource pack (_s textures)
#endif
uniform float alphaTestRef;
uniform vec3 fogColor;
uniform int biome_category;
uniform float fogStart;
uniform float fogEnd;
uniform float far;
uniform float sunAngle;
uniform vec3 shadowLightPosition;
uniform mat4 shadowModelView;
uniform mat4 shadowProjection;
uniform mat4 gbufferModelViewInverse;
uniform vec3 cameraPosition;
uniform int currentRenderedItemId;

#include "/include/lighting.glsl"
uniform float frameTimeCounter;
#if defined(END_SHADER) && defined(END_EVENT_ENABLED)
#include "/include/end_event.glsl"
#endif
uniform int frameCounter;
uniform int isEyeInWater;

in vec2 texcoord;
in vec4 glcolor;
in float viewDistance;
in float outlineMask;
in float skylight;
in float blocklight;
flat in float emissive;
flat in float emissiveType;
in vec3 worldPos;
in vec4 shadowPos;  // xyz = shadow screen pos (already biased), w = lightDot
flat in float isGrassGeometry;  // Flat to prevent interpolation artifacts
flat in float isHeatSource;
flat in float isHologram;
flat in float metalness;  // 0 = non-metal, 1 = metal, 2 = gem
flat in float reflective; // 1.0 = reflective material (SSR)
in vec3 normal;
flat in vec3 geoNormal;  // Flat geometric normal for shadow bias
flat in float blockId;    // Block ID for connected texture detection
in float leafAO;           // Reserved for future use
#ifdef PBR_ENABLED
in vec3 tangentVec;        // Tangent vector for TBN matrix (view space)
in vec3 binormalVec;       // Binormal/bitangent vector for TBN matrix (view space)
#endif

// Get view-independent fog color based on time of day
// Uses biome fog color during stable daytime, fixed colors during transitions
vec3 getTimeBasedFogColor() {
    float angle = fract(sunAngle);
    
    float isDay = smoothstep(0.02, 0.08, angle) * smoothstep(0.48, 0.42, angle);
    float twilight = smoothstep(0.40, 0.46, angle) * smoothstep(0.58, 0.52, angle)
                   + smoothstep(0.94, 1.0, angle) + smoothstep(0.06, 0.0, angle);
    float blueHour = smoothstep(0.50, 0.56, angle) * smoothstep(0.66, 0.60, angle);
    float isNight = smoothstep(0.58, 0.64, angle) * smoothstep(0.98, 0.92, angle);
    
    float totalWeight = max(isDay + twilight + blueHour + isNight, 0.001);
    isDay /= totalWeight;
    twilight /= totalWeight;
    blueHour /= totalWeight;
    isNight /= totalWeight;

    if (isForcedNetherBiome(biome)) {
        return getForcedBiomeFogColorCat(biome, biome_category, fogColor);
    }    // Biome tint strength across phases (strongest at daytime).
    float biomeDayGate = smoothstep(0.18, 0.78, isDay + twilight * 0.30);
    float biomeBlendStrength = SKY_BIOME_BLEND * biomeDayGate;
    float biomeTintDay = biomeBlendStrength;
    float biomeTintTwilight = biomeBlendStrength * 0.55;
    float biomeTintBlueHour = biomeBlendStrength * 0.40;
    float biomeTintNight = biomeBlendStrength * 0.20;

    vec3 biomeFogOverride = getForcedBiomeFogColorCat(biome, biome_category, fogColor);
    vec3 dayFog = mix(vec3(DAY_HORIZON_R, DAY_HORIZON_G, DAY_HORIZON_B), biomeFogOverride, biomeTintDay) * DAY_BRIGHTNESS;
    vec3 sunsetFog = mix(vec3(SUNSET_HORIZON_R, SUNSET_HORIZON_G, SUNSET_HORIZON_B), biomeFogOverride, biomeTintTwilight) * SUNSET_BRIGHTNESS;
    vec3 blueFog = mix(vec3(BLUEHOUR_HORIZON_R, BLUEHOUR_HORIZON_G, BLUEHOUR_HORIZON_B), biomeFogOverride, biomeTintBlueHour) * BLUEHOUR_BRIGHTNESS;
    vec3 nightFog = mix(vec3(NIGHT_HORIZON_R, NIGHT_HORIZON_G, NIGHT_HORIZON_B), biomeFogOverride, biomeTintNight) * NIGHT_BRIGHTNESS;
    
    return dayFog * isDay + sunsetFog * twilight + blueFog * blueHour + nightFog * isNight;
}

vec3 getEmissiveLightColor(float type) {
    int t = int(type + 0.5);
    // Original emissive IDs (10020-10031, type 0-11)
    if (t == 0)  return vec3(1.0, 0.7, 0.4);   // Torch, lantern, campfire
    if (t == 1)  return vec3(0.3, 0.8, 1.0);   // Soul torch, soul campfire
    if (t == 2)  return vec3(1.0, 0.4, 0.1);   // Lava, fire
    if (t == 3)  return vec3(1.0, 0.85, 0.5);  // Glowstone
    if (t == 4)  return vec3(0.6, 0.9, 1.0);   // Sea lantern
    if (t == 5)  return vec3(1.0, 0.6, 0.3);   // Shroomlight
    if (t == 6)  return vec3(1.0, 0.2, 0.1);   // Redstone torch
    if (t == 7)  return vec3(1.0, 0.85, 0.3);  // Ochre froglight
    if (t == 8)  return vec3(0.5, 1.0, 0.4);   // Verdant froglight
    if (t == 9)  return vec3(1.0, 0.6, 0.9);   // Pearlescent froglight
    if (t == 10) return vec3(1.0, 1.0, 1.0);   // Light block (white)
    if (t == 11) return vec3(1.0, 1.0, 1.0);   // End rod (white)
    
    // LPV emissive IDs (10032-10063, type 12-43)
    if (t == 12) return vec3(0.6, 0.9, 1.0);   // Sea lantern (strong white-blue)
    if (t == 13) return vec3(1.0, 1.0, 1.0);   // End rod (medium white)
    if (t == 14) return vec3(0.8, 1.0, 0.9);   // Glow lichen (weak white-green)
    if (t == 15) return vec3(1.0, 0.85, 0.5);  // Glowstone, lantern (strong golden)
    if (t == 16) return vec3(1.0, 0.7, 0.4);   // Torch, campfire (medium golden)
    if (t == 17) return vec3(1.0, 0.7, 0.4);   // Cave vines (weak golden)
    if (t == 18) return vec3(1.0, 0.2, 0.1);   // Redstone components
    if (t == 19) return vec3(1.0, 0.45, 0.1);  // Lava
    if (t == 20) return vec3(1.0, 0.5, 0.15);  // Fire, magma, shroomlight
    if (t == 21) return vec3(1.0, 0.75, 0.2);  // Brewing stand
    if (t == 22) return vec3(1.0, 0.7, 0.4);   // Jack o' Lantern
    if (t == 23) return vec3(0.45, 0.73, 1.0); // Soul lights
    if (t == 24) return vec3(0.45, 0.73, 1.0); // Beacon
    if (t == 25) return vec3(0.75, 1.0, 0.83); // End portal frame
    if (t == 26) return vec3(0.3, 0.9, 0.7);   // Sculk
    if (t == 27) return vec3(0.8, 0.3, 1.0);   // Crying obsidian, spawner
    if (t == 28) return vec3(0.75, 1.0, 0.5);  // Sea pickle
    if (t == 29) return vec3(1.0, 0.5, 0.25);  // Nether plants
    if (t == 30) return vec3(1.0, 0.7, 0.4);   // Candles
    if (t == 31) return vec3(1.0, 0.75, 0.35); // Ochre froglight
    if (t == 32) return vec3(0.7, 1.0, 0.4);   // Verdant froglight
    if (t == 33) return vec3(0.85, 0.5, 1.0);  // Pearlescent froglight
    if (t == 34) return vec3(0.6, 0.1, 1.0);   // Enchanting table
    if (t == 35) return vec3(0.75, 0.44, 1.0); // Amethyst cluster
    if (t == 36) return vec3(0.3, 0.9, 0.7);   // Calibrated sculk sensor
    if (t == 37) return vec3(0.3, 0.9, 0.7);   // Active sculk sensor
    if (t == 38) return vec3(1.0, 0.2, 0.1);   // Redstone block
    if (t == 39) return vec3(1.0, 0.5, 0.25);  // Open eyeblossom
    if (t == 42) return vec3(0.6, 0.1, 1.0);   // Nether portal
    if (t == 43) return vec3(0.2, 0.8, 0.6);   // End portal
    
    return vec3(1.0, 0.7, 0.4); // Default warm light
}

// ============================================================================
// Cloud Shadow Sampling
// ============================================================================
#if defined(CLOUDS_2D_ENABLED) && defined(CLOUD_SHADOWS_ENABLED)
float cloudShadowHash(vec2 p) {
    vec3 p3 = fract(vec3(p.xyx) * 0.1031);
    p3 += dot(p3, p3.yzx + 33.33);
    return fract((p3.x + p3.y) * p3.z);
}

float cloudShadowNoise(vec2 p) {
    vec2 i = floor(p);
    vec2 f = fract(p);
    f = f * f * (3.0 - 2.0 * f);
    
    float a = cloudShadowHash(i);
    float b = cloudShadowHash(i + vec2(1.0, 0.0));
    float c = cloudShadowHash(i + vec2(0.0, 1.0));
    float d = cloudShadowHash(i + vec2(1.0, 1.0));
    
    return mix(mix(a, b, f.x), mix(c, d, f.x), f.y);
}

float cloudShadowFBM(vec2 p) {
    float value = 0.0;
    float amplitude = 0.5;
    float frequency = 1.0;
    
    for (int i = 0; i < 5; i++) {
        value += amplitude * cloudShadowNoise(p * frequency);
        amplitude *= 0.5;
        frequency *= 2.0;
    }
    
    return value;
}

float getCloudShadow(vec3 wPos, float time) {
    // Circular wind: Clouds move in a large circle
    float r = 2500.0;
    float speed = CLOUD_SPEED * 3.0;
    float angle = time * speed / r;
    vec2 offset = vec2(cos(angle), sin(angle)) * r;
    
    vec2 cloudPos = (wPos.xz + offset) * CLOUD_SCALE;
    
    float noise = cloudShadowFBM(cloudPos);
    float density = smoothstep(1.0 - CLOUD_COVERAGE, 1.0 - CLOUD_COVERAGE + 0.3, noise);
    
    #if CLOUD_TOON_EDGES == 1
    density = step(0.3, density);
    #endif
    
    return 1.0 - density * CLOUD_SHADOW_STRENGTH;
}
#endif

float random(float x) {
    return fract(sin(x * 12.9898) * 43758.5453);
}

float hash12(vec2 p) {
    return fract(sin(dot(p, vec2(127.1, 311.7))) * 43758.5453);
}

float smoothChunkNoise(vec2 p) {
    vec2 i = floor(p);
    vec2 f = fract(p);
    f = f * f * (3.0 - 2.0 * f);
    float a = hash12(i);
    float b = hash12(i + vec2(1.0, 0.0));
    float c = hash12(i + vec2(0.0, 1.0));
    float d = hash12(i + vec2(1.0, 1.0));
    return mix(mix(a, b, f.x), mix(c, d, f.x), f.y);
}

#ifdef METALNESS_ENABLED
// Fake environment color based on viewing angle and time of day
vec3 getEnvironmentColor(vec3 reflectDir, float sunAngle) {
    float angle = fract(sunAngle);
    
    // Time of day phases
    float isDay = smoothstep(0.02, 0.10, angle) * smoothstep(0.48, 0.40, angle);
    float isTwilight = smoothstep(0.40, 0.48, angle) * smoothstep(0.58, 0.50, angle)
                     + smoothstep(0.94, 1.0, angle) + smoothstep(0.06, 0.0, angle);
    float isNight = smoothstep(0.52, 0.60, angle) * smoothstep(0.98, 0.90, angle);
    
    // Sky gradient based on reflection direction (up = bright, down = dark)
    float upAmount = reflectDir.y * 0.5 + 0.5;
    
    // Day: bright blue sky gradient
    vec3 dayColor = mix(vec3(0.6, 0.7, 0.8), vec3(0.4, 0.6, 1.0), upAmount);
    
    // Twilight: warm orange-pink
    vec3 twilightColor = mix(vec3(0.4, 0.3, 0.3), vec3(1.0, 0.6, 0.4), upAmount);
    
    // Night: dark blue with subtle stars
    vec3 nightColor = mix(vec3(0.02, 0.02, 0.04), vec3(0.1, 0.15, 0.25), upAmount);
    
    float totalWeight = max(isDay + isTwilight + isNight, 0.001);
    return (dayColor * isDay + twilightColor * isTwilight + nightColor * isNight) / totalWeight;
}

// Fresnel effect - edges reflect more
float fresnelSchlick(float cosTheta, float F0) {
    // Clamp cosTheta away from 0 to prevent extreme fresnel spikes at grazing angles
    float ct = max(cosTheta, 0.05);
    return F0 + (1.0 - F0) * pow(1.0 - ct, 5.0);
}

// GGX/Trowbridge-Reitz normal distribution for realistic specular
float distributionGGX(float NdotH, float roughness) {
    float a = roughness * roughness;
    float a2 = a * a;
    float denom = NdotH * NdotH * (a2 - 1.0) + 1.0;
    return a2 / (3.14159265 * denom * denom);
}

// Derive a per-texel micro-normal from texture color to break up flat reflections.
// Uses only texture luminance (no position-based noise) for stable, flicker-free results.
vec3 perturbNormal(vec3 N, vec3 baseColor, vec3 wPos) {
    // Sample luminance at offsets to get smooth gradient across texels
    // Use a multi-texel step to avoid per-pixel edge artifacts
    vec2 dUVdx = dFdx(texcoord);
    vec2 dUVdy = dFdy(texcoord);
    vec2 texelStep = abs(dUVdx) + abs(dUVdy); // ~1 pixel in UV space

    float lumC = dot(baseColor, vec3(0.299, 0.587, 0.114));
    float lumR = dot(texture(gtexture, texcoord + texelStep * vec2(1.0, 0.0)).rgb * glcolor.rgb, vec3(0.299, 0.587, 0.114));
    float lumU = dot(texture(gtexture, texcoord + texelStep * vec2(0.0, 1.0)).rgb * glcolor.rgb, vec3(0.299, 0.587, 0.114));

    float dLdu = lumR - lumC;
    float dLdv = lumU - lumC;

    // Build tangent frame from the geometric normal
    vec3 up = abs(N.y) < 0.99 ? vec3(0.0, 1.0, 0.0) : vec3(1.0, 0.0, 0.0);
    vec3 T = normalize(cross(up, N));
    vec3 B = cross(N, T);

    float bumpStrength = 1.2;
    vec3 perturbed = N - T * (dLdu * bumpStrength) - B * (dLdv * bumpStrength);

    return normalize(perturbed);
}

// Brightness-dependent metalness factor: strong on bright pixels, moderate on dark
float getBrightnessMetalFactor(vec3 baseColor) {
    float lum = dot(baseColor, vec3(0.299, 0.587, 0.114));
    // Remap: dark pixels get 0.35 effect, bright pixels get full 1.0
    return mix(0.35, 1.0, smoothstep(0.05, 0.6, lum));
}

// End-specific environment color ? purple/indigo tones matching the void sky
vec3 getEndEnvironmentColor(vec3 reflectDir) {
    float upAmount = reflectDir.y * 0.5 + 0.5;
    // Dark void below, purple-indigo glow above
    vec3 downColor = vec3(0.05, 0.02, 0.10);
    vec3 upColor = vec3(0.25, 0.10, 0.45);
    return mix(downColor, upColor, upAmount);
}

// End-specific metalness ? uses vortex light instead of sun, purple environment
vec3 applyMetalnessEnd(vec3 baseColor, vec3 viewDir, vec3 surfaceNormal, vec3 lightDir, float metalType, vec3 wPos, float time) {
    bool isMetal = (metalType > 0.5 && metalType < 1.5);
    bool isGem = (metalType > 1.5);

    // Brightness-dependent: bright pixels get strong metal, dark get moderate
    float brightFactor = getBrightnessMetalFactor(baseColor);

    vec3 N = perturbNormal(normalize(surfaceNormal), baseColor, wPos);
    vec3 V = normalize(-viewDir);
    vec3 R = reflect(-V, N);
    vec3 L = normalize(lightDir);
    vec3 H = normalize(V + L);

    float NdotV = max(dot(N, V), 0.001);
    float NdotH = max(dot(N, H), 0.0);
    float NdotL = max(dot(N, L), 0.0);

    float F0 = isMetal ? 0.7 : 0.4;
    float fresnel = fresnelSchlick(NdotV, F0) * METALNESS_FRESNEL;

    // End environment ? purple/indigo tones
    vec3 envColor = getEndEnvironmentColor(R);
    vec3 reflectionTint = isMetal ? baseColor : mix(vec3(1.0), baseColor, 0.3);
    vec3 reflection = envColor * reflectionTint;

    // GGX specular from the fake vortex light
    float roughness = METALNESS_ROUGHNESS;
    if (isGem) roughness = max(roughness * 0.5, 0.35);
    float D = distributionGGX(NdotH, roughness);
    float metalSpec = D * NdotL;

    // Gem sparkle
    float sparkle = 0.0;
    if (isGem) {
        float sparkleNoise = fract(sin(dot(N * 100.0, vec3(12.9898, 78.233, 45.5432))) * 43758.5453);
        float sparkleAngle = pow(max(NdotH, 0.0), 60.0);
        sparkle = sparkleAngle * sparkleNoise * GEM_SPARKLE * NdotL;
    }

    // Effective intensity scaled by pixel brightness
    float effectiveIntensity = METALNESS_INTENSITY * brightFactor;

    // Metal edge darkening
    float edgeDarken = isMetal ? mix(0.7, 1.0, NdotV) : 1.0;

    vec3 metalColor = baseColor * edgeDarken;

    // Blend in purple environment reflection
    metalColor = mix(metalColor, reflection, fresnel * effectiveIntensity);

    // Specular highlight tinted purple-white for End ambiance
    vec3 specColor = isMetal ? mix(baseColor, vec3(0.6, 0.4, 1.0), 0.3) * 2.5 : vec3(0.8, 0.7, 1.0);
    metalColor += metalSpec * specColor * effectiveIntensity;

    if (isGem) {
        metalColor += vec3(sparkle) * vec3(0.8, 0.6, 1.0);
    }

    return metalColor;
}

// Apply metalness effect to a surface
vec3 applyMetalness(vec3 baseColor, vec3 viewDir, vec3 surfaceNormal, vec3 lightDir, float sunAngle, float metalType, vec3 wPos) {
    bool isMetal = (metalType > 0.5 && metalType < 1.5);
    bool isGem = (metalType > 1.5);

    // Brightness-dependent: bright pixels get strong metal, dark get moderate
    float brightFactor = getBrightnessMetalFactor(baseColor);

    vec3 N = perturbNormal(normalize(surfaceNormal), baseColor, wPos);
    vec3 V = normalize(-viewDir);
    vec3 R = reflect(-V, N);
    vec3 L = normalize(lightDir);
    vec3 H = normalize(V + L);

    float NdotV = max(dot(N, V), 0.001);
    float NdotH = max(dot(N, H), 0.0);
    float NdotL = max(dot(N, L), 0.0);

    // Fresnel ? metals have high F0 (colored), gems moderate
    float F0 = isMetal ? 0.7 : 0.4;
    float fresnel = fresnelSchlick(NdotV, F0) * METALNESS_FRESNEL;

    // Environment reflection
    vec3 envColor = getEnvironmentColor(R, sunAngle);
    vec3 reflectionTint = isMetal ? baseColor : mix(vec3(1.0), baseColor, 0.3);
    vec3 reflection = envColor * reflectionTint;

    // GGX specular ? more realistic than Blinn-Phong
    float roughness = METALNESS_ROUGHNESS;
    if (isGem) roughness = max(roughness * 0.5, 0.35);
    float D = distributionGGX(NdotH, roughness);
    float metalSpec = D * NdotL;

    // Gems get extra sparkle
    float sparkle = 0.0;
    if (isGem) {
        float sparkleNoise = fract(sin(dot(N * 100.0, vec3(12.9898, 78.233, 45.5432))) * 43758.5453);
        float sparkleAngle = pow(max(NdotH, 0.0), 60.0);
        sparkle = sparkleAngle * sparkleNoise * GEM_SPARKLE * NdotL;
    }

    // Effective intensity scaled by pixel brightness
    float effectiveIntensity = METALNESS_INTENSITY * brightFactor;

    // Metal edge darkening ? real metals absorb more at glancing angles
    float edgeDarken = isMetal ? mix(0.7, 1.0, NdotV) : 1.0;

    vec3 metalColor = baseColor * edgeDarken;

    // Blend in environment reflection
    metalColor = mix(metalColor, reflection, fresnel * effectiveIntensity);

    // Specular highlight ? metals tint by surface color, gems stay white
    vec3 specColor = isMetal ? baseColor * 2.5 : vec3(1.0);
    metalColor += metalSpec * specColor * effectiveIntensity;

    // Add gem sparkle
    if (isGem) {
        metalColor += vec3(sparkle);
    }

    return metalColor;
}
#endif

void main() {
    vec2 finalUV = texcoord;
    
    vec4 color = texture(gtexture, finalUV) * glcolor;
    
    if (color.a < alphaTestRef) {
        discard;
    }

    // True distance dissolve near vanilla chunk edge (not fog blend).
    // Uses a world-height reveal plane so geometry reveals bottom-up.
    if (!isForcedNetherBiome(biome) && !isForcedEndBiome(biome)) {
        #if defined(CHUNK_FADE_OUT_ENABLED) && !defined(DISTANT_HORIZONS)
        // Horizontal world distance only to avoid per-pixel depth ordering.
        float horizontalDist = length(worldPos.xz - cameraPosition.xz);
        float distGate = smoothstep(CHUNK_FADE_OUT_RADIUS, CHUNK_FADE_OUT_RADIUS + 24.0, horizontalDist);
        if (distGate > 0.001) {
            float reveal = 1.0 - distGate; // Near=1, Far=0
            float minY = SEA_LEVEL_OFFSET - 96.0;
            float maxY = SEA_LEVEL_OFFSET + 320.0;
            // Small world-anchored jitter to avoid a perfectly straight cut line.
            float mask = smoothChunkNoise(worldPos.xz * 0.12);
            float jitterY = (mask - 0.5) * 10.0;
            float revealY = mix(minY, maxY, reveal) + jitterY;
            float visible = 1.0 - smoothstep(revealY - 8.0, revealY + 8.0, worldPos.y);
            color.rgb *= mix(0.60, 1.0, visible);
            if (visible < 0.02) {
                discard;
            }
        }
        #endif
    }

    // Store raw texture color for glass bloom (before any lighting)
    vec3 rawColor = color.rgb;

    float finalBlocklight = blocklight;
    float finalSkylight = skylight;
    float finalEmissive = emissive;

    // Held torches/lanterns/soul lights: already emissive via block.properties,
    // but apply extra brightness so they visually glow brighter than raw texture.
    bool isHeldLight = (currentRenderedItemId == 10020 || currentRenderedItemId == 10021);

    // Handheld light applied after lighting as additive tinted color (see lighting.glsl)
    
    if (isGrassGeometry > 0.5) {
        float dLightX = dFdx(blocklight);
        float dLightZ = dFdy(blocklight);
        vec2 blockFract = fract(worldPos.xz);
        float gradientOffset = (blockFract.x - 0.5) * dLightX * 8.0 + (blockFract.y - 0.5) * dLightZ * 8.0;
        finalBlocklight = clamp(blocklight + gradientOffset, 0.0, 1.0);
    }

    // Calculate shadow
    float shadow = 1.0;
    #ifdef SHADOWS_ENABLED
    if (finalSkylight > 0.05 && finalEmissive < 0.5) {
        // Shadow sample position (Z may be biased for leaves)
        vec3 shadowSamplePos = shadowPos.xyz;

        // Leaf shadow Z bias: push shadow sample toward light on back faces
        // so the lit area extends slightly past the block boundary
        #ifdef LEAF_SHEEN_ENABLED
        {
            int bid = int(blockId + 0.5);
            if (bid == 10005) {
                vec3 wN = normalize(mat3(gbufferModelViewInverse) * normal);
                vec3 wL = normalize(mat3(gbufferModelViewInverse) * shadowLightPosition);
                float backFace = max(0.0, -dot(wN, wL));
                shadowSamplePos.z -= backFace * LEAF_SHADOW_TRANSMITTANCE * 0.02;
            }
        }
        #endif

        // Leaf blocks: always use wide PCF blur to soften shadows and hide blocky geometry
        int shadowBid = int(blockId + 0.5);
        bool isLeafShadow = (shadowBid == 10005);

        float dither = interleavedGradientNoise(gl_FragCoord.xy, frameCounter);
        float r = quartic_length(shadowSamplePos.xy * 2.0 - 1.0);
        float distortFactor = r + SHADOW_DISTORTION;

        if (isLeafShadow) {
            #if LEAF_SHADOW_SOFTNESS <= 0.0
                // Softness 0.0 = sharp leaf shadows (no leaf PCF blur)
                float mapDepth = texture(shadowtex0, shadowSamplePos.xy).r;
                shadow = step(shadowSamplePos.z, mapDepth);
                float fadeFactor = smoothstep(SHADOW_DISTANCE * 0.8, SHADOW_DISTANCE, viewDistance);
                shadow = mix(shadow, 1.0, fadeFactor);
            #else
                shadow = getShadowLeafFaded(shadowtex0, shadowSamplePos, distortFactor, viewDistance, dither);
            #endif
        } else {
            #ifdef SHARP_SHADOWS
                float mapDepth = texture(shadowtex0, shadowSamplePos.xy).r;
                shadow = step(shadowSamplePos.z, mapDepth);
                float fadeFactor = smoothstep(SHADOW_DISTANCE * 0.8, SHADOW_DISTANCE, viewDistance);
                shadow = mix(shadow, 1.0, fadeFactor);
            #else
                shadow = getShadowFaded(shadowtex0, shadowSamplePos, distortFactor, viewDistance, dither);
            #endif
        }

        // Zenith fix for vertical walls at noon
        // Skip for foliage/crops (IDs 2,3,4,19,15) ? they should never go dark
        bool isFoliageShadowId = (shadowBid == 10002 || shadowBid == 10003 || shadowBid == 10004 || shadowBid == 10019);
        if (shadowPos.w < 0.001 && isGrassGeometry < 0.5 && !isFoliageShadowId) {
            shadow = 0.0;
        }

        // Vine/sugar_cane (block 10018): skip self-shadowing entirely
        if (shadowBid == 10018) {
            shadow = 1.0;
        }


        // Blend shadow with ambient based on sky visibility
        shadow = mix(1.0, shadow, finalSkylight);

        // Apply shadow opacity
        shadow = mix(1.0, shadow, SHADOW_OPACITY);
    }
    #endif

    // Apply cloud shadows
    #if defined(CLOUDS_2D_ENABLED) && defined(CLOUD_SHADOWS_ENABLED)
    if (finalSkylight > 0.1) {
        float cloudShadow = getCloudShadow(worldPos, frameTimeCounter);
        shadow *= cloudShadow;
    }
    #endif

    color.rgb = applyLightingWithShadow(color.rgb, sunAngle, finalSkylight, finalBlocklight, finalEmissive, shadow);


    bool outputHeldBloom = false;
    vec3 heldBloomColor = vec3(0.0);
    #ifdef HANDHELD_LIGHT_ENABLED
    float distToEye = length(worldPos - eyePosition);
    bool isHeldLightItem = (heldItemId == 10020 || heldItemId == 10021 ||
                            heldItemId2 == 10020 || heldItemId2 == 10021);
    
    // Standard path: heldItemId works ? full emissive + bloom
    if (distToEye < 2.0 && isHeldLightItem) {
        color.rgb = rawColor * EMISSIVE_BRIGHTNESS * 1.5;
        finalEmissive = 1.0;
        heldBloomColor = rawColor * EMISSIVE_BRIGHTNESS * 1.5;
        outputHeldBloom = true;
    }
    
    // Mod-agnostic fallback: block IDs are stripped by 3D model mods.
    // Only catch blocks with NO block.properties mapping (blockId < 1.0).
    // Normal terrain (grass, stone, dirt etc.) all have valid IDs and are excluded.
    if (!outputHeldBloom) {
        bool holdingLight = (heldBlockLightValue > 7 || heldBlockLightValue2 > 7);
        if (holdingLight && distToEye < HELD_BLOOM_RADIUS && blockId < 1.0) {
            float rawColorLuma = dot(rawColor, vec3(0.299, 0.587, 0.114));
            if (rawColorLuma > HELD_BLOOM_THRESHOLD) {
                color.rgb = rawColor * EMISSIVE_BRIGHTNESS * HELD_BLOOM_EMISSION;
                finalEmissive = 1.0;
                heldBloomColor = rawColor * EMISSIVE_BRIGHTNESS * HELD_BLOOM_STRENGTH;
                outputHeldBloom = true;
            }
        }
    }
    #endif
    #ifdef HANDHELD_LIGHT_ENABLED
    if (finalEmissive < 0.5) color.rgb += getHandheldLightBoost(worldPos, rawColor, color.rgb);
    #endif
    color.rgb *= TERRAIN_BRIGHTNESS;

    // End dimension: terrain darkness patches + ambient darkening
    #ifdef END_SHADER
    if (finalEmissive < 0.5) {
        // Random darkness patches on ground surfaces for visual variety
        #ifdef END_TERRAIN_PATCHES_ENABLED
        {
            // Only patch upward-facing surfaces (ground, not walls/ceilings)
            float patchUpFacing = max(normal.y, 0.0);
            if (patchUpFacing > 0.3) {
                // 2D hash for value noise
                vec2 patchPos = worldPos.xz * END_TERRAIN_PATCH_SCALE;
                // Multi-octave value noise for varied patch sizes (up to ~10 blocks)
                float pn = 0.0;
                float pAmp = 0.6;
                for (int octave = 0; octave < 3; octave++) {
                    vec2 ip = floor(patchPos);
                    vec2 fp = fract(patchPos);
                    fp = fp * fp * (3.0 - 2.0 * fp); // smoothstep interp
                    float a = fract(sin(dot(ip, vec2(127.1, 311.7))) * 43758.5453);
                    float b = fract(sin(dot(ip + vec2(1.0, 0.0), vec2(127.1, 311.7))) * 43758.5453);
                    float c = fract(sin(dot(ip + vec2(0.0, 1.0), vec2(127.1, 311.7))) * 43758.5453);
                    float d = fract(sin(dot(ip + vec2(1.0, 1.0), vec2(127.1, 311.7))) * 43758.5453);
                    pn += mix(mix(a, b, fp.x), mix(c, d, fp.x), fp.y) * pAmp;
                    patchPos *= 2.3;
                    pAmp *= 0.45;
                }
                // Shape into patches: darken where noise is low
                float patchDark = smoothstep(0.25, 0.55, pn);
                patchDark = mix(1.0, 1.0 - END_TERRAIN_PATCH_STRENGTH, 1.0 - patchDark);
                color.rgb *= mix(1.0, patchDark, patchUpFacing);
            }
        }
        #endif

        float baseDarken = 0.55;
        vec3 purpleTint = vec3(0.08, 0.06, 0.35);
        float tintMult = 0.15;
        float colorShift = 0.55;

        // Blocklight + handheld to preserve through event darkness
        float preserveBlend = 0.0;
        vec3 preservedLight = vec3(0.0);

        #if defined(END_SHADER) && defined(END_EVENT_ENABLED)
        EndEvent endEvent = getEndEvent(frameTimeCounter);
        float eventDarkness = endEvent.terrainDarkness;
        if (eventDarkness > 0.001) {
            // Recompute blocklight contribution (mirrors lighting.glsl END_SHADER path)
            float bFalloff = getBlocklightFalloff(finalBlocklight, finalSkylight);
            vec3 endBlockColor = vec3(END_BLOCKLIGHT_R, END_BLOCKLIGHT_G, END_BLOCKLIGHT_B);
            preservedLight = rawColor * endBlockColor * bFalloff * bFalloff * END_BLOCKLIGHT_BRIGHTNESS * TERRAIN_BRIGHTNESS;

            // Also preserve handheld light contribution
            #ifdef HANDHELD_LIGHT_ENABLED
            preservedLight += getHandheldLightBoost(worldPos, rawColor, vec3(0.0)) * TERRAIN_BRIGHTNESS;
            #endif

            preserveBlend = eventDarkness;
        }
        baseDarken = mix(baseDarken, 0.02, eventDarkness);
        tintMult = mix(tintMult, 0.0, eventDarkness);
        colorShift = mix(colorShift, 0.0, eventDarkness);
        #endif

        color.rgb *= baseDarken;
        color.rgb += purpleTint * tintMult;
        color.rgb = mix(color.rgb, color.rgb * vec3(0.55, 0.58, 1.35), colorShift);

        // Restore blocklight + handheld through darkness
        color.rgb += preservedLight * preserveBlend;

        // Eye spotlight ? theatre-style light cone from the cosmic eye onto the player
        #if defined(END_SHADER) && defined(END_EVENT_ENABLED) && defined(END_EVENT_EYE_ENABLED) && defined(END_EVENT_SPOTLIGHT_ENABLED)
        if (endEvent.eyeOpen > 0.01) {
            // Distance from fragment to player (XZ only ? spotlight from above)
            // eyePosition is the player's head ? stays on entity even in third-person
            vec2 playerXZ = eyePosition.xz;
            vec2 fragXZ = worldPos.xz;
            float hDist = length(fragXZ - playerXZ);

            // Soft circular falloff with radius from setting
            float spotRadius = END_EVENT_SPOTLIGHT_RADIUS;
            float spot = 1.0 - smoothstep(spotRadius * 0.4, spotRadius, hDist);

            // Only illuminate upward-facing surfaces (dot with up vector)
            float upFacing = max(normal.y, 0.0);
            spot *= upFacing;

            // Modulate by eye openness (fades with blinks and close)
            spot *= endEvent.eyeOpen;

            // Spotlight color: cool purple-white (from the eye)
            vec3 spotColor = vec3(
                END_EVENT_EYE_IRIS_R * 0.5 + 0.5,
                END_EVENT_EYE_IRIS_G * 0.3 + 0.4,
                END_EVENT_EYE_IRIS_B * 0.4 + 0.6
            );
            color.rgb += rawColor * spotColor * spot * END_EVENT_SPOTLIGHT_INTENSITY * TERRAIN_BRIGHTNESS;
        }
        #endif
    }
    #endif

    // Grass block variation: subtle dark blue-green patches for depth (overworld only)
    #ifndef END_SHADER
    {
        int bid = int(blockId + 0.5);
        int btype = (bid >= 10000) ? (bid - 10000) : -1;
        if (btype == 15 && finalEmissive < 0.5) {
            // Only patch upward-facing surfaces (grass top, not dirt sides)
            float upFacing = max(normal.y, 0.0);
            if (upFacing > 0.3) {
                vec2 patchPos = worldPos.xz * 0.15;
                float pn = 0.0;
                float pAmp = 0.6;
                for (int octave = 0; octave < 3; octave++) {
                    vec2 ip = floor(patchPos);
                    vec2 fp = fract(patchPos);
                    fp = fp * fp * (3.0 - 2.0 * fp);
                    float a = fract(sin(dot(ip, vec2(127.1, 311.7))) * 43758.5453);
                    float b = fract(sin(dot(ip + vec2(1.0, 0.0), vec2(127.1, 311.7))) * 43758.5453);
                    float c = fract(sin(dot(ip + vec2(0.0, 1.0), vec2(127.1, 311.7))) * 43758.5453);
                    float d = fract(sin(dot(ip + vec2(1.0, 1.0), vec2(127.1, 311.7))) * 43758.5453);
                    pn += mix(mix(a, b, fp.x), mix(c, d, fp.x), fp.y) * pAmp;
                    patchPos *= 2.3;
                    pAmp *= 0.45;
                }
                // Dark blue-green tint in low noise areas
                float patchMask = 1.0 - smoothstep(0.25, 0.55, pn);
                float patchStrength = 0.20 * patchMask * upFacing;
                // Darken and shift toward blue-green
                color.rgb *= mix(vec3(1.0), vec3(0.7, 0.8, 0.95), patchStrength);
            }
        }
    }
    #endif

    // Palette limit final lit color
    #ifdef TEXTURE_PALETTE_ENABLED
    if (finalEmissive < 0.5) {
        float levels = float(TEXTURE_PALETTE_LEVELS);
        color.rgb = floor(color.rgb * levels) / levels;
    }
    #endif

    // Apply metalness effect to metallic/gem blocks
    #ifdef METALNESS_ENABLED
    if (metalness > 0.5 && finalEmissive < 0.5) {
        // Calculate view direction (from camera to fragment)
        vec3 viewDir = normalize(worldPos - cameraPosition);

        #ifdef END_SHADER
        // End has no sun ? use a slow-rotating overhead vortex light
        float endLightAngle = frameTimeCounter * 0.15;
        vec3 lightDir = normalize(vec3(sin(endLightAngle) * 0.4, 0.8, cos(endLightAngle) * 0.4));
        // Pass sunAngle = 0.25 (permanent "day" phase) so getEnvironmentColor picks something
        // but we override the environment color in applyMetalness via the End path below
        color.rgb = applyMetalnessEnd(color.rgb, viewDir, normal, lightDir, metalness, worldPos, frameTimeCounter);
        #else
        // Get light direction (sun/moon)
        vec3 lightDir = normalize(shadowLightPosition);

        // Apply metalness with view-dependent reflections
        color.rgb = applyMetalness(color.rgb, viewDir, normal, lightDir, sunAngle, metalness, worldPos);
        #endif
    }
    #endif

    // PBR material specular highlights (from resource pack textures or default materials)
    #ifdef PBR_ENABLED
    float pbrEmissive = 0.0;   // LabPBR per-pixel emissiveness (specular.a)
    vec3 pbrNormal = normal;   // PBR-decoded normal for SSR (falls back to geometric)
    if (finalEmissive < 0.5 && metalness < 0.5) {
        // Sample PBR textures from resource pack
        vec4 normalData = texture(normals, texcoord);
        vec4 specData = texture(specular, texcoord);

        // Detect if a PBR resource pack is providing data
        // Without PBR pack: Iris returns flat normal (0.5, 0.5, 1.0) and specular all zeros
        bool normalIsFlat = abs(normalData.r - 0.5) < 0.05 && abs(normalData.g - 0.5) < 0.05 && normalData.b > 0.90;
        bool specIsEmpty = (specData.r + specData.g + specData.b + specData.a) < 0.02;
        bool hasPBR = !normalIsFlat || !specIsEmpty;

        // Decode roughness, F0, and metalness
        float pbrRoughness;
        float pbrF0;
        float pbrMetallic;

        if (hasPBR) {
            #ifdef MC_TEXTURE_FORMAT_LAB_PBR
            // LabPBR format
            float perceptualSmooth = specData.r;
            pbrRoughness = pow(1.0 - perceptualSmooth, 2.0);
            // G channel: 0-229/255 = dielectric F0, 230-255/255 = metals
            float rawF0 = specData.g * 255.0;
            if (rawF0 > 229.5) {
                pbrMetallic = 1.0;
                pbrF0 = 0.7; // Metals have high F0
            } else {
                pbrMetallic = 0.0;
                pbrF0 = specData.g * (255.0 / 229.0); // Remap 0-229 to 0-1
                pbrF0 = max(pbrF0, 0.02); // Minimum F0 for dielectrics
            }
            #else
            // oldPBR (seusPBR) format
            pbrRoughness = pow(1.0 - specData.r, 2.0);
            pbrMetallic = step(0.5, specData.g);
            pbrF0 = pbrMetallic > 0.5 ? 0.7 : 0.04;
            #endif
        } else {
            // Default materials based on block ID (no PBR resource pack)
            int bid = int(blockId + 0.5);
            int btype = (bid >= 10000) ? (bid - 10000) : -1;

            if (btype == 10) {
                // Wood: smooth grain specular
                pbrRoughness = DEFAULT_WOOD_ROUGHNESS;
                pbrF0 = 0.04;
                pbrMetallic = 0.0;
            } else if (btype == 18) {
                // Stone: harsh rough specular
                pbrRoughness = DEFAULT_STONE_ROUGHNESS;
                pbrF0 = 0.04;
                pbrMetallic = 0.0;
            } else if (btype == 17) {
                // Polished/glazed: smoother
                pbrRoughness = 0.45;
                pbrF0 = 0.05;
                pbrMetallic = 0.0;
            } else {
                // No PBR data and not a default material ? skip
                pbrRoughness = -1.0; // sentinel: skip PBR
                pbrF0 = 0.0;
                pbrMetallic = 0.0;
            }
        }

        // Apply PBR specular if we have data
        if (pbrRoughness >= 0.0) {
            // Build surface normal
            vec3 N;
            if (hasPBR) {
                // Decode tangent-space normal from texture
                vec3 tNormal = normalData.rgb * 2.0 - 1.0;
                tNormal.xy *= PBR_NORMAL_STRENGTH;
                tNormal = normalize(tNormal);
                // Transform to view space via TBN matrix
                mat3 TBN = mat3(normalize(tangentVec), normalize(binormalVec), normalize(normal));
                N = normalize(TBN * tNormal);
            } else {
                // Use luminance-perturbed geometric normal (for default materials)
                vec3 rawColor = texture(gtexture, texcoord).rgb;
                N = perturbNormal(normalize(normal), rawColor, worldPos);
            }

            // Lighting vectors ? work in world space
            vec3 L = normalize(mat3(gbufferModelViewInverse) * shadowLightPosition);
            vec3 Nworld = normalize(mat3(gbufferModelViewInverse) * N);
            vec3 Vworld = normalize(cameraPosition - worldPos);
            vec3 Hworld = normalize(Vworld + L);

            float NdotL = max(dot(Nworld, L), 0.0);
            float NdotH = max(dot(Nworld, Hworld), 0.0);
            float NdotV = max(dot(Nworld, Vworld), 0.001);

            // Scale by sun visibility (shadow) and skylight
            float sunVisibility = shadow * finalSkylight;
            // Time of day: reduce specular at night
            float dayFactor = smoothstep(0.02, 0.10, fract(sunAngle)) * smoothstep(0.48, 0.40, fract(sunAngle));

            if (hasPBR) {
                // Full PBR GGX for resource pack data
                float D = distributionGGX(NdotH, max(pbrRoughness, 0.04));
                float F = fresnelSchlick(NdotV, pbrF0);
                float spec = D * F * NdotL;

                vec3 specColor = pbrMetallic > 0.5 ? color.rgb * 2.5 : vec3(1.0);
                color.rgb += spec * specColor * PBR_SPECULAR_STRENGTH * sunVisibility * dayFactor;

                // Metallic environment reflection
                if (pbrMetallic > 0.5) {
                    vec3 R = reflect(-Vworld, Nworld);
                    vec3 envColor = getEnvironmentColor(R, sunAngle);
                    float envFresnel = fresnelSchlick(NdotV, pbrF0) * 0.5;
                    color.rgb = mix(color.rgb, envColor * color.rgb, envFresnel * PBR_SPECULAR_STRENGTH);
                }
            } else {
                // Stylized specular for default materials (no PBR pack)
                // Broad, soft specular that follows texture grain via perturbed normal
                float shininess = mix(4.0, 32.0, 1.0 - pbrRoughness); // roughness 0.6 ? ~15
                float spec = pow(NdotH, shininess);

                // Normalize Blinn-Phong to keep energy consistent
                float normFactor = (shininess + 2.0) / (2.0 * 3.14159);
                spec *= normFactor;

                // Wrap NdotL so side faces still get specular
                float wrappedNdotL = max(NdotL, 0.25);

                float specAmount = spec * wrappedNdotL * 0.15;
                color.rgb += specAmount * PBR_SPECULAR_STRENGTH * sunVisibility * dayFactor;
            }

            // Export PBR normal for SSR encoding
            pbrNormal = N;
        }

        // LabPBR per-pixel emissiveness from specular.a
        if (hasPBR) {
            #ifdef MC_TEXTURE_FORMAT_LAB_PBR
            pbrEmissive = specData.a;
            #else
            pbrEmissive = specData.b; // oldPBR: emissive in blue channel
            #endif
        }
    }

    // Apply PBR per-pixel emissiveness ? blend with existing emissive system
    if (pbrEmissive > 0.01) {
        // Boost brightness for emissive texels (like block-ID emissive does)
        finalEmissive = max(finalEmissive, pbrEmissive);
        // Add self-illumination: emissive pixels glow regardless of lighting
        color.rgb = mix(color.rgb, rawColor * 1.5, pbrEmissive * 0.5);
    }
    #endif

    // Leaf Sheen: face-independent subsurface glow for stylized foliage
    #ifdef LEAF_SHEEN_ENABLED
    {
        int bid = int(blockId + 0.5);
        if (bid == 10005 && finalEmissive < 0.5) {
            vec3 worldLightDir = normalize(mat3(gbufferModelViewInverse) * shadowLightPosition);
            vec3 viewDir = normalize(worldPos - cameraPosition);

            // --- Subsurface Scattering (no face normals ? uniform across block) ---
            // Pure view-to-light: glow when looking toward the sun through foliage
            float VdotL = max(dot(viewDir, worldLightDir), 0.0);
            float sss = pow(VdotL, 3.0) * LEAF_SSS_STRENGTH;
            vec3 sssColor = color.rgb * vec3(1.2, 1.1, 0.7) * sss * finalSkylight * shadow;

            color.rgb += sssColor;
        }
    }
    #endif

    // Apply legacy sky fog - but NOT for forced-Nether handling.
    // Nether fog is composited in final.fsh so chunks and DH LOD stay matched.
    if (finalEmissive < 0.5 && isEyeInWater != 1 && !isForcedNetherBiome(biome)) {
        float denom = max(fogEnd - fogStart, 0.0001);
        float fogFactor = clamp((fogEnd - viewDistance) / denom, 0.0, 1.0);
        color.rgb = mix(getTimeBasedFogColor(), color.rgb, fogFactor);
    }

    gl_FragData[0] = color;
    // R = outline mask, G = emissive, B = skylight (for bloom), A = heat source
    gl_FragData[1] = vec4(outlineMask, finalEmissive, finalSkylight, isHeatSource);
    
    // Colored light for nearby surface tinting (using emissive type lookup)
    vec3 lightColor = vec3(0.0);
    if (finalEmissive > 0.5) {
        lightColor = getEmissiveLightColor(emissiveType) * EMISSIVE_BRIGHTNESS;
        #ifdef END_SHADER
        lightColor *= END_EMISSIVE_BOOST;
        #endif
    }
    
    // Natively inject 3D Block Model Handheld Glow directly into the bloom buffer matching 3rd person
    if (outputHeldBloom) {
        lightColor = heldBloomColor;
    }
    
    gl_FragData[2] = vec4(lightColor, 1.0);
    
    // Block ID for connected texture detection (normalize to 0-1 range roughly)
    gl_FragData[3] = vec4(blockId / 65535.0, 0.0, 0.0, 1.0);

    // Reflective material SSR data (colortex5) ? same format as water reflections
    #ifdef MATERIAL_REFLECTIONS_ENABLED
    if (reflective > 0.5 && finalEmissive < 0.5) {
        // Use PBR-decoded normal for better SSR on textured surfaces when available
        #ifdef PBR_ENABLED
        vec3 ssrNormal = pbrNormal;
        #else
        vec3 ssrNormal = normal;
        #endif
        vec3 worldNormal = normalize(mat3(gbufferModelViewInverse) * ssrNormal);
        vec3 encodedNormal = worldNormal * 0.5 + 0.5;
        // Pack lightmap coords (ILV style)
        float packedLmcoord = dot(floor(255.0 * vec2(blocklight, skylight) + 0.5), vec2(1.0 / 65535.0, 256.0 / 65535.0));
        // Pack reflectiveness
        float packedReflect = dot(floor(255.0 * vec2(MATERIAL_REFLECTION_AMOUNT, 0.0) + 0.5), vec2(1.0 / 65535.0, 256.0 / 65535.0));
        gl_FragData[4] = vec4(packedLmcoord, packedReflect, encodedNormal.x, encodedNormal.y);
    } else {
        gl_FragData[4] = vec4(0.0);
    }
    #else
    gl_FragData[4] = vec4(0.0);
    #endif
}




