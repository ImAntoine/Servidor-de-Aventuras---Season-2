/* RENDERTARGETS: 0,1 */

#include "/settings.glsl"
#include "/include/color_utils.glsl"
#include "/include/biome_overrides.glsl"

uniform float sunAngle;
uniform float frameTimeCounter;
uniform float rainStrength;
uniform mat4 gbufferModelViewInverse;
uniform vec3 fogColor;   // Biome horizon color (view-dependent during sunset!)
uniform vec3 skyColor;   // Biome zenith color (view-dependent during sunset!)
uniform int biome;
uniform int biome_category;
uniform float biome_jungle;
uniform float biome_swamp;
uniform float biome_snowy;
uniform float biome_arid;
uniform sampler2D noisetex;  // Noise texture for planet rings
uniform vec3 sunPosition;
uniform vec3 shadowLightPosition;
uniform vec3 cameraPosition;

in vec3 viewPos;
in vec4 starColor;

// Hash functions for procedural generation
float hash11(float p) {
    p = fract(p * 0.1031);
    p *= p + 33.33;
    p *= p + p;
    return fract(p);
}

float hash21(vec2 p) {
    vec3 p3 = fract(vec3(p.xyx) * 0.1031);
    p3 += dot(p3, p3.yzx + 33.33);
    return fract((p3.x + p3.y) * p3.z);
}

vec2 hash22(vec2 p) {
    vec3 p3 = fract(vec3(p.xyx) * vec3(0.1031, 0.1030, 0.0973));
    p3 += dot(p3, p3.yzx + 33.33);
    return fract((p3.xx + p3.yz) * p3.zy);
}

vec3 hash33(vec3 p) {
    p = fract(p * vec3(0.1031, 0.1030, 0.0973));
    p += dot(p, p.yxz + 33.33);
    return fract((p.xxy + p.yxx) * p.zyx);
}

// Rotation matrices
vec3 rotateX(vec3 v, float angle) {
    float c = cos(angle);
    float s = sin(angle);
    return vec3(v.x, v.y * c - v.z * s, v.y * s + v.z * c);
}

vec3 rotateY(vec3 v, float angle) {
    float c = cos(angle);
    float s = sin(angle);
    return vec3(v.x * c + v.z * s, v.y, -v.x * s + v.z * c);
}

vec3 rotateZ(vec3 v, float angle) {
    float c = cos(angle);
    float s = sin(angle);
    return vec3(v.x * c - v.y * s, v.x * s + v.y * c, v.z);
}

// Apply celestial rotation (synced with sun/moon path)
vec3 celestialRotate(vec3 dir) {
    // Sun path rotation (tilt of the celestial sphere)
    float pathTilt = radians(sunPathRotation);
    dir = rotateZ(dir, pathTilt);
    
    // Daily rotation (sunAngle goes 0->1 per day)
    float dailyRotation = sunAngle * 6.28318;
    dir = rotateX(dir, dailyRotation);
    
    return dir;
}

// Cube-map style projection - uniform distribution, no pole stretching
vec2 cubeProject(vec3 dir) {
    vec3 absDir = abs(dir);
    vec2 uv;
    float face;
    
    if (absDir.x >= absDir.y && absDir.x >= absDir.z) {
        uv = dir.zy / absDir.x;
        face = dir.x > 0.0 ? 0.0 : 1.0;
    } else if (absDir.y >= absDir.x && absDir.y >= absDir.z) {
        uv = dir.xz / absDir.y;
        face = dir.y > 0.0 ? 2.0 : 3.0;
    } else {
        uv = dir.xy / absDir.z;
        face = dir.z > 0.0 ? 4.0 : 5.0;
    }
    
    uv += face * 100.0;
    return uv;
}

// Simplex-like noise for galaxy
float simplexNoise(vec2 p) {
    vec2 i = floor(p);
    vec2 f = fract(p);
    f = f * f * (3.0 - 2.0 * f);
    
    float a = hash21(i);
    float b = hash21(i + vec2(1.0, 0.0));
    float c = hash21(i + vec2(0.0, 1.0));
    float d = hash21(i + vec2(1.0, 1.0));
    
    return mix(mix(a, b, f.x), mix(c, d, f.x), f.y);
}

// FBM noise for galaxy clouds
float fbm(vec2 p, int octaves) {
    float value = 0.0;
    float amplitude = 0.5;
    float frequency = 1.0;
    
    for (int i = 0; i < octaves; i++) {
        value += amplitude * simplexNoise(p * frequency);
        amplitude *= 0.5;
        frequency *= 2.0;
    }
    
    return value;
}

// Voronoi-like noise for dust lane structure
float voronoiNoise(vec2 p) {
    vec2 i = floor(p);
    vec2 f = fract(p);
    
    float minDist = 1.0;
    for (int x = -1; x <= 1; x++) {
        for (int y = -1; y <= 1; y++) {
            vec2 neighbor = vec2(float(x), float(y));
            vec2 point = hash22(i + neighbor);
            vec2 diff = neighbor + point - f;
            float d = length(diff);
            minDist = min(minDist, d);
        }
    }
    return minDist;
}

// Star field with rotation synced to sun path
float starField(vec3 dir, float time) {
    dir = normalize(dir);
    
    // Apply celestial rotation (synced with sunPathRotation and sunAngle)
    dir = celestialRotate(dir);
    
    // Use cube projection for uniform star distribution
    vec2 starUV = cubeProject(dir) * STAR_SCALE;
    
    vec2 cell = floor(starUV);
    vec2 local = fract(starUV);
    
    float star = 0.0;
    
    // Check 3x3 neighborhood
    for (int x = -1; x <= 1; x++) {
        for (int y = -1; y <= 1; y++) {
            vec2 nc = cell + vec2(x, y);
            
            // Star density check
            float rnd = hash21(nc);
            if (rnd > STAR_DENSITY) continue;
            
            // Star position within cell
            vec2 sp = hash22(nc) * 0.6 + 0.2;
            
            // Distance to star center
            vec2 d = local - vec2(x, y) - sp;
            float dist = length(d);
            
            // Base brightness with variation
            float baseBright = 0.4 + hash21(nc + 500.0) * 0.6;
            
            // Twinkling effect
            float twinklePhase = hash21(nc + 700.0) * 6.28318;
            float twinkleSpeed = 0.5 + hash21(nc + 800.0) * 2.0;
            float twinkle = 0.7 + 0.3 * sin(time * twinkleSpeed + twinklePhase);
            
            float twinkleAmount = hash21(nc + 900.0);
            twinkle = mix(1.0, twinkle, twinkleAmount * STAR_TWINKLE);
            
            float bright = baseBright * twinkle * STAR_BRIGHTNESS;
            
            // Size with variation
            float radius = STAR_SIZE * (0.5 + hash21(nc + 400.0) * 0.5);
            
            // Smooth circular star shape
            float s = 1.0 - smoothstep(0.0, radius, dist);
            star = max(star, s * bright);
        }
    }
    
    return star;
}

// Shooting star / meteor effect
vec3 shootingStar(vec3 dir, float time) {
    dir = normalize(dir);
    
    // Apply celestial rotation (synced with sunPathRotation)
    dir = celestialRotate(dir);
    
    vec3 result = vec3(0.0);
    
    // Check multiple potential shooting star slots
    for (int i = 0; i < 3; i++) {
        // Each shooting star has a random time window
        float slotOffset = float(i) * 47.0;
        float cycleTime = 15.0 + hash11(slotOffset) * 20.0; // 15-35 second cycles
        float t = mod(time + slotOffset, cycleTime);
        
        // Only active for short duration
        float duration = 0.5 + hash11(slotOffset + 10.0) * 1.0;
        if (t > duration) continue;
        
        // Random start position on sky dome
        float startPhi = hash11(slotOffset + 20.0) * 6.28318;
        float startTheta = 0.2 + hash11(slotOffset + 30.0) * 0.6; // Above horizon
        vec3 startDir = vec3(
            cos(startPhi) * cos(startTheta),
            sin(startTheta),
            sin(startPhi) * cos(startTheta)
        );
        
        // Direction of travel (slightly downward)
        float travelAngle = hash11(slotOffset + 40.0) * 6.28318;
        vec3 travelDir = vec3(cos(travelAngle), -0.3, sin(travelAngle));
        travelDir = normalize(travelDir);
        
        // Current position along trail
        float speed = 0.3 + hash11(slotOffset + 50.0) * 0.4;
        vec3 currentPos = startDir + travelDir * t * speed;
        currentPos = normalize(currentPos);
        
        // Distance from view direction to shooting star
        float angleDist = acos(clamp(dot(dir, currentPos), -1.0, 1.0));
        
        // Trail effect - elongated in travel direction
        vec3 toViewer = dir - currentPos;
        float alongTrail = dot(toViewer, travelDir);
        float perpDist = length(toViewer - travelDir * alongTrail);
        
        // Shooting star is visible if close to the trail
        float trailWidth = 0.003;
        float trailLength = 0.08 * (1.0 - t / duration); // Fades as it travels
        
        if (perpDist < trailWidth && alongTrail > -trailLength && alongTrail < 0.01) {
            float intensity = (1.0 - perpDist / trailWidth);
            intensity *= smoothstep(-trailLength, 0.0, alongTrail); // Fade along trail
            intensity *= 1.0 - t / duration; // Fade over time
            intensity *= STAR_SHOOTING_BRIGHTNESS;
            
            // Slightly blue-white color
            result += vec3(0.9, 0.95, 1.0) * intensity;
        }
    }
    
    return result;
}

// 2-layer blend (horizon -> zenith).
// Mid color is intentionally ignored to avoid middle-band artifacts.
vec3 blendSkyLayers(vec3 horizon, vec3 mid, vec3 zenith, float height, float midH, float zenithH) {
    float h = clamp(height, 0.0, 1.0);
    // Lock horizon size in 2-layer mode so it does not scale with per-phase heights.
    float transitionHeight = clamp(DAY_ZENITH_HEIGHT, 0.45, 0.95);
    float t = smoothstep(0.0, transitionHeight, h);
    return mix(horizon, zenith, t);
}

// ============================================================================
// === RINGED PLANET (EXACT copy from IterationT End Sky) ===
// ============================================================================
#ifdef RINGED_PLANET_ENABLED

#ifndef PI
#define PI 3.14159265359
#endif

float curve_p(float x) { return x * x * (3.0 - 2.0 * x); }
float saturate_p(float x) { return clamp(x, 0.0, 1.0); }

vec2 RaySphereIntersectionIO_p(vec3 p, vec3 dir, float r) {
    float b = dot(p, dir);
    float c = -r * r + dot(p, p);
    float d = b * b - c;
    if (d < 0.0) return vec2(-1e10, 1e10);
    d = sqrt(d);
    return vec2(-b + d, -b - d);
}

vec3 RayPlaneIntersection_p(vec3 ori, vec3 dir, vec3 normal) {
    float rayPlaneAngle = dot(dir, normal);
    float planeRayDist = 1e8;
    vec3 intersectionPos = dir * planeRayDist;
    if (rayPlaneAngle > 0.0001 || rayPlaneAngle < -0.0001) {
        planeRayDist = dot(-ori, normal) / rayPlaneAngle;
        intersectionPos = ori + dir * planeRayDist;
    }
    return intersectionPos;
}

vec3 H_p(vec3 albedo, float a) {
    a = max(a, 0.001);
    vec3 R = sqrt(vec3(1.0) - clamp(albedo, 0.001, 0.999));
    vec3 r = (1.0 - R) / (1.0 + R);
    vec3 H = r + (0.5 - r * a) * log((1.0 + a) / a);
    H *= albedo * a;
    return 1.0 / (1.0 - clamp(H, 0.0, 0.99));
}

vec3 ppss_p(vec3 albedo, vec3 normal, vec3 eyeDir, vec3 lightDir, float s) {
    float NdotL = dot(normal, lightDir);
    float NdotV = dot(normal, eyeDir);
    albedo *= curve_p(saturate_p(NdotL));
    NdotL = max(NdotL, 0.001);
    NdotV = max(NdotV, 0.001);
    vec3 color = albedo * H_p(albedo, NdotL) * H_p(albedo, NdotV) / (4.0 * PI * (NdotL + NdotV));
    return clamp(color, 0.0, 1.0);
}

float Disc_p(float a, float s, float h) {
    float disc = curve_p(saturate_p((a - (1.0 - s)) * h));
    return disc * disc;
}

float MiePhase_p(float g, float cosTheta) {
    float g2 = g * g;
    return (1.0 - g2) / (4.0 * PI * pow(1.0 + g2 - 2.0 * g * cosTheta, 1.5));
}

void PlanetEnd2(inout vec3 color, in vec3 eyeIn, in vec3 rayDir, in vec3 lightDir) {
    float Rground = 20e6;
    vec3 eye = vec3(0.0);
    eye.y += Rground;
    eye.y += 15e6;

    float VdotL = dot(lightDir, rayDir);

    float angleX = -1.8;
    float angleY = 3.0;

    mat3 eyeRotationMatrixX = mat3(1, 0, 0, 0, cos(angleX), -sin(angleX), 0, sin(angleX), cos(angleX));
    mat3 eyeRotationMatrixY = mat3(cos(angleY), 0, sin(angleY), 0, 1, 0, -sin(angleY), 0, cos(angleY));
    mat3 eyeRotationMatrix = eyeRotationMatrixX * eyeRotationMatrixY;

    float ringAngle = 0.008;

    mat3 ringRotationMatrix = mat3(1.0, 0.0, 0.0,
                                   0.0, cos(ringAngle), sin(ringAngle),
                                   0.0, -sin(ringAngle), cos(ringAngle));
    mat3 ringRotationMatrixInverse = transpose(ringRotationMatrix);

    rayDir = eyeRotationMatrix * rayDir;
    lightDir = eyeRotationMatrix * lightDir;

    vec3 rayDirRing = ringRotationMatrix * rayDir;
    vec3 lightDirRing = ringRotationMatrix * lightDir;

    vec3 ringOrigin = vec3(0.0, cos(ringAngle), sin(ringAngle)) * (eye.y / Rground);
    vec2 ringRadius = vec2(1.6, 2.6);

    vec3 surface = vec3(0.0);

    vec2 RgroundIntersection = RaySphereIntersectionIO_p(eye, rayDir, Rground);
    if (RgroundIntersection.x > 0.0) {
        color *= 0.0;
        vec3 surfacePos = rayDir * RgroundIntersection.y;
        vec3 surfaceNormal = normalize(surfacePos - vec3(0.0, -eye.y, 0.0));
        vec3 surfaceAlbedo = vec3(1.0, 0.87, 0.55);

        // Simple diffuse lighting - ACTUALLY VISIBLE
        float NdotL = max(dot(surfaceNormal, lightDir), 0.0);
        surface = surfaceAlbedo * (NdotL * 0.7 + 0.3);

        vec3 origin = ringOrigin + surfacePos / Rground;
        vec3 rayPos = RayPlaneIntersection_p(origin, lightDirRing, vec3(0.0, 0.0, 1.0));
        float rayRadiusShadow = length(rayPos);

        if (rayRadiusShadow > ringRadius.x && rayRadiusShadow < ringRadius.y && dot(rayPos - origin, lightDirRing) > 0.0) {
            float accum = 0.0;
            float alpha = 0.5;
            float position = rayRadiusShadow * 0.5 + 0.69;
            for (int i = 0; i < 5; i++) {
                accum += alpha * texture(noisetex, vec2(position, 0.0)).z;
                position = position * 4.0;
                alpha *= 0.5;
            }
            float octShift = 0.025;
            surface *= exp(-pow(saturate_p(accum + octShift - 0.1) * 1.5, 3.0) * smoothstep(ringRadius.x, ringRadius.x * 1.1, rayRadiusShadow));
        }

        float UdotN = saturate_p(dot(ringRotationMatrixInverse[2], surfaceNormal));
        float DdotN = saturate_p(dot(-ringRotationMatrixInverse[2], surfaceNormal));
        float OLdotN = saturate_p(dot(ringRotationMatrixInverse * normalize(vec3(-lightDir.xy, 0.0)), surfaceNormal));

        float ringLighting = Disc_p(UdotN, 1.2, 1.5) * (1.0 - Disc_p(UdotN, 3.4, 0.3));
        ringLighting += Disc_p(DdotN, 1.2, 1.5) * (1.0 - Disc_p(DdotN, 3.4, 0.3));
        ringLighting *= 1.0 - Disc_p(OLdotN, 0.7, 1.3);

        surface += surfaceAlbedo * (0.01 + ringLighting * 0.7);
    }

    color += surface * 0.5;  // Much brighter output

    vec3 ring = vec3(0.0);

    // Always check for ring (removed restrictive condition)
    {
        vec3 origin = vec3(0.0, cos(ringAngle), sin(ringAngle)) * (eye.y / Rground);
        vec3 ringPos = RayPlaneIntersection_p(origin, rayDirRing, vec3(0.0, 0.0, 1.0));
        float rayRadiusRing = length(ringPos);

        if (rayRadiusRing > ringRadius.x && rayRadiusRing < ringRadius.y) {
            // Simple procedural ring pattern (doesn't rely on noisetex)
            float ringNorm = (rayRadiusRing - ringRadius.x) / (ringRadius.y - ringRadius.x);
            float pattern = sin(rayRadiusRing * 15.0) * 0.2 + 0.7;
            pattern *= smoothstep(0.0, 0.1, ringNorm);
            pattern *= smoothstep(1.0, 0.9, ringNorm);

            ring = vec3(pattern);

            if (ringPos.y < 0.0 && RgroundIntersection.x > 0.0) {
                ring *= 0.0;
            } else {
                color *= exp(-ring * 1.5);
            }

            float d = length(cross(lightDirRing, ringPos));
            if (d < 1.0 && dot(lightDirRing, ringPos) < 0.0) ring *= 0.1;
        }
    }
    ring *= vec3(1.0, 0.85, 0.60) * (1.0 + MiePhase_p(0.8, VdotL) * 10.0);

    color += ring * 0.3;  // Much brighter rings
}
#endif // RINGED_PLANET_ENABLED

// ============================================================================
// === END DIMENSION SKY ===
// ============================================================================
#ifdef END_SKY_ENABLED

// --- End Star Field (always visible, colored) ---
#ifdef END_STARS_ENABLED
vec3 endStarField(vec3 dir, float time) {
    dir = normalize(dir);
    vec2 starUV = cubeProject(dir) * STAR_SCALE;

    vec2 cell = floor(starUV);
    vec2 local = fract(starUV);

    vec3 result = vec3(0.0);

    for (int x = -1; x <= 1; x++) {
        for (int y = -1; y <= 1; y++) {
            vec2 nc = cell + vec2(float(x), float(y));

            float rnd = hash21(nc);
            if (rnd > END_STAR_DENSITY) continue;

            vec2 sp = hash22(nc) * 0.6 + 0.2;
            vec2 d = local - vec2(float(x), float(y)) - sp;
            float dist = length(d);

            float baseBright = 0.4 + hash21(nc + 500.0) * 0.6;

            // Twinkling
            float twinklePhase = hash21(nc + 700.0) * 6.28318;
            float twinkleSpeed = 0.5 + hash21(nc + 800.0) * 2.0;
            float twinkle = 0.7 + 0.3 * sin(time * twinkleSpeed + twinklePhase);

            float bright = baseBright * twinkle * END_STAR_BRIGHTNESS;

            float radius = STAR_SIZE * (0.5 + hash21(nc + 400.0) * 0.5);
            float s = 1.0 - smoothstep(0.0, radius, dist);

            // Color variation: white -> purple/blue/teal
            vec3 sColor = vec3(1.0);
            if (END_STAR_COLOR_SHIFT > 0.0) {
                float colorRnd = hash21(nc + 1000.0);
                vec3 tint;
                if (colorRnd < 0.3) {
                    tint = vec3(0.7, 0.5, 1.0);       // purple
                } else if (colorRnd < 0.55) {
                    tint = vec3(0.4, 0.7, 1.0);       // blue
                } else if (colorRnd < 0.75) {
                    tint = vec3(0.3, 0.9, 0.8);       // teal
                } else {
                    tint = vec3(1.0, 0.95, 0.9);      // warm white
                }
                sColor = mix(vec3(1.0), tint, END_STAR_COLOR_SHIFT);
            }

            result = max(result, sColor * s * bright);
        }
    }

    return result;
}
#endif // END_STARS_ENABLED

// --- End Nebula (wispy cosmic clouds) ---
#ifdef END_NEBULA_ENABLED
vec3 endNebula(vec3 dir, float time) {
    // Spherical coordinates for seamless wrapping
    vec2 uv = vec2(atan(dir.z, dir.x), asin(clamp(dir.y, -1.0, 1.0)));
    uv *= END_NEBULA_SCALE;

    // Slow drift with subtle rotation
    float drift = time * END_NEBULA_SPEED;
    vec2 uv1 = uv + vec2(drift, drift * 0.3);
    vec2 uv2 = uv + vec2(-drift * 0.7, drift * 0.5);

    // Large-scale swirling structure (low frequency for big clouds)
    float largeClouds = fbm(uv1 * 0.6, 5);
    float largeClouds2 = fbm(uv2 * 0.8 + vec2(50.0, 25.0), 4);

    // Medium detail
    float medDetail = fbm(uv1 * 1.2 + vec2(100.0, 50.0), 4);

    // Color separation layer (slow-moving)
    float colorLayer = fbm(uv * 0.4 + vec2(-30.0, 80.0) + drift * 0.3, 3);

    // Voronoi for filament/dust lane structure
    float v = voronoiNoise(uv1 * 2.0);

    // Build cloud mask ? wide, sweeping formations
    float nebulaMask = smoothstep(0.20, 0.55, largeClouds);
    nebulaMask *= 0.5 + 0.5 * smoothstep(0.15, 0.50, largeClouds2);

    // Add medium detail structure
    nebulaMask *= 0.6 + 0.4 * smoothstep(0.25, 0.60, medDetail);

    // Filamentary wisps from voronoi (softer)
    nebulaMask *= 0.6 + 0.4 * (1.0 - smoothstep(0.0, 0.5, v));

    // Brighten core regions
    float coreGlow = smoothstep(0.50, 0.80, largeClouds) * 0.5;
    nebulaMask += coreGlow;

    // Two-tone color blending
    vec3 color1 = vec3(END_NEBULA_R1, END_NEBULA_G1, END_NEBULA_B1);
    vec3 color2 = vec3(END_NEBULA_R2, END_NEBULA_G2, END_NEBULA_B2);
    float colorMix = smoothstep(0.3, 0.7, colorLayer);
    vec3 nebulaColor = mix(color1, color2, colorMix);

    // Add subtle bright white highlights in densest regions
    vec3 highlight = vec3(0.7, 0.6, 0.9) * smoothstep(0.70, 0.95, largeClouds) * 0.3;

    return (nebulaColor * nebulaMask + highlight) * END_NEBULA_INTENSITY;
}
#endif // END_NEBULA_ENABLED

// --- End Aurora / Void Shimmer (vertical energy curtains) ---
#ifdef END_AURORA_ENABLED
vec3 endAurora(vec3 dir, float time) {
    float elevation = dir.y;
    if (elevation < 0.02) return vec3(0.0);

    // Height mask: aurora appears in a wide vertical band
    float heightMask = smoothstep(0.02, END_AURORA_HEIGHT * 0.3, elevation)
                     * smoothstep(END_AURORA_HEIGHT + 0.3, END_AURORA_HEIGHT * 0.5, elevation);

    float angle = atan(dir.z, dir.x);

    // Multiple overlapping curtains with different speeds and frequencies
    float curtain1 = sin(angle * 3.0 + time * END_AURORA_SPEED * 0.7) * 0.5 + 0.5;
    float curtain2 = sin(angle * 5.0 - time * END_AURORA_SPEED * 1.1 + 2.0) * 0.5 + 0.5;
    float curtain3 = sin(angle * 7.0 + time * END_AURORA_SPEED * 0.4 + 4.5) * 0.5 + 0.5;
    float curtain4 = sin(angle * 2.0 + time * END_AURORA_SPEED * 0.9 + 1.0) * 0.5 + 0.5;

    // Noise-based waviness along elevation
    float waveNoise = simplexNoise(vec2(angle * 2.0, time * END_AURORA_SPEED * 0.3));
    float wave = sin(elevation * 12.0 + waveNoise * 4.0 + time * END_AURORA_SPEED) * 0.5 + 0.5;

    // Vertical streaking effect
    float vertStreak = simplexNoise(vec2(angle * 4.0 + time * 0.05, elevation * 8.0));
    vertStreak = smoothstep(0.1, 0.6, vertStreak);

    // Combine curtains with vertical streaks
    float auroraShape = curtain1 * curtain2 * 0.5 + curtain3 * 0.3 + curtain4 * 0.2;
    auroraShape *= wave;
    auroraShape *= 0.6 + 0.4 * vertStreak;
    auroraShape = pow(auroraShape, 1.5); // Softer than before

    // Color shift along the curtain
    vec3 color1 = vec3(END_AURORA_R1, END_AURORA_G1, END_AURORA_B1);
    vec3 color2 = vec3(END_AURORA_R2, END_AURORA_G2, END_AURORA_B2);
    float colorPhase = sin(angle * 2.0 + time * END_AURORA_SPEED * 0.2) * 0.5 + 0.5;
    vec3 auroraColor = mix(color1, color2, colorPhase);

    return auroraColor * auroraShape * heightMask * END_AURORA_INTENSITY;
}
#endif // END_AURORA_ENABLED

// --- End Void Particles (floating emissive specks) ---
#ifdef END_VOID_PARTICLES_ENABLED
vec3 endVoidParticles(vec3 dir, float time) {
    dir = normalize(dir);
    vec2 particleUV = cubeProject(dir) * 30.0; // Dense grid

    vec2 cell = floor(particleUV);
    vec2 local = fract(particleUV);

    vec3 result = vec3(0.0);

    for (int x = -1; x <= 1; x++) {
        for (int y = -1; y <= 1; y++) {
            vec2 nc = cell + vec2(float(x), float(y));

            float rnd = hash21(nc + vec2(200.0, 300.0));
            if (rnd > END_VOID_PARTICLE_DENSITY) continue;

            vec2 sp = hash22(nc + vec2(200.0, 300.0)) * 0.6 + 0.2;

            // Pulsing brightness
            float pulsePhase = hash21(nc + vec2(500.0, 600.0)) * 6.28318;
            float pulseSpeed = 0.3 + hash21(nc + vec2(700.0, 800.0)) * 1.5;
            float pulse = 0.5 + 0.5 * sin(time * pulseSpeed + pulsePhase);

            // Slow drift
            float driftX = sin(time * 0.1 + pulsePhase) * 0.02;
            float driftY = cos(time * 0.08 + pulsePhase * 1.3) * 0.02;

            vec2 d = local - vec2(float(x), float(y)) - sp + vec2(driftX, driftY);
            float dist = length(d);

            // Small, soft point
            float particle = 1.0 - smoothstep(0.0, 0.04, dist);
            particle *= pulse;

            // Color: purple <-> cyan
            float hueRnd = hash21(nc + vec2(900.0, 100.0));
            vec3 pColor = mix(vec3(0.6, 0.2, 1.0), vec3(0.2, 0.8, 0.9), hueRnd);

            result += pColor * particle * END_VOID_PARTICLE_BRIGHTNESS * 0.3;
        }
    }

    return result;
}
#endif // END_VOID_PARTICLES_ENABLED

// --- Master End Sky Renderer ---
vec3 renderEndSky(vec3 worldDir, float time) {
    float height = applySkyGradientCurve(max(worldDir.y, 0.0));

    vec3 horizonColor = vec3(END_SKY_HORIZON_R, END_SKY_HORIZON_G, END_SKY_HORIZON_B);
    vec3 midColor = vec3(END_SKY_MID_R, END_SKY_MID_G, END_SKY_MID_B);
    vec3 zenithColor = vec3(END_SKY_ZENITH_R, END_SKY_ZENITH_G, END_SKY_ZENITH_B);

    // Use existing blendSkyLayers for smooth gradient
    vec3 sky = blendSkyLayers(horizonColor, midColor, zenithColor, height, 0.25, 0.65);

    // Below horizon: fade toward fog color (void mist)
    if (worldDir.y < 0.0) {
        float belowFade = smoothstep(0.0, -0.4, worldDir.y);
        #ifdef END_FOG_ENABLED
        vec3 voidColor = vec3(END_FOG_R, END_FOG_G, END_FOG_B);
        #else
        vec3 voidColor = horizonColor * 0.3;
        #endif
        sky = mix(horizonColor, voidColor, belowFade);
    }

    sky *= END_SKY_BRIGHTNESS;

    // Layer 1: Dense star field (always visible, no time-of-day gating)
    #ifdef END_STARS_ENABLED
    sky += endStarField(worldDir, time);
    #endif

    // Layer 2: Nebula
    #ifdef END_NEBULA_ENABLED
    sky += endNebula(worldDir, time);
    #endif

    // Layer 3: Aurora / void shimmer
    #ifdef END_AURORA_ENABLED
    sky += endAurora(worldDir, time);
    #endif

    // Layer 4: Void particles
    #ifdef END_VOID_PARTICLES_ENABLED
    sky += endVoidParticles(worldDir, time);
    #endif

    return sky;
}

#endif // END_SKY_ENABLED

// ============================================================================
// 2D Stylized Clouds
// ============================================================================
#ifdef CLOUDS_2D_ENABLED

// Smooth noise for clouds
float cloudNoise(vec2 p) {
    vec2 i = floor(p);
    vec2 f = fract(p);
    f = f * f * (3.0 - 2.0 * f); // Smoothstep
    
    float a = hash21(i);
    float b = hash21(i + vec2(1.0, 0.0));
    float c = hash21(i + vec2(0.0, 1.0));
    float d = hash21(i + vec2(1.0, 1.0));
    
    return mix(mix(a, b, f.x), mix(c, d, f.x), f.y);
}

// FBM (Fractal Brownian Motion) for cloud shapes
float cloudFBM(vec2 p) {
    float value = 0.0;
    float amplitude = 0.5;
    float frequency = 1.0;
    
    for (int i = 0; i < 5; i++) {
        value += amplitude * cloudNoise(p * frequency);
        amplitude *= 0.5;
        frequency *= 2.0;
    }
    
    return value;
}

// Sample cloud density at a world position (for both sky and shadows)
float sampleCloudDensity(vec2 worldXZ, float time) {
    // Circular wind: Clouds move in a large circle (radius 2500)
    // This creates a consistent arc path everywhere in the world
    float r = 2500.0;
    float speed = CLOUD_SPEED * 3.0; // Convert to roughly blocks/sec
    float angle = time * speed / r;
    vec2 offset = vec2(cos(angle), sin(angle)) * r;
    
    vec2 cloudPos = (worldXZ + offset) * CLOUD_SCALE;
    
    float noise = cloudFBM(cloudPos);
    
    // Apply coverage threshold
    float density = smoothstep(1.0 - CLOUD_COVERAGE, 1.0 - CLOUD_COVERAGE + 0.3, noise);
    
    #if CLOUD_TOON_EDGES == 1
    // Hard edge for toon look
    density = step(0.3, density);
    #endif
    
    return density;
}

// Render clouds for sky view
vec4 render2DClouds(vec3 worldDir, vec3 camPos, float time, float sunAngle) {
    // Only render above horizon
    if (worldDir.y < 0.01) return vec4(0.0);
    
    // Ray-plane intersection with cloud layer
    float t = ((CLOUD_HEIGHT + SEA_LEVEL_OFFSET) - camPos.y) / worldDir.y;
    
    // If looking away from cloud layer (camera above clouds looking up)
    if (t < 0.0) return vec4(0.0);
    
    // Limit render distance
    if (t > 50000.0) return vec4(0.0);
    
    // World position where ray hits cloud plane
    vec2 cloudWorldPos = camPos.xz + worldDir.xz * t;
    
    // Sample main cloud
    float density = sampleCloudDensity(cloudWorldPos, time);
    
    if (density < 0.01) return vec4(0.0);
    
    // Parallax for thickness illusion - sample slightly offset layer
    vec2 offsetPos = cloudWorldPos + worldDir.xz * CLOUD_THICKNESS * 0.5 / max(worldDir.y, 0.1);
    float density2 = sampleCloudDensity(offsetPos, time);
    
    // Combine for depth
    float finalDensity = max(density, density2 * 0.7);
    
    // Sun direction for lighting
    float dayTime = fract(sunAngle);
    float sunHeight = sin(dayTime * 6.28318);
    
    // Cloud colors based on time of day
    vec3 cloudLit, cloudShadow;
    
    // Sunrise/sunset detection
    float sunsetFactor = smoothstep(0.0, 0.15, abs(sunHeight)) * (1.0 - smoothstep(0.15, 0.3, abs(sunHeight)));
    float nightFactor = 1.0 - smoothstep(-0.10, 0.05, sunHeight);
    
    // Day colors
    cloudLit = vec3(1.0, 1.0, 1.0) * CLOUD_BRIGHTNESS;
    cloudShadow = vec3(CLOUD_SHADOW_R, CLOUD_SHADOW_G, CLOUD_SHADOW_B);
    
    // Sunset/sunrise tint
    vec3 sunsetLit = vec3(1.0, 0.7, 0.5) * CLOUD_BRIGHTNESS;
    vec3 sunsetShadow = vec3(0.8, 0.4, 0.5);
    cloudLit = mix(cloudLit, sunsetLit, sunsetFactor);
    cloudShadow = mix(cloudShadow, sunsetShadow, sunsetFactor);
    
    // Night colors
    vec3 nightLit = vec3(0.15, 0.18, 0.25);
    vec3 nightShadow = vec3(0.05, 0.08, 0.12);
    cloudLit = mix(cloudLit, nightLit, nightFactor);
    cloudShadow = mix(cloudShadow, nightShadow, nightFactor);
    
    // Simple lighting - brighter on sun-facing side
    float r = 2500.0;
    float speed = CLOUD_SPEED * 3.0;
    float angle = time * speed / r;
    vec2 offset = vec2(cos(angle), sin(angle)) * r;
    
    float lightGradient = cloudNoise((cloudWorldPos + offset) * CLOUD_SCALE * 0.5);
    // Keep cloud shadows stylized but avoid full black cloud overlays.
    vec3 cloudShadowSafe = max(cloudShadow, cloudLit * 0.28);
    vec3 cloudColor = mix(cloudShadowSafe, cloudLit, lightGradient);
    
    // Edge glow during sunset
    float edgeFactor = smoothstep(0.0, 0.5, finalDensity) * (1.0 - smoothstep(0.5, 1.0, finalDensity));
    cloudColor += vec3(1.0, 0.5, 0.2) * edgeFactor * sunsetFactor * 0.5;
    
    // Soften horizon transition only by view angle.
    // Using ray distance here creates a circular "dome cutoff" around zenith.
    float horizonFade = smoothstep(-0.02, 0.16, worldDir.y);
    finalDensity *= horizonFade;
    
    return vec4(cloudColor, finalDensity);
}
#endif // CLOUDS_2D_ENABLED && !CLOUDS_3D_ENABLED && !CLOUDS_VANILLA_ENABLED

// ============================================================================
// === NIGHT NEBULA (overworld colored sky patches) ===
// ============================================================================
#ifdef NIGHT_NEBULA_ENABLED
// 3D smooth noise ? no seam anywhere on the sphere
float noise3D(vec3 p) {
    vec3 i = floor(p);
    vec3 f = fract(p);
    f = f * f * (3.0 - 2.0 * f);
    return mix(
        mix(mix(hash21(i.xy + i.z * 7.3), hash21(i.xy + vec2(1,0) + i.z * 7.3), f.x),
            mix(hash21(i.xy + vec2(0,1) + i.z * 7.3), hash21(i.xy + vec2(1,1) + i.z * 7.3), f.x), f.y),
        mix(mix(hash21(i.xy + (i.z+1.0) * 7.3), hash21(i.xy + vec2(1,0) + (i.z+1.0) * 7.3), f.x),
            mix(hash21(i.xy + vec2(0,1) + (i.z+1.0) * 7.3), hash21(i.xy + vec2(1,1) + (i.z+1.0) * 7.3), f.x), f.y),
        f.z);
}

float fbm3D(vec3 p, int octaves) {
    float v = 0.0, a = 0.5;
    for (int i = 0; i < octaves; i++) {
        v += a * noise3D(p);
        p *= 2.0; a *= 0.5;
    }
    return v;
}

vec3 nightNebula(vec3 dir, float time) {
    vec3 d = normalize(dir);
    float scale = NIGHT_NEBULA_SCALE * 2.0;
    float drift = time * NIGHT_NEBULA_SPEED;

    // Sample noise directly on the sphere direction ? zero seams
    vec3 p1 = d * scale + vec3(drift * 0.4, drift * 0.15, 0.0);
    vec3 p2 = d * scale * 1.4 + vec3(31.7, 17.3, 5.1) + vec3(-drift * 0.25, drift * 0.35, 0.0);
    vec3 p3 = d * scale * 0.3 + vec3(-50.0, 25.0, 12.3) + drift * 0.08;

    float large1    = fbm3D(p1, 4);
    float large2    = fbm3D(p2, 3);
    float colorLayer = fbm3D(p3, 3);

    // Mask
    float mask = smoothstep(0.28, 0.60, large1);
    mask *= 0.55 + 0.45 * large2;
    mask  = max(mask, smoothstep(0.50, 0.80, large1) * 0.5);

    // Height fade: above horizon only
    float heightFade = smoothstep(-0.05, 0.18, d.y)
                     * (1.0 - smoothstep(0.88, 1.00, d.y));
    mask *= heightFade;

    // Two-color blend
    vec3 col1 = vec3(NIGHT_NEBULA_R1, NIGHT_NEBULA_G1, NIGHT_NEBULA_B1);
    vec3 col2 = vec3(NIGHT_NEBULA_R2, NIGHT_NEBULA_G2, NIGHT_NEBULA_B2);
    vec3 nebulaColor = mix(col1, col2, smoothstep(0.3, 0.7, colorLayer));
    nebulaColor += vec3(0.5, 0.4, 0.8) * smoothstep(0.65, 0.85, large1) * 0.35;

    return nebulaColor * mask * NIGHT_NEBULA_INTENSITY;
}
#endif // NIGHT_NEBULA_ENABLED

// ============================================================================
// === NIGHT ASTEROIDS (fast streaking rocks across the sky) ===
// ============================================================================
#ifdef NIGHT_ASTEROIDS_ENABLED
vec3 nightAsteroids(vec3 dir, float time) {
    dir = normalize(dir);
    dir = celestialRotate(dir);

    vec3 result = vec3(0.0);

    for (int i = 0; i < NIGHT_ASTEROID_COUNT; i++) {
        float slot = float(i) * 47.3;

        // Staggered cycle per slot ? each fires independently
        float cycleLen = NIGHT_ASTEROID_INTERVAL * (0.5 + hash11(slot) * 1.0);
        float t = mod(time + slot * 37.1, cycleLen);

        // Active for a slower, longer pass than shooting stars
        float duration = 1.5 + hash11(slot + 10.0) * 2.0;
        if (t > duration) continue;

        // Random start on upper hemisphere
        float startPhi   = hash11(slot + 20.0) * 6.28318;
        float startTheta = 0.15 + hash11(slot + 30.0) * 0.65;
        vec3 startDir = vec3(
            cos(startPhi) * cos(startTheta),
            sin(startTheta),
            sin(startPhi) * cos(startTheta)
        );

        // Travel direction ? slightly downward like a real meteor
        float travelAngle = hash11(slot + 40.0) * 6.28318;
        float travelDip   = -0.2 - hash11(slot + 45.0) * 0.3;
        vec3 travelDir    = normalize(vec3(cos(travelAngle), travelDip, sin(travelAngle)));

        // Slower than shooting stars ? feels heavier
        float speed     = NIGHT_ASTEROID_SPEED * (0.6 + hash11(slot + 50.0) * 0.8);
        vec3 currentPos = startDir + travelDir * t * speed;
        currentPos      = normalize(currentPos);

        // Same trail projection as shootingStar (proven geometry)
        vec3  toViewer  = dir - currentPos;
        float along     = dot(toViewer, travelDir);
        float perpDist  = length(toViewer - travelDir * along);

        float trailLen  = NIGHT_ASTEROID_LENGTH * (0.7 + hash11(slot + 60.0) * 0.6);
        float progress  = t / duration;

        float burnOut = 1.0 - smoothstep(0.5, 1.0, progress);

        // Trail: narrow rectangle behind the head
        if (perpDist < NIGHT_ASTEROID_THICKNESS && along > -trailLen && along < 0.002) {
            float intensity = (1.0 - perpDist / NIGHT_ASTEROID_THICKNESS);
            intensity *= smoothstep(-trailLen, -trailLen * 0.1, along); // fade toward tail
            intensity *= burnOut * NIGHT_ASTEROID_BRIGHTNESS;

            float heatRamp = clamp(-along / max(trailLen, 0.001), 0.0, 1.0);
            float personality = hash11(slot + 70.0);
            vec3 midColor  = mix(vec3(1.0, 0.55, 0.15), vec3(0.8, 0.65, 1.0), personality);
            vec3 asteroidColor = mix(vec3(1.0, 0.97, 0.85), mix(midColor, vec3(0.55, 0.20, 0.04), heatRamp * 0.7), heatRamp);
            result += asteroidColor * intensity;
        }

        // Head: circular radial glow at currentPos
        float headDist = length(dir - currentPos);
        float headGlow = 1.0 - smoothstep(0.0, NIGHT_ASTEROID_THICKNESS * 2.5, headDist);
        headGlow = headGlow * headGlow; // sharpen
        headGlow *= burnOut * NIGHT_ASTEROID_BRIGHTNESS * 1.5;
        result += vec3(1.0, 0.97, 0.90) * headGlow;
    }

    return result;
}
#endif // NIGHT_ASTEROIDS_ENABLED

// Apply saturation adjustment
vec3 applySaturation(vec3 color, float satMult) {
    vec3 hsv = rgb2hsv(color);
    hsv.y = clamp(hsv.y * satMult, 0.0, 1.0);
    return hsv2rgb(hsv);
}

// Apply user sky gradient curve.
// Higher curve => faster transition to zenith => narrower horizon band.
float applySkyGradientCurve(float h) {
    float x = clamp(h, 0.0, 1.0);
    float curve = max(SKY_GRADIENT_CURVE, 0.001);
    return pow(x, 1.0 / curve);
}

// Biome layer blend for the current 3-layer sky system.
// Directly blends layer RGB values instead of applying a multiplicative color filter.
vec3 applyBiomeLayerBlend(vec3 baseColor, vec3 biomeColor, float amount) {
    return mix(baseColor, biomeColor, clamp(amount, 0.0, 1.0));
}

// Heuristic for custom/server dimensions that intentionally have no sky.
bool isSkylessWorldHeuristic() {
    float sunLen = length(sunPosition);
    float shadowLen = length(shadowLightPosition);
    vec3 skyMax = max(skyColor, vec3(0.0));
    vec3 fogMax = max(fogColor, vec3(0.0));
    float skyPeak = max(max(skyMax.r, skyMax.g), skyMax.b);
    float fogPeak = max(max(fogMax.r, fogMax.g), fogMax.b);
    bool noDirectionalLight = (sunLen < 0.001 && shadowLen < 0.001);
    bool darkFlatAtmosphere = (skyPeak < 0.06 && fogPeak < 0.08);
    return darkFlatAtmosphere && noDirectionalLight;
}

void main() {
    // Keep zenith/background intact; star suppression is handled in skytextured pass.
    
    // Use sky vertex direction (translation-free from vsh) for stable gradients.
    vec3 viewDir = normalize(viewPos);
    vec3 worldDir = normalize(mat3(gbufferModelViewInverse) * viewDir);

    // Nether: fill sky with per-biome fog color so VFOG covers it seamlessly
    #ifdef NETHER_FOG_ENABLED
    if (isForcedNetherBiome(biome)) {
        vec3 netherSky = getForcedBiomeFogColor(biome, vec3(NETHER_FOG_R, NETHER_FOG_G, NETHER_FOG_B));
        gl_FragData[0] = vec4(netherSky * 0.15, 1.0);
        gl_FragData[1] = vec4(0.0);
        return;
    }
    #endif

    // End sky is handled by world1/gbuffers_skybasic.fsh via dimension.properties

    if (isSkylessWorldHeuristic()) {
        vec3 flatSky = max(fogColor, skyColor * 0.8);
        gl_FragData[0] = vec4(flatSky, 1.0);
        gl_FragData[1] = vec4(0.0);
        return;
    }

    float rawHeight = applySkyGradientCurve(max(worldDir.y, 0.0));
    float angle = fract(sunAngle);

    // Time phases tuned to reduce overlong sunrise/sunset windows.
    float isDay = smoothstep(0.02, 0.09, angle) * (1.0 - smoothstep(0.43, 0.50, angle));
    float twilight = smoothstep(0.44, 0.50, angle) * (1.0 - smoothstep(0.54, 0.60, angle))
                   + smoothstep(0.96, 1.0, angle) + (1.0 - smoothstep(0.0, 0.04, angle));
    float blueHour = smoothstep(0.53, 0.58, angle) * (1.0 - smoothstep(0.62, 0.69, angle));
    float isNight = smoothstep(0.61, 0.68, angle) * (1.0 - smoothstep(0.90, 0.98, angle));

    float rawDay = isDay;
    float rawTwilight = twilight;
    float rawBlueHour = blueHour;
    float rawNight = isNight;

    // Normalize weights
    float totalWeight = isDay + twilight + blueHour + isNight;
    if (totalWeight > 0.0001) {
        isDay /= totalWeight;
        twilight /= totalWeight;
        blueHour /= totalWeight;
        isNight /= totalWeight;
    } else {
        isDay = 1.0;
        twilight = 0.0;
        blueHour = 0.0;
        isNight = 0.0;
    }

    // Biome sky tint:
    // - use skyColor for zenith hue
    // - use fogColor for horizon hue
    // - apply mostly during daytime to avoid transition flicker
    // Base colors: configured daytime palette.
    vec3 baseDayHorizon = vec3(DAY_HORIZON_R, DAY_HORIZON_G, DAY_HORIZON_B);
    vec3 baseDayMid = vec3(DAY_MID_R, DAY_MID_G, DAY_MID_B);
    vec3 baseDayZenith = vec3(DAY_ZENITH_R, DAY_ZENITH_G, DAY_ZENITH_B);
    vec3 biomeHorizon = baseDayHorizon;
    vec3 biomeMid = baseDayMid;
    vec3 biomeZenith = baseDayZenith;

    float wSnow = clamp(biome_snowy, 0.0, 1.0);
    float wJungle = clamp(biome_jungle, 0.0, 1.0);
    float wSwamp = clamp(biome_swamp, 0.0, 1.0);
    float wArid = clamp(biome_arid, 0.0, 1.0);

    if (wSnow > 0.001) {
        biomeHorizon = mix(biomeHorizon, vec3(230.0, 241.0, 252.0) / 255.0, wSnow);
        biomeMid = mix(biomeMid, vec3(184.0, 202.0, 242.0) / 255.0, wSnow);
        biomeZenith = mix(biomeZenith, vec3(176.0, 191.0, 245.0) / 255.0, wSnow);
    }
    if (wJungle > 0.001) {
        biomeHorizon = mix(biomeHorizon, vec3(81.0, 189.0, 92.0) / 255.0, wJungle);
        biomeMid = mix(biomeMid, vec3(154.0, 194.0, 110.0) / 255.0, wJungle);
        biomeZenith = mix(biomeZenith, vec3(122.0, 211.0, 255.0) / 255.0, wJungle);
    }
    if (wSwamp > 0.001) {
        biomeHorizon = mix(biomeHorizon, vec3(66.0, 128.0, 75.0) / 255.0, wSwamp);
        biomeMid = mix(biomeMid, vec3(83.0, 77.0, 102.0) / 255.0, wSwamp);
        biomeZenith = mix(biomeZenith, vec3(144.0, 199.0, 90.0) / 255.0, wSwamp);
    }
    if (wArid > 0.001) {
        biomeHorizon = mix(biomeHorizon, vec3(235.0, 213.0, 185.0) / 255.0, wArid);
        biomeMid = mix(biomeMid, vec3(214.0, 206.0, 224.0) / 255.0, wArid);
        biomeZenith = mix(biomeZenith, vec3(191.0, 198.0, 255.0) / 255.0, wArid);
    }

    bool hasForcedBiomeSky = (max(max(wSnow, wJungle), max(wSwamp, wArid)) > 0.001)
                          || isForcedSnowyBiome(biome) || isCategorySnowy(biome_category)
                          || isForcedJungleBiome(biome) || isCategoryJungle(biome_category)
                          || isForcedSwampyBiome(biome) || isCategorySwampy(biome_category)
                          || isForcedSavannaBiome(biome) || isCategorySavanna(biome_category)
                          || isForcedDesertBiome(biome) || isCategoryDesert(biome_category);
    // Datapack/custom biome fallback:
    // use runtime sky/fog colors only in daytime and only when they are clearly
    // different from configured day colors. This preserves the normal blue sky.
    float dynZenithDelta = length(skyColor - baseDayZenith);
    float dynHorizonDelta = length(fogColor - baseDayHorizon);
    float dynDelta = max(dynZenithDelta, dynHorizonDelta);
    // Looser detection so subtle datapack biome colors still apply.
    // Keep a small deadzone to preserve default blue sky where colors match.
    float dynBiomeWeight = smoothstep(0.03, 0.18, dynDelta);

    if (!hasForcedBiomeSky && dynBiomeWeight > 0.001) {
        vec3 dynHorizon = fogColor;
        vec3 dynZenith = skyColor;
        vec3 dynMid = mix(dynHorizon, dynZenith, 0.55);
        biomeHorizon = mix(biomeHorizon, dynHorizon, dynBiomeWeight);
        biomeMid = mix(biomeMid, dynMid, dynBiomeWeight);
        biomeZenith = mix(biomeZenith, dynZenith, dynBiomeWeight);
    }

    float biomeBlendStrength = hasForcedBiomeSky ? 1.0 : (SKY_BIOME_BLEND * dynBiomeWeight);
    float biomeTintStrengthDay = biomeBlendStrength;
    // Biome palette overrides are daytime-only.
    float biomeTintStrengthTwilight = 0.0;
    float biomeTintStrengthBlueHour = 0.0;
    float biomeTintStrengthNight = 0.0;

    // === DAY SKY (RGB from settings) ===
    vec3 dayHorizon = vec3(DAY_HORIZON_R, DAY_HORIZON_G, DAY_HORIZON_B);
    vec3 dayMid = vec3(DAY_MID_R, DAY_MID_G, DAY_MID_B);
    vec3 dayZenith = vec3(DAY_ZENITH_R, DAY_ZENITH_G, DAY_ZENITH_B);
    // Apply biome tint directly to current sky layers.
    dayHorizon = applyBiomeLayerBlend(dayHorizon, biomeHorizon, biomeTintStrengthDay);
    dayMid = applyBiomeLayerBlend(dayMid, biomeMid, biomeTintStrengthDay);
    dayZenith = applyBiomeLayerBlend(dayZenith, biomeZenith, biomeTintStrengthDay);
    // Apply saturation
    dayHorizon = applySaturation(dayHorizon, SKY_SATURATION);
    dayMid = applySaturation(dayMid, SKY_SATURATION);
    dayZenith = applySaturation(dayZenith, SKY_SATURATION);
    vec3 dayColor = blendSkyLayers(dayHorizon, dayMid, dayZenith, rawHeight, DAY_MID_HEIGHT, DAY_ZENITH_HEIGHT);

    // === SUNSET SKY (RGB from settings) ===
    vec3 sunsetHorizon = vec3(SUNSET_HORIZON_R, SUNSET_HORIZON_G, SUNSET_HORIZON_B);
    vec3 sunsetMid = vec3(SUNSET_MID_R, SUNSET_MID_G, SUNSET_MID_B);
    vec3 sunsetZenith = vec3(SUNSET_ZENITH_R, SUNSET_ZENITH_G, SUNSET_ZENITH_B);
    sunsetHorizon = applyBiomeLayerBlend(sunsetHorizon, biomeHorizon, biomeTintStrengthTwilight);
    sunsetMid = applyBiomeLayerBlend(sunsetMid, biomeMid, biomeTintStrengthTwilight);
    sunsetZenith = applyBiomeLayerBlend(sunsetZenith, biomeZenith, biomeTintStrengthTwilight);
    sunsetHorizon = applySaturation(sunsetHorizon, SKY_SATURATION);
    sunsetMid = applySaturation(sunsetMid, SKY_SATURATION);
    sunsetZenith = applySaturation(sunsetZenith, SKY_SATURATION);
    vec3 sunsetColor = blendSkyLayers(sunsetHorizon, sunsetMid, sunsetZenith, rawHeight, SUNSET_MID_HEIGHT, SUNSET_ZENITH_HEIGHT);

    // === BLUE HOUR SKY (RGB from settings) ===
    vec3 blueHorizon = vec3(BLUEHOUR_HORIZON_R, BLUEHOUR_HORIZON_G, BLUEHOUR_HORIZON_B);
    vec3 blueMid = vec3(BLUEHOUR_MID_R, BLUEHOUR_MID_G, BLUEHOUR_MID_B);
    vec3 blueZenith = vec3(BLUEHOUR_ZENITH_R, BLUEHOUR_ZENITH_G, BLUEHOUR_ZENITH_B);
    blueHorizon = applyBiomeLayerBlend(blueHorizon, biomeHorizon, biomeTintStrengthBlueHour);
    blueMid = applyBiomeLayerBlend(blueMid, biomeMid, biomeTintStrengthBlueHour);
    blueZenith = applyBiomeLayerBlend(blueZenith, biomeZenith, biomeTintStrengthBlueHour);
    blueHorizon = applySaturation(blueHorizon, SKY_SATURATION);
    blueMid = applySaturation(blueMid, SKY_SATURATION);
    blueZenith = applySaturation(blueZenith, SKY_SATURATION);
    vec3 blueHourColor = blendSkyLayers(blueHorizon, blueMid, blueZenith, rawHeight, BLUEHOUR_MID_HEIGHT, BLUEHOUR_ZENITH_HEIGHT);

    // === NIGHT SKY (RGB from settings) ===
    vec3 nightHorizon = vec3(NIGHT_HORIZON_R, NIGHT_HORIZON_G, NIGHT_HORIZON_B);
    vec3 nightMid = vec3(NIGHT_MID_R, NIGHT_MID_G, NIGHT_MID_B);
    vec3 nightZenith = vec3(NIGHT_ZENITH_R, NIGHT_ZENITH_G, NIGHT_ZENITH_B);
    nightHorizon = applyBiomeLayerBlend(nightHorizon, biomeHorizon, biomeTintStrengthNight);
    nightMid = applyBiomeLayerBlend(nightMid, biomeMid, biomeTintStrengthNight);
    nightZenith = applyBiomeLayerBlend(nightZenith, biomeZenith, biomeTintStrengthNight);
    nightHorizon = applySaturation(nightHorizon, SKY_SATURATION);
    nightMid = applySaturation(nightMid, SKY_SATURATION);
    nightZenith = applySaturation(nightZenith, SKY_SATURATION);
    vec3 nightColor = blendSkyLayers(nightHorizon, nightMid, nightZenith, rawHeight, NIGHT_MID_HEIGHT, NIGHT_ZENITH_HEIGHT);

    // === FINAL BLEND ===
    vec3 dayFinal = dayColor * DAY_BRIGHTNESS;
    float sunsetBrightnessFade = smoothstep(0.06, 0.35, rawTwilight);
    float sunsetBrightness = mix(1.0, SUNSET_BRIGHTNESS, sunsetBrightnessFade);
    vec3 sunsetFinal = sunsetColor * sunsetBrightness;
    vec3 blueFinal = blueHourColor * BLUEHOUR_BRIGHTNESS;
    vec3 nightFinal = nightColor * NIGHT_BRIGHTNESS;
    
    // Weighted blend
    vec3 color = dayFinal * isDay
               + sunsetFinal * twilight  
               + blueFinal * blueHour
               + nightFinal * isNight;

    // Boost saturation during transitions to prevent muddy colors
    float transitionAmount = 1.0 - max(max(isDay, twilight), max(blueHour, isNight));
    transitionAmount = max(transitionAmount, min(isDay, twilight) * 2.0);
    transitionAmount = max(transitionAmount, min(twilight, blueHour) * 2.0);
    transitionAmount = max(transitionAmount, min(blueHour, isNight) * 2.0);
    
    if (transitionAmount > 0.01) {
        vec3 hsv = rgb2hsv(color);
        hsv.y = min(hsv.y * (1.0 + transitionAmount * 0.22), 1.0);
        hsv.z = min(hsv.z * (1.0 + transitionAmount * 0.06), 1.0);
        color = hsv2rgb(hsv);
    }

    // === STARS ===
    #ifdef STARS_ENABLED
    // Stars only visible at night/blue hour, and above horizon
    // Fade out with rain so weather fog covers the night sky (matches cloud fade timing)
    float starRainFade = 1.0 - smoothstep(0.15, 0.70, rainStrength);
    float nightVisibility = (isNight + blueHour * 0.5) * starRainFade;
    if (nightVisibility > 0.01 && worldDir.y > -0.1) {
        // Regular stars with twinkling
        float stars = starField(worldDir, frameTimeCounter);

        // Fade stars near horizon
        float horizonFade = smoothstep(-0.1, 0.15, worldDir.y);

        // Add stars
        color += vec3(stars) * nightVisibility * horizonFade;

        // Shooting stars (only at night)
        #ifdef STAR_SHOOTING_ENABLED
        if (isNight > 0.5) {
            vec3 shootingStars = shootingStar(worldDir, frameTimeCounter);
            color += shootingStars * horizonFade * starRainFade;
        }
        #endif
    }
    #endif

    // === NIGHT NEBULA (colored patches) ===
    #ifdef NIGHT_NEBULA_ENABLED
    {
        float starRainFadeN = 1.0 - smoothstep(0.15, 0.70, rainStrength);
        float nebulaVis = (isNight + blueHour * 0.4) * starRainFadeN;
        if (nebulaVis > 0.01) {
            vec3 nebula = nightNebula(worldDir, frameTimeCounter);
            color += nebula * nebulaVis;
        }
    }
    #endif

    // === NIGHT ASTEROIDS ===
    #ifdef NIGHT_ASTEROIDS_ENABLED
    {
        float starRainFadeA = 1.0 - smoothstep(0.15, 0.70, rainStrength);
        float asteroidVis = isNight * starRainFadeA;
        if (asteroidVis > 0.01 && worldDir.y > -0.05) {
            float horizonFadeA = smoothstep(-0.05, 0.10, worldDir.y);
            vec3 asteroids = nightAsteroids(worldDir, frameTimeCounter);
            color += asteroids * asteroidVis * horizonFadeA;
        }
    }
    #endif
    
    // === 2D CLOUDS ===
    #ifdef CLOUDS_2D_ENABLED
    {
        vec4 clouds = render2DClouds(worldDir, cameraPosition, frameTimeCounter, sunAngle);
        // Blend clouds over sky (alpha compositing)
        color = mix(color, clouds.rgb, clouds.a);
    }
    #endif
    
    // === RINGED PLANET ===
    #ifdef RINGED_PLANET_ENABLED
    {
        // Use shadow light position for proper sun direction
        vec3 sunDir = normalize(mat3(gbufferModelViewInverse) * shadowLightPosition);
        vec3 eye = vec3(0.0);
        
        PlanetEnd2(color, eye, worldDir, sunDir);
    }
    #endif

    gl_FragData[0] = vec4(color, 1.0);
    gl_FragData[1] = vec4(0.0);
}



