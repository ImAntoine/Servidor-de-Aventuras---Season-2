
#include "/settings.glsl"

out vec2 texcoord;
out vec4 glcolor;

uniform float frameTimeCounter;
uniform float rainStrength;

float hash11(float n) {
	return fract(sin(n) * 43758.5453123);
}

vec2 hash21(vec2 p) {
	float n = dot(p, vec2(127.1, 311.7));
	float n2 = dot(p, vec2(269.5, 183.3));
	return fract(sin(vec2(n, n2)) * 43758.5453123);
}

void main() {
	vec2 uv = (gl_TextureMatrix[0] * gl_MultiTexCoord0).xy;
	texcoord = uv;
	glcolor = gl_Color;

	// Start from standard fixed-function transform
	vec4 viewPos = gl_ModelViewMatrix * gl_Vertex;

	// Wind-driven rain slant/sway
	float rs = clamp(rainStrength, 0.0, 1.0);
	float w = clamp(RAIN_WIND_STRENGTH, 0.0, 1.0) * rs;

	// Standard projection
	gl_Position = gl_ProjectionMatrix * viewPos;

	if (w > 0.0001) {
		float t = frameTimeCounter;

		// One coherent WORLD wind direction for ALL rain.
		// This is independent of camera yaw; the on-screen slant changes naturally as you look around.
		vec3 windWorld = normalize(vec3(1.0, 0.0, 0.65));
		vec4 windClip = gl_ProjectionMatrix * (gl_ModelViewMatrix * vec4(windWorld, 0.0));
		vec2 windDir = windClip.xy;
		float wLen = length(windDir);
		windDir = (wLen > 0.00001) ? (windDir / wLen) : vec2(1.0, 0.0);

		// Gust wobble (magnitude only, direction stays consistent)
		float gust = 0.75 + 0.25 * sin(t * 2.6);
		float shearAmt = w * gust;

		// Tilt along the streak (top shifts more than bottom)
		float along = (uv.y - 0.5) * 2.0; // -1..1

		// NDC slant amount (small, stable) -> avoids "sending rain everywhere"
		float slantNDC = 0.03 * shearAmt;
		gl_Position.xy += windDir * (along * slantNDC) * gl_Position.w;
	}
}
