/* RENDERTARGETS: 0,1,3 */

#include "/settings.glsl"

uniform sampler2D gtexture;

in vec2 texcoord;
in vec4 glcolor;

void main() {
	vec4 color = texture(gtexture, texcoord) * glcolor;

	// Emissive entity eyes (enderman, spider, phantom, etc.)
	// Boost brightness so eyes glow visibly, then output the color for bloom extraction.
	vec3 visibleColor = color.rgb * EMISSIVE_BRIGHTNESS;
	vec3 bloomColor = visibleColor;

	gl_FragData[0] = vec4(visibleColor, color.a);
	gl_FragData[1] = vec4(0.0, 1.0, 0.0, 0.0); // G=1.0 = emissive for bloom
	gl_FragData[2] = vec4(bloomColor, 1.0);       // colortex3: colored bloom input
}
