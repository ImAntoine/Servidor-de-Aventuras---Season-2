#ifndef SETTINGS_INCLUDED
#define SETTINGS_INCLUDED

// ############################################################################
// ##                                                                        ##
// ##                         CAZFPS SHADER SETTINGS                         ##
// ##                                                                        ##
// ############################################################################

// Dummy constant for settings UI credit label (not used in shaders)
#define SHADER_CREDITS 0 // [0]

// ============================================================================
// =====                        LIGHTING                                  =====
// ============================================================================

// ----------------------------------------------------------------------------
//   Shadows
// ----------------------------------------------------------------------------

// Enable directional shadows (sun/moon shadows)
#define SHADOWS_ENABLED

// Shadow map resolution (lower is faster, Quartic Distortion keeps detail high)
const int shadowMapResolution = 6144; // [512 1024 2048 3072 4096 6144 8192 12288 16384]

// Shadow render distance (blocks)
#define SHADOW_DISTANCE 10000.0// [32.0 48.0 64.0 80.0 96.0 112.0 128.0 144.0 160.0 176.0 192.0 224.0 256.0 320.0 384.0 512.0 640.0 768.0 1024.0 1280.0 1536.0 2000.0 2500.0 3000.0 4000.0 5000.0 6000.0 8000.0 10000.0]

// Shadow distortion factor (balance between resolution and edge quality)
// Lower values = more uniform coverage (better for long distance), higher = more detail at center
#define SHADOW_DISTORTION 0.10// [0.02 0.03 0.04 0.05 0.08 0.10 0.12 0.15 0.20 0.25 0.30 0.40 0.50 0.60 0.70 0.85]

// Photon-style shadow depth scale (internal)
#define SHADOW_DEPTH_SCALE 0.2

// Normal bias scale (reduces shadow acne)
#define SHADOW_NORMAL_BIAS 2.0 // [0.00 0.50 1.00 1.50 2.00 2.50 3.00 4.00 5.00]

// Shadow opacity (0 = no shadows, 1 = full dark shadows)
#define SHADOW_OPACITY 0.60// [0.00 0.10 0.20 0.30 0.40 0.50 0.60 0.70 0.75 0.80 0.85 0.90 0.95 1.00]

// Shadow color tint (0 = no tint, positive = cool/blue, negative = warm/orange)
#define SHADOW_HUE 45.0// [-180.0 -165.0 -150.0 -135.0 -120.0 -105.0 -90.0 -75.0 -60.0 -45.0 -30.0 -15.0 0.0 15.0 30.0 45.0 60.0 75.0 90.0 105.0 120.0 135.0 150.0 165.0 180.0]

// Shadow color saturation (0 = subtle/washed out, 1 = vivid/saturated, higher = oversaturated)
#define SHADOW_SATURATION 1.75// [0.00 0.10 0.20 0.30 0.40 0.50 0.60 0.70 0.80 0.90 1.00 1.25 1.50 1.75 2.00 2.50 3.00 4.00 5.00]

// How much blocklight can override/cancel directional shadows around light sources.
// 0 = no override, 1 = full override near strong blocklight.
#define BLOCKLIGHT_SHADOW_OVERRIDE 1.00// [0.00 0.10 0.20 0.30 0.40 0.50 0.60 0.70 0.80 0.90 1.00]

// Lightmap shadow settings (for areas beyond shadow map distance)
// These control the darkness/color of areas with low skylight
#define LIGHTMAP_SATURATION 0.25// [0.00 0.05 0.10 0.15 0.20 0.25 0.30 0.35 0.40 0.50 0.60 0.70 0.80 0.90 1.00]

// Skylight darkness levels. Subtracts fixed levels from skylight 14..1 (15 untouched).
// 0 = no change, 13 = strongest darkening.
#define SKYLIGHT_DARKNESS_LEVELS 3 // [0 1 2 3 4 5 6 7 8 9 10 11 12 13]

// Skylight darkness increment curve (Z):
// 0.0 = gentle progression (x1, x1.1, x1.2...), 1.0 = steep progression (x1, x2, x3...).
#define SKYLIGHT_DARKNESS_Z 0.5 // [0.0 0.1 0.2 0.3 0.4 0.5 0.6 0.7 0.8 0.9 1.0]

// DH shadow opacity. Controls how dark shadows from the shadow map are on DH terrain.
// 0.0 = no shadow darkening, 1.0 = maximum darkness.
#define DH_SHADOW_OPACITY 0.60// [0.00 0.05 0.10 0.15 0.20 0.25 0.30 0.35 0.40 0.45 0.50 0.55 0.60 0.65 0.70 0.75 0.80 0.85 0.90 0.95 1.00]

// DH ambient occlusion intensity (percentage). Controls darkness under overhangs/trees on DH terrain.
// 0% = no AO (flat), 100% = full AO.
#define DH_AO_INTENSITY 100// [0 1 2 3 4 5 6 7 8 9 10 11 12 13 14 15 16 17 18 19 20 21 22 23 24 25 26 27 28 29 30 31 32 33 34 35 36 37 38 39 40 41 42 43 44 45 46 47 48 49 50 51 52 53 54 55 56 57 58 59 60 61 62 63 64 65 66 67 68 69 70 71 72 73 74 75 76 77 78 79 80 81 82 83 84 85 86 87 88 89 90 91 92 93 94 95 96 97 98 99 100]


// Shadow filter style: Sharp uses hardware-bilinear, Soft uses Blue Noise PCF
#define SHARP_SHADOWS // Sharp shadows use less GPU and look crisper. Comment out for Soft shadows.

// PCF filter radius for soft shadows (only used when SHARP_SHADOWS is disabled).
// Higher values blur shadow edges more.
#define SHADOW_PCF_RADIUS 2.5 // [0.5 1.0 1.5 2.0 2.5 3.0 3.5 4.0 5.0 6.0 8.0]



// ----------------------------------------------------------------------------
//   Ambient & World Lighting
// ----------------------------------------------------------------------------

// Terrain brightness multiplier
#define TERRAIN_BRIGHTNESS 0.80// [0.50 0.55 0.60 0.65 0.70 0.75 0.80 0.85 0.90 0.95 1.00 1.05 1.10 1.15 1.20]

// Night ambient light (0 = pure darkness)
#define NIGHT_AMBIENT 0.10// [0.00 0.005 0.01 0.015 0.02 0.025 0.03 0.035 0.04 0.045 0.05 0.06 0.07 0.08 0.09 0.10 0.12 0.15 0.20 0.25 0.30 0.35 0.40 0.50 0.60 0.75 1.00]

// Cave/indoor ambient light
#define CAVE_AMBIENT 0.05 // [0.00 0.01 0.02 0.03 0.04 0.05 0.06 0.07 0.08 0.09 0.10 0.12 0.15 0.20]

// Blocklight brightness (torches, lanterns, etc.)
#define BLOCKLIGHT_BRIGHTNESS 0.70// [0.20 0.25 0.30 0.35 0.40 0.45 0.50 0.55 0.60 0.65 0.70 0.75 0.80 0.85 0.90 0.95 1.00 1.10 1.20 1.30 1.40 1.50]

// Reduce blocklight when skylight is present.
// 0 = no reduction, 1 = full reduction at full skylight.
#define BLOCKLIGHT_SKYLIGHT_REDUCTION 0.50// [0.00 0.10 0.20 0.30 0.40 0.50 0.60 0.70 0.80 0.90 1.00]

// Entity brightness boost (0 = normal, 1 = fully bright)
#define ENTITY_BRIGHTNESS_BOOST 0.00// [0.00 0.05 0.10 0.15 0.20 0.25 0.30 0.35 0.40 0.45 0.50 0.55 0.60 0.65 0.70 0.75 0.80 0.85 0.90 0.95 1.00]

// Ambient tint (negative = warm, 0 = neutral, positive = cool/blue)
#define AMBIENT_TINT 0.3 // [-1.00 -0.90 -0.80 -0.70 -0.60 -0.50 -0.40 -0.30 -0.20 -0.10 0.00 0.10 0.20 0.30 0.40 0.50 0.60 0.70 0.80 0.90 1.00]

// How strongly the sky colors tint world skylight (0 = neutral white skylight, 1 = fully sky-colored)
// This is what makes the world pick up the warm horizon glow at sunset.
#define SKYLIGHT_COLOR_TINT 0.25// [0.00 0.25 0.50 0.65 0.75 0.85 1.00]

// Skylight tint saturation (applies to the sky-tinted lighting on blocks; 1.0 = unchanged)
#define SKYLIGHT_TINT_SATURATION 0.50// [0.00 0.25 0.50 0.75 1.00 1.10 1.25 1.50 1.75 2.00 2.50 3.00]

// Extra saturation applied mostly in bright/lit areas.
// 0 = keep lit areas closer to neutral, 1 = lit areas use full SKYLIGHT_TINT_SATURATION.
#define SKYLIGHT_TINT_LIGHT_SATURATION 0.50// [0.00 0.25 0.50 0.75 1.00]

// Extra tint/saturation boost at sunset and sunrise on terrain.
// 0 = no extra warmth beyond SKYLIGHT_COLOR_TINT, higher = stronger golden-hour glow on blocks.
#define SUNSET_TERRAIN_TINT 0.55// [0.00 0.05 0.10 0.15 0.20 0.25 0.30 0.35 0.40 0.45 0.50 0.55 0.60 0.65 0.70 0.75 0.80 0.85 0.90 1.00 1.10 1.20 1.30 1.40 1.50]

// ----------------------------------------------------------------------------
//   Weather (Rain)
// ----------------------------------------------------------------------------

// Rain transparency multiplier (0 = invisible rain, 1 = vanilla texture alpha)
#define RAIN_OPACITY 0.50// [0.00 0.10 0.20 0.30 0.40 0.50 0.60 0.70 0.75 0.80 0.90 1.00]

// Rain wind strength (slants/sways rain; 0 = straight down)
#define RAIN_WIND_STRENGTH 1.00// [0.00 0.10 0.20 0.30 0.35 0.40 0.50 0.60 0.70 0.80 0.90 1.00]

// Rain puddles on surfaces (requires water reflections to be enabled)
#define PUDDLES_ENABLED
// Overall puddle coverage/strength
#define PUDDLES_STRENGTH 1.00// [0.00 0.10 0.20 0.30 0.40 0.50 0.60 0.70 0.80 0.90 1.00]
// How reflective puddles are
#define PUDDLES_REFLECTION_STRENGTH 0.30// [0.00 0.10 0.20 0.30 0.40 0.50 0.60 0.70 0.80 0.90 1.00]

// Water runoff streaks on vertical surfaces during rain
#define WALL_RUNOFF_ENABLED
// Overall visibility/strength of runoff streaks
#define WALL_RUNOFF_STRENGTH 0.55 // [0.00 0.10 0.20 0.30 0.40 0.50 0.55 0.60 0.70 0.80 0.90 1.00]
// Speed of the downward flow
#define WALL_RUNOFF_SPEED 1.00 // [0.00 0.25 0.50 0.75 1.00 1.25 1.50 2.00 2.50 3.00]

// ----------------------------------------------------------------------------
//   Emissive Blocks
// ----------------------------------------------------------------------------

// Emissive block brightness multiplier
#define EMISSIVE_BRIGHTNESS 1 // [0.50 0.55 0.60 0.65 0.70 0.75 0.80 0.85 0.90 0.95 1.00 1.05 1.10 1.15 1.20 1.25 1.30 1.40 1.50 1.75 2.00]

// Dynamic handheld light (held torches/lanterns/etc. light nearby world around player)
#define HANDHELD_LIGHT_ENABLED
#define HANDHELD_LIGHT_STRENGTH 1.00 // [0.00 0.10 0.20 0.30 0.40 0.50 0.60 0.70 0.80 0.90 1.00 1.20 1.40 1.60 1.80 2.00 2.50 3.00]
#define HANDHELD_LIGHT_RADIUS 14.0 // [4.0 6.0 8.0 10.0 12.0 14.0 16.0 18.0 20.0 24.0 28.0 32.0 40.0]

// Handheld 3D block bloom (for mods that render held items as terrain)
// Emission: brightness of the glowing texture on the held item
#define HELD_BLOOM_EMISSION 1.5 // [0.5 0.75 1.0 1.25 1.5 1.75 2.0 2.5 3.0 4.0 5.0 6.0 8.0 10.0 15.0 20.0]
// Bloom strength: intensity of the bloom glow around the held item
#define HELD_BLOOM_STRENGTH 3.0 // [0.5 1.0 1.5 2.0 2.5 3.0 4.0 5.0 6.0 8.0 10.0 15.0 20.0 30.0 50.0]
// Detection radius: how close to the player (in blocks) items are detected
#define HELD_BLOOM_RADIUS 1.5 // [0.5 0.8 1.0 1.2 1.5 2.0 2.5 3.0]
// Luma threshold: minimum texture brightness to trigger bloom
#define HELD_BLOOM_THRESHOLD 0.0 // [0.0 0.1 0.2 0.3 0.4 0.5 0.6 0.7 0.8]

// ============================================================================
// =====                      POST PROCESSING                             =====
// ============================================================================

// ----------------------------------------------------------------------------
//   Bloom
// ----------------------------------------------------------------------------

// Enable bloom glow effect
#define BLOOM_ENABLED

// Bloom intensity (glow brightness)
#define BLOOM_INTENSITY 0.25// [0.00 0.05 0.10 0.15 0.20 0.25 0.30 0.35 0.40 0.45 0.50 0.55 0.60 0.65 0.70 0.75 0.80 0.85 0.90 0.95 1.00 1.25 1.50 1.75 2.00 2.50 3.00]

// Bloom radius (glow spread distance)
#define BLOOM_RADIUS 0.3// [0.1 0.2 0.3 0.4 0.5 0.6 0.7 0.8 0.9 1.0 1.2 1.4 1.6 1.8 2.0 2.5 3.0 4.0 5.0 6.0 7.0 8.0 9.0 10.0 12.0 14.0 16.0 20.0 25.0 30.0]

// Distance compensation (boost bloom for far objects, 0 = off)
#define BLOOM_DISTANCE_COMPENSATION 1 // [0.0 0.25 0.5 0.75 1.0 1.5 2.0 3.0 4.0]

// Bloom in sunlight (reduces bloom on surface during day, underground unaffected)
#define BLOOM_DAY_STRENGTH 0.22// [0.00 0.02 0.04 0.06 0.08 0.10 0.12 0.14 0.16 0.18 0.20 0.22 0.24 0.26 0.28 0.30 0.32 0.34 0.36 0.38 0.40 0.45 0.50 0.55 0.60 0.65 0.70 0.75 0.80 0.85 0.90 0.95 1.00]

// --- Particle Bloom ---
// Particle bloom intensity
#define PARTICLE_BLOOM_INTENSITY 2.50 // [0.00 0.25 0.50 0.75 1.00 1.25 1.50 1.75 2.00 2.25 2.50 2.75 3.00 3.50 4.00 5.00 6.00 8.00]

// Particle brightness threshold (lower = more glow)
#define PARTICLE_BLOOM_THRESHOLD 0.40// [0.10 0.15 0.20 0.25 0.30 0.35 0.40 0.45 0.50 0.55 0.60 0.65 0.70 0.75 0.80 0.85 0.90]

// Particle warmth threshold
#define PARTICLE_BLOOM_WARMTH 0.15 // [0.00 0.05 0.10 0.15 0.20 0.25 0.30 0.35 0.40]


// ----------------------------------------------------------------------------
//   Metalness (Fake PBR for metallic blocks)
// ----------------------------------------------------------------------------

// Enable metalness effect on metal/gem blocks
#define METALNESS_ENABLED

// Metalness intensity (reflection strength)
#define METALNESS_INTENSITY 0.9// [0.1 0.2 0.3 0.4 0.5 0.6 0.7 0.8 0.9 1.0]

// Fresnel effect strength (edge reflection boost)
#define METALNESS_FRESNEL 0.6// [0.0 0.1 0.2 0.3 0.4 0.5 0.6 0.7 0.8 0.9 1.0]

// Specular highlight sharpness (lower = sharper, tighter highlight)
#define METALNESS_ROUGHNESS 0.70// [0.05 0.08 0.10 0.12 0.15 0.18 0.20 0.25 0.30 0.40 0.50 0.60 0.70 0.80]

// Gem sparkle intensity (extra sparkle for diamond, emerald, etc.)
#define GEM_SPARKLE 0.0// [0.0 0.2 0.4 0.6 0.8 1.0 1.2 1.5 2.0]

// ----------------------------------------------------------------------------
//   PBR Materials (Resource Pack Textures + Default Materials)
// ----------------------------------------------------------------------------

// Enable PBR material support (normal maps + specular maps from resource packs)
#define PBR_ENABLED

// Specular highlight strength
#define PBR_SPECULAR_STRENGTH 1.0// [0.1 0.2 0.3 0.4 0.5 0.6 0.7 0.8 0.9 1.0 1.2 1.5 2.0]

// Normal map influence strength
#define PBR_NORMAL_STRENGTH 1.0// [0.0 0.25 0.5 0.75 1.0 1.25 1.5 2.0]

// Default wood roughness (when no PBR resource pack)
#define DEFAULT_WOOD_ROUGHNESS 0.6// [0.3 0.4 0.5 0.6 0.7 0.75 0.8 0.85 0.9]

// Default stone roughness (when no PBR resource pack)
#define DEFAULT_STONE_ROUGHNESS 0.85// [0.5 0.6 0.7 0.75 0.8 0.85 0.9 0.95]

// ----------------------------------------------------------------------------
//   Leaf Sheen (Subsurface Scattering + Fresnel for natural foliage)
// ----------------------------------------------------------------------------

// Enable leaf sheen effect on leaf blocks
#define LEAF_SHEEN_ENABLED

// Subsurface scattering strength (warm glow through back-lit leaves)
#define LEAF_SSS_STRENGTH 0.7// [0.0 0.1 0.2 0.3 0.4 0.5 0.6 0.7 0.8 0.9 1.0 1.2 1.5 2.0]

// Fresnel rim strength (bright edge at grazing viewing angles)
#define LEAF_FRESNEL_STRENGTH 0.5 // [0.0 0.1 0.2 0.3 0.4 0.5 0.6 0.7 0.8 0.9 1.0]

// Shadow transmittance (subtle light leak onto back faces of leaves)
#define LEAF_SHADOW_TRANSMITTANCE 0.0// [0.0 0.05 0.10 0.15 0.20 0.25 0.30 0.40 0.50]

// Shadow softness on leaf blocks (wider = blurrier shadows, hides blocky geometry)
#define LEAF_SHADOW_SOFTNESS 24.0// [0.0 1.0 2.0 3.0 4.0 5.0 6.0 8.0 10.0 12.0 16.0 20.0 24.0 32.0 48.0 64.0]

// ----------------------------------------------------------------------------
//   Outlines
// ----------------------------------------------------------------------------

// Outline mode: 0 = off, 1 = standard, 2 = dungeons style
#define OUTLINES 2 // [0 1 2]

// Outline brightness/darkness
#define OUTLINE_BRIGHTNESS 0.80// [-1.00 -0.90 -0.80 -0.70 -0.60 -0.50 -0.40 -0.30 -0.20 -0.10 0.00 0.10 0.20 0.30 0.40 0.50 0.60 0.70 0.80 0.90 1.00]

// Outline thickness (in pixels)
#define OUTLINE_PIXEL_SIZE 3// [1 2 3 4 5 6 8 10 12 16 24 32 48 64]

// Outline fog fade threshold (higher = outlines persist further into fog)
#define OUTLINE_FOG_FADE 0.35 // [0.10 0.20 0.35 0.50 0.65 0.80 1.00]



// ----------------------------------------------------------------------------
//   Color Correction
// ----------------------------------------------------------------------------

// Enable sharpening filter
//#define POST_SHARPEN

// Sharpening strength
#define POST_SHARPEN_STRENGTH 0.30// [0.00 0.05 0.10 0.15 0.20 0.25 0.30 0.35 0.40 0.45 0.50 0.55 0.60 0.65 0.70 0.75 0.80]

// Color saturation (1 = neutral)
#define POST_SATURATION 1.00 // [0.00 0.10 0.20 0.30 0.40 0.50 0.60 0.70 0.80 0.90 1.00 1.10 1.20 1.30 1.40 1.50 1.60 1.70 1.80 1.90 2.00]

// Color contrast (1 = neutral)
#define POST_CONTRAST 1.00 // [0.50 0.55 0.60 0.65 0.70 0.75 0.80 0.85 0.90 0.95 1.00 1.05 1.10 1.15 1.20 1.25 1.30 1.35 1.40 1.45 1.50]

// Brightness offset (0 = neutral)
#define POST_BRIGHTNESS 0.05// [-0.50 -0.45 -0.40 -0.35 -0.30 -0.25 -0.20 -0.15 -0.10 -0.05 0.00 0.05 0.10 0.15 0.20 0.25 0.30 0.35 0.40 0.45 0.50]

// ----------------------------------------------------------------------------
//   Temporal Anti-Aliasing (TAA)
// ----------------------------------------------------------------------------

// Enable TAA — blends frames over time for smoother volumetrics and reduced aliasing
#define TAA_ENABLED

// Blend factor — how much of the previous frame to keep (higher = smoother but more ghosting)
#define TAA_BLEND 0.90 // [0.75 0.80 0.85 0.90 0.92 0.95]

// ----------------------------------------------------------------------------
//   Color Grading (Cinematic Vibes)
// ----------------------------------------------------------------------------

// Enable color grading system
//#define COLOR_GRADING_ENABLED

// --- Temperature & Tint ---
// Temperature: negative = cool/blue, positive = warm/orange
#define CG_TEMPERATURE 0.0 // [-1.00 -0.90 -0.80 -0.70 -0.60 -0.50 -0.40 -0.30 -0.20 -0.10 0.00 0.10 0.20 0.30 0.40 0.50 0.60 0.70 0.80 0.90 1.00]

// Tint: negative = green, positive = magenta
#define CG_TINT 0.0 // [-1.00 -0.90 -0.80 -0.70 -0.60 -0.50 -0.40 -0.30 -0.20 -0.10 0.00 0.10 0.20 0.30 0.40 0.50 0.60 0.70 0.80 0.90 1.00]

// --- Split Toning (Color different parts of the image) ---
// Enable split toning (shadows/highlights tinting)
#define CG_SPLIT_TONING_ENABLED

// Shadow tint color (RGB 0-1)
#define CG_SHADOW_TINT_R 0.1 // [0.0 0.05 0.1 0.15 0.2 0.25 0.3 0.35 0.4 0.45 0.5 0.55 0.6 0.65 0.7 0.75 0.8 0.85 0.9 0.95 1.0]
#define CG_SHADOW_TINT_G 0.1 // [0.0 0.05 0.1 0.15 0.2 0.25 0.3 0.35 0.4 0.45 0.5 0.55 0.6 0.65 0.7 0.75 0.8 0.85 0.9 0.95 1.0]
#define CG_SHADOW_TINT_B 0.2 // [0.0 0.05 0.1 0.15 0.2 0.25 0.3 0.35 0.4 0.45 0.5 0.55 0.6 0.65 0.7 0.75 0.8 0.85 0.9 0.95 1.0]

// Highlight tint color (RGB 0-1)
#define CG_HIGHLIGHT_TINT_R 0.2 // [0.0 0.05 0.1 0.15 0.2 0.25 0.3 0.35 0.4 0.45 0.5 0.55 0.6 0.65 0.7 0.75 0.8 0.85 0.9 0.95 1.0]
#define CG_HIGHLIGHT_TINT_G 0.15 // [0.0 0.05 0.1 0.15 0.2 0.25 0.3 0.35 0.4 0.45 0.5 0.55 0.6 0.65 0.7 0.75 0.8 0.85 0.9 0.95 1.0]
#define CG_HIGHLIGHT_TINT_B 0.1 // [0.0 0.05 0.1 0.15 0.2 0.25 0.3 0.35 0.4 0.45 0.5 0.55 0.6 0.65 0.7 0.75 0.8 0.85 0.9 0.95 1.0]

// Split toning intensity (0 = off, 1 = full strength)
#define CG_SPLIT_TONING_INTENSITY 0.15 // [0.00 0.05 0.10 0.15 0.20 0.25 0.30 0.35 0.40 0.50 0.60 0.70 0.80 0.90 1.00]

// Split toning balance (-1 = more shadows, 0 = balanced, 1 = more highlights)
#define CG_SPLIT_TONING_BALANCE 0.0 // [-1.00 -0.75 -0.50 -0.25 0.00 0.25 0.50 0.75 1.00]

// --- Lift/Gamma/Gain (Professional Color Grading) ---
// Lift affects shadows (RGB multiplier)
#define CG_LIFT_R 1.0 // [0.50 0.60 0.70 0.80 0.85 0.90 0.95 1.00 1.05 1.10 1.15 1.20 1.30 1.40 1.50]
#define CG_LIFT_G 1.0 // [0.50 0.60 0.70 0.80 0.85 0.90 0.95 1.00 1.05 1.10 1.15 1.20 1.30 1.40 1.50]
#define CG_LIFT_B 1.0 // [0.50 0.60 0.70 0.80 0.85 0.90 0.95 1.00 1.05 1.10 1.15 1.20 1.30 1.40 1.50]

// Gamma affects midtones (RGB power)
#define CG_GAMMA_R 1.0 // [0.50 0.60 0.70 0.80 0.85 0.90 0.95 1.00 1.05 1.10 1.15 1.20 1.30 1.40 1.50]
#define CG_GAMMA_G 1.0 // [0.50 0.60 0.70 0.80 0.85 0.90 0.95 1.00 1.05 1.10 1.15 1.20 1.30 1.40 1.50]
#define CG_GAMMA_B 1.0 // [0.50 0.60 0.70 0.80 0.85 0.90 0.95 1.00 1.05 1.10 1.15 1.20 1.30 1.40 1.50]

// Gain affects highlights (RGB multiplier)
#define CG_GAIN_R 1.0 // [0.50 0.60 0.70 0.80 0.85 0.90 0.95 1.00 1.05 1.10 1.15 1.20 1.30 1.40 1.50]
#define CG_GAIN_G 1.0 // [0.50 0.60 0.70 0.80 0.85 0.90 0.95 1.00 1.05 1.10 1.15 1.20 1.30 1.40 1.50]
#define CG_GAIN_B 1.0 // [0.50 0.60 0.70 0.80 0.85 0.90 0.95 1.00 1.05 1.10 1.15 1.20 1.30 1.40 1.50]

// --- Color Palette / Posterization ---
// Enable color palette limiting (retro/stylized look) - applies to EVERYTHING
//#define CG_POSTERIZE_ENABLED  // Disabled - causes noise

// Number of color levels per channel (lower = more stylized)
#define CG_POSTERIZE_LEVELS 3// [2 3 4 5 6 8 10 12 16 24 32 48 64]

// Posterize dithering (reduces banding)
#define CG_POSTERIZE_DITHER 0.0 // [0.0 0.25 0.5 0.75 1.0]

// --- Texture Palette Limiting ---
// Apply palette limiting directly to block/entity textures (not post-process, no fog)
//#define TEXTURE_PALETTE_ENABLED

// Number of color levels per channel for textures
#define TEXTURE_PALETTE_LEVELS 16 // [2 3 4 5 6 8 10 12 16 24 32]

// --- Vignette ---
// Enable vignette (darkened edges)
//#define CG_VIGNETTE_ENABLED

// Vignette intensity (0 = none, 1 = heavy)
#define CG_VIGNETTE_INTENSITY 0.3 // [0.00 0.05 0.10 0.15 0.20 0.25 0.30 0.35 0.40 0.50 0.60 0.70 0.80 0.90 1.00]

// Vignette radius (how far from center the darkening starts)
#define CG_VIGNETTE_RADIUS 0.75 // [0.30 0.40 0.50 0.60 0.70 0.75 0.80 0.85 0.90 1.00]

// Vignette softness (smooth transition)
#define CG_VIGNETTE_SOFTNESS 0.4 // [0.10 0.20 0.30 0.40 0.50 0.60 0.70 0.80]

// Vignette roundness (1 = circular, lower = more elliptical)
#define CG_VIGNETTE_ROUNDNESS 1.0 // [0.50 0.60 0.70 0.80 0.90 1.00]

// --- Film Grain ---
// Enable film grain (cinematic noise)
//#define CG_FILM_GRAIN_ENABLED

// Film grain intensity
#define CG_FILM_GRAIN_INTENSITY 0.1 // [0.02 0.04 0.06 0.08 0.10 0.12 0.15 0.18 0.20 0.25 0.30 0.40 0.50]

// Film grain size (higher = larger grain)
#define CG_FILM_GRAIN_SIZE 1.5 // [0.5 0.75 1.0 1.25 1.5 2.0 2.5 3.0 4.0]

// Film grain is luminance only (monochrome) vs colored
#define CG_FILM_GRAIN_LUMINANCE

// --- Color Lookup / Preset Styles ---
// Color style preset (adds themed color adjustments)
#define CG_STYLE_PRESET 3// [0 1 2 3 4 5 6 7 8]
// 0 = None (manual settings)
// 1 = Cinematic (warm highlights, cool shadows, slight desaturation)
// 2 = Vintage (sepia-ish, reduced contrast, warm tones)
// 3 = Cyberpunk (teal & orange, high contrast, saturated)
// 4 = Horror (desaturated, green tint, crushed blacks)
// 5 = Fantasy (vibrant, purple shadows, golden highlights)
// 6 = Nordic (cold, desaturated, blue shadows)
// 7 = Tropical (warm, saturated greens and blues)
// 8 = Noir (heavy desaturation, slight blue tint, high contrast)

// Preset intensity (blend between no preset and full preset)
#define CG_STYLE_INTENSITY 1.00// [0.00 0.10 0.20 0.30 0.40 0.50 0.60 0.70 0.80 0.90 1.00]

// --- Hue Shift ---
// Global hue rotation (degrees, for creative effects)
#define CG_HUE_SHIFT 0.0 // [-180.0 -150.0 -120.0 -90.0 -60.0 -30.0 0.0 30.0 60.0 90.0 120.0 150.0 180.0]

// --- Vibrance (intelligent saturation) ---
// Vibrance: boosts less saturated colors more than already saturated ones
#define CG_VIBRANCE 0.0 // [-1.00 -0.75 -0.50 -0.25 0.00 0.25 0.50 0.75 1.00]

// ============================================================================
// =====                        EFFECTS                                   =====
// ============================================================================


// ----------------------------------------------------------------------------
//   Volumetric Fog
// ----------------------------------------------------------------------------

// Enable volumetric fog (full fog with height, density, etc)
#define VOLUMETRIC_FOG_ENABLED

// Debug mode - shows depth as black and white
//#define VOLUMETRIC_FOG_DEBUG

// --- Fog Color ---
// Use sky horizon color instead of custom fog color (blends naturally with sky)
#define VFOG_USE_SKY_COLOR

// Custom fog color (used when VFOG_USE_SKY_COLOR is disabled)
#define VFOG_COLOR_R 0.00// [0.00 0.05 0.10 0.15 0.20 0.25 0.30 0.35 0.40 0.45 0.50 0.55 0.60 0.65 0.70 0.75 0.80 0.85 0.90 0.95 1.00]
#define VFOG_COLOR_G 0.00// [0.00 0.05 0.10 0.15 0.20 0.25 0.30 0.35 0.40 0.45 0.50 0.55 0.60 0.65 0.70 0.75 0.80 0.85 0.90 0.95 1.00]
#define VFOG_COLOR_B 1 // [0.00 0.05 0.10 0.15 0.20 0.25 0.30 0.35 0.40 0.45 0.50 0.55 0.60 0.65 0.70 0.75 0.80 0.85 0.90 0.95 1.00]

// Fog color saturation (0 = grayscale, 1 = normal, 2 = very vibrant)
#define VFOG_SATURATION 1.00// [0.00 0.25 0.50 0.75 1.00 1.25 1.50 1.75 2.00 2.50 3.00 4.00 5.00]

// Fog clarity — boosts scene contrast inside fog (0 = flat washed-out, higher = punchier details visible through fog)
// Pulls scene colors away from the fog midpoint so brights stay bright and darks stay dark.
#define VFOG_DETAIL_VISIBILITY 0.00// [0.00 0.05 0.10 0.15 0.20 0.25 0.30 0.35 0.40 0.45 0.50 0.55 0.60 0.65 0.70 0.75 0.80 0.85 0.90 0.95 1.00]

// --- Fog Density ---
// Fog density/thickness (higher = thicker fog)
#define VFOG_DENSITY 3.00// [0.50 1.00 1.50 2.00 3.00 5.00 7.50 10.0 15.0 20.0 30.0 50.0 75.0 100.0]

// Fog scattering intensity (how bright the fog is)
#define VFOG_SCATTERING 5.00// [0.50 1.00 1.50 2.00 3.00 4.00 5.00]

// Fog brightness multiplier (master brightness control)
#define VFOG_BRIGHTNESS 0.30// [0.10 0.20 0.30 0.40 0.50 0.60 0.70 0.75 0.80 0.82 0.84 0.86 0.88 0.90 0.92 0.94 0.96 0.98 1.00 1.10 1.20 1.50 2.00]

// Fog ambient light (minimum fog brightness in shadows - lower = more god ray contrast)
#define VFOG_AMBIENT 0.30// [0.00 0.05 0.10 0.15 0.20 0.25 0.30 0.40 0.50 0.60 0.80 1.00]

// --- Time-Based Fog Modifiers ---
// Controls fog intensity at different times of day (0 = no fog, 100 = full fog)
#define VFOG_TIME_NOON 50// [0 10 20 30 40 50 60 70 80 90 100]
#define VFOG_TIME_SUNSET 60// [0 10 20 30 40 50 60 70 80 90 100]
#define VFOG_TIME_MIDNIGHT 100 // [0 10 20 30 40 50 60 70 80 90 100]
#define VFOG_TIME_SUNRISE 80// [0 10 20 30 40 50 60 70 80 90 100]

// --- Time-Based Fog Brightness ---
// Controls fog brightness at different times of day (multiplier of main VFOG_BRIGHTNESS)
#define VFOG_BRIGHT_NOON 1.50// [0.10 0.20 0.30 0.40 0.50 0.60 0.70 0.80 0.90 1.00 1.10 1.20 1.30 1.40 1.50]
#define VFOG_BRIGHT_SUNSET 1.50// [0.10 0.20 0.30 0.40 0.50 0.60 0.70 0.80 0.90 1.00 1.10 1.20 1.30 1.40 1.50 1.75 2.00 2.50 3.00 4.00 5.00]
#define VFOG_BRIGHT_MIDNIGHT 1.50// [0.10 0.20 0.30 0.40 0.50 0.60 0.70 0.80 0.90 1.00 1.10 1.20 1.30 1.40 1.50]
#define VFOG_BRIGHT_SUNRISE 1.50// [0.10 0.20 0.30 0.40 0.50 0.60 0.70 0.80 0.90 1.00 1.10 1.20 1.30 1.40 1.50]

// --- Fog Distance ---
// Maximum fog render distance (blocks)
#define VFOG_DISTANCE 2048.0// [64.0 128.0 192.0 256.0 384.0 512.0 768.0 1024.0 1536.0 2048.0]

// Clear zone radius around player (no fog within this distance)
#define VFOG_START_DISTANCE 8.0// [0.0 8.0 16.0 24.0 32.0 48.0 64.0 96.0 128.0]

// Distance at which fog reaches full density (blocks)
#define VFOG_DEPTH_DISTANCE 512.0// [32.0 48.0 64.0 96.0 128.0 192.0 256.0 384.0 512.0 768.0 1024.0 1536.0 2048.0 3000.0 4000.0]

// Emissive/hologram visibility distance - holograms stay visible through fog within this range
#define VFOG_EMISSIVE_VISIBILITY 8.0// [0.0 8.0 16.0 24.0 32.0 48.0 64.0 96.0 128.0 192.0 256.0]

// Raymarch steps (higher = better quality, more GPU cost)
#define VFOG_STEPS 96// [16 24 32 48 64 96 128]

// --- Fog Height ---
// Fog layer bottom Y coordinate (world space)
#define VFOG_HEIGHT_BOTTOM -32.0// [-64.0 -32.0 0.0 20.0 40.0 50.0 60.0 70.0 80.0 90.0 100.0 110.0 120.0 140.0 160.0 200.0 250.0 300.0]

// Fog layer top Y coordinate (world space)  
#define VFOG_HEIGHT_TOP 120.0// [50.0 60.0 70.0 80.0 90.0 100.0 110.0 120.0 140.0 160.0 180.0 200.0 250.0 300.0 350.0 400.0]

// Fog fade distance at bottom edge (blocks)
#define VFOG_FADE_BOTTOM 0.0// [0.0 2.0 4.0 6.0 8.0 10.0 12.0 16.0 20.0 24.0 32.0 48.0 64.0 96.0 128.0 192.0 256.0]

// Fog fade distance at top edge (blocks)
#define VFOG_FADE_TOP 128.0// [0.0 2.0 4.0 6.0 8.0 10.0 12.0 16.0 20.0 24.0 32.0 48.0 64.0 96.0 128.0 192.0 256.0]

// --- Sun God Rays ---
// Enable god rays - darkens fog in shadowed areas
// Supports colored shadows from stained glass!
#define VFOG_GOD_RAYS
// Iris requires #ifdef reference to register boolean toggles
#ifdef VFOG_GOD_RAYS
#endif

// Debug god rays - shows yellow=lit, black=shadow (disable for normal use)
//#define VFOG_GOD_RAYS_DEBUG

// Debug: Connected textures - shows outline where different block types meet
//#define BLOCK_ID_OUTLINE_DEBUG

// God ray intensity (how visible the light shafts are, lower = softer contrast)
#define VFOG_GOD_RAY_INTENSITY 0.30// [0.10 0.20 0.30 0.40 0.50 0.60 0.70 0.75 0.80 0.90 1.00 1.25 1.50]

// God ray sharpness (enhances contrast at shadow edges without changing brightness)
// Higher = sharper ray edges, 1.0 = linear, 2.0+ = crisp edges
#define VFOG_GOD_RAY_SHARPNESS 1.50// [1.00 1.25 1.50 1.75 2.00 2.50 3.00 4.00 5.00]

// God ray smoothing (lower = sharper rays but more noise, higher = smoother)
#define VFOG_GOD_RAY_SMOOTHING 0.30 // [0.05 0.10 0.15 0.20 0.25 0.30 0.40 0.50 0.60 0.70 0.80]

// God ray shadow tint strength (0 = neutral gray shadows, 1 = full colored shadow tint)
#define VFOG_GOD_RAY_TINT_STRENGTH 0.40// [0.00 0.10 0.20 0.30 0.40 0.50 0.60 0.70 0.80 0.90 1.00 1.25 1.50 2.00]

// Moon light shaft brightness (multiplier for nighttime rays, 0 = no moon rays)
#define VFOG_MOON_BRIGHTNESS 0.5 // [0.00 0.10 0.20 0.30 0.40 0.50 0.60 0.70 0.80 0.90 1.00 1.25 1.50]

// --- Fog Bloom ---
// Enable bloom glow visible through volumetric fog
//#define VFOG_BLOOM_ENABLED

// Fog bloom intensity (how much glow shows through fog)
#define VFOG_BLOOM_INTENSITY 0.40// [0.00 0.10 0.20 0.30 0.40 0.50 0.60 0.70 0.80 0.90 1.00 1.25 1.50 2.00]

// Fog bloom falloff (how quickly bloom fades in fog, lower = farther reach)
#define VFOG_BLOOM_FALLOFF 0.40// [0.10 0.20 0.30 0.40 0.50 0.60 0.70 0.80 0.90 1.00]

// ----------------------------------------------------------------------------
//   Chunk Border Fog (for no-DH distant cutoff)
// ----------------------------------------------------------------------------

// Add a dedicated volumetric fog band at the vanilla chunk cutoff when DH is absent.
#define CHUNK_BORDER_FOG_ENABLED
#ifdef CHUNK_BORDER_FOG_ENABLED
#endif

// Start/end as fractions of current client render radius proxy (uniform far).
#define CHUNK_BORDER_FOG_START 0.78 // [0.50 0.55 0.60 0.65 0.70 0.75 0.78 0.80 0.82 0.85 0.88 0.90 0.92]
#define CHUNK_BORDER_FOG_END 0.98   // [0.85 0.88 0.90 0.92 0.94 0.96 0.98 0.99]

// Volumetric material controls.
#define CHUNK_BORDER_FOG_OPACITY 0.80 // [0.10 0.15 0.20 0.25 0.30 0.35 0.40 0.45 0.50 0.55 0.60 0.70 0.80 0.90 1.00]
#define CHUNK_BORDER_FOG_DENSITY 2.00 // [0.30 0.40 0.50 0.60 0.80 1.00 1.20 1.50 2.00 3.00]
#define CHUNK_BORDER_FOG_DEPTH 256.0  // [32.0 48.0 64.0 96.0 128.0 160.0 180.0 200.0 256.0 320.0 384.0 512.0]
#define CHUNK_BORDER_FOG_SCALE 0.0030 // [0.0008 0.0010 0.0015 0.0020 0.0025 0.0030 0.0040 0.0050 0.0060]
#define CHUNK_BORDER_FOG_STEPS 12     // [4 6 8 10 12 16 24]
#define CHUNK_BORDER_FOG_BRIGHTNESS 1.00 // [0.50 0.60 0.70 0.80 0.90 1.00 1.10 1.20 1.30 1.50]

// ----------------------------------------------------------------------------
//   Cave Fog (volumetric fog in underground areas)
// ----------------------------------------------------------------------------

// Volumetric 3D-noise fog in low-skylight areas (caves, mines, ravines).
#define CAVE_FOG_ENABLED
#ifdef CAVE_FOG_ENABLED
#endif

#define CAVE_FOG_DENSITY 1.00  // [0.20 0.30 0.40 0.50 0.60 0.70 0.80 0.90 1.00 1.20 1.50 2.00 2.50 3.00]
#define CAVE_FOG_SCALE 0.015   // [0.005 0.008 0.010 0.012 0.015 0.020 0.025 0.030 0.040 0.050]
#define CAVE_FOG_SPEED 0.30    // [0.00 0.05 0.10 0.15 0.20 0.25 0.30 0.40 0.50 0.60 0.80 1.00]
#define CAVE_FOG_HEIGHT 80     // [40 50 60 70 80 90 100 110 120 130 150 180 200 256]
#define CAVE_FOG_STEPS 8       // [4 6 8 10 12 16]
#define CAVE_FOG_COLOR_R 0.12  // [0.00 0.02 0.04 0.06 0.08 0.10 0.12 0.15 0.18 0.20 0.25 0.30 0.40 0.50]
#define CAVE_FOG_COLOR_G 0.14  // [0.00 0.02 0.04 0.06 0.08 0.10 0.12 0.14 0.16 0.18 0.20 0.25 0.30 0.40 0.50]
#define CAVE_FOG_COLOR_B 0.20  // [0.00 0.02 0.04 0.06 0.08 0.10 0.12 0.15 0.18 0.20 0.25 0.30 0.40 0.50]

// ----------------------------------------------------------------------------
//   Weather Fog (raymarched, shaped fog during rain/thunder)
// ----------------------------------------------------------------------------

// Enable weather fog (visible during rain/thunder, hides clouds, covers sky)
#define WEATHER_FOG_ENABLED

// Fog density — how thick the fog patches are
#define WEATHER_FOG_DENSITY 1.00  // [0.10 0.20 0.30 0.40 0.50 0.60 0.70 0.80 0.90 1.00 1.20 1.50 2.00 2.50 3.00]

// Noise scale — size of fog clumps (smaller = bigger billowing shapes)
#define WEATHER_FOG_SCALE 0.012   // [0.004 0.006 0.008 0.010 0.012 0.015 0.018 0.022 0.028 0.035 0.045]

// Fog animation speed
#define WEATHER_FOG_SPEED 0.40    // [0.00 0.05 0.10 0.15 0.20 0.25 0.30 0.40 0.50 0.60 0.80 1.00]

// Max radius around player that fog is raymarched (blocks)
#define WEATHER_FOG_RADIUS 120    // [32 48 64 80 96 120 144 160 192 256]

// Raymarch step count (higher = more accurate but slower)
#define WEATHER_FOG_STEPS 10      // [4 6 8 10 12 16 20]

// Fog base color (used in normal biomes — biome-specific colors override this automatically)
#define WEATHER_FOG_COLOR_R 0.55  // [0.00 0.05 0.10 0.15 0.20 0.25 0.30 0.35 0.40 0.45 0.50 0.55 0.60 0.62 0.65 0.70 0.75 0.80 0.85 0.90 0.95 1.00]
// Fog color G
#define WEATHER_FOG_COLOR_G 0.50  // [0.00 0.05 0.10 0.15 0.20 0.25 0.30 0.35 0.40 0.45 0.50 0.55 0.60 0.65 0.70 0.75 0.80 0.85 0.90 0.95 1.00]
// Fog color B
#define WEATHER_FOG_COLOR_B 0.75  // [0.00 0.05 0.10 0.15 0.20 0.25 0.30 0.35 0.40 0.45 0.50 0.55 0.60 0.65 0.70 0.75 0.80 0.85 0.90 0.95 1.00]

// Maximum fog opacity (clamp — prevents total whiteout)
#define WEATHER_FOG_MAX_OPACITY 0.92 // [0.20 0.30 0.40 0.50 0.60 0.70 0.75 0.80 0.85 0.90 0.92 0.95 1.00]

// Rain darkness multiplier (1.0 = no darkening, 0.0 = pitch black)
#define WEATHER_RAIN_DARKNESS 0.72 // [0.40 0.45 0.50 0.55 0.60 0.65 0.70 0.72 0.75 0.80 0.85 0.90 0.95 1.00]

// Thunder extra darkness (applied on top of rain darkness during thunderstorms)
#define WEATHER_THUNDER_DARKNESS 0.85 // [0.40 0.50 0.55 0.60 0.65 0.70 0.75 0.80 0.85 0.90 0.95 1.00]

// ----------------------------------------------------------------------------
//   Chunk Fade Out (distance-based)
// ----------------------------------------------------------------------------

#define CHUNK_FADE_OUT_ENABLED
#ifdef CHUNK_FADE_OUT_ENABLED
// Start radius (blocks) around player where fade begins.
#define CHUNK_FADE_OUT_RADIUS 100.0 // [32.0 48.0 64.0 80.0 96.0 100.0 112.0 128.0 144.0 160.0 192.0 224.0 256.0 320.0 384.0 512.0]
#endif

// ----------------------------------------------------------------------------
//   Nether Fog
// ----------------------------------------------------------------------------

// Enable full-volume depth fog in Nether biomes (ignores height limits)
#define NETHER_FOG_ENABLED

// Max fog render distance in the Nether (blocks). Controls where fog becomes fully opaque.
#define NETHER_FOG_DISTANCE 128 // [0 32 48 64 96 128 160 192 256 320 384 512]

// Depth where Nether fog starts (blocks from camera). No fog closer than this.
#define NETHER_DISTANCE_FOG_START 0.0 // [0.0 8.0 16.0 24.0 32.0 48.0 64.0 80.0 96.0 112.0 128.0 160.0 192.0 224.0 256.0 320.0 384.0 512.0]

// Fog density/strength. Higher = thicker fog.
#define NETHER_DISTANCE_FOG_OPACITY 1.00 // [0.00 0.05 0.10 0.15 0.20 0.25 0.30 0.35 0.40 0.45 0.50 0.55 0.60 0.65 0.70 0.75 0.80 0.85 0.90 0.95 1.00 1.25 1.50 2.00 3.00 5.00]

// Nether brightness multiplier. Controls how bright/dark the ambient lighting is in the Nether.
#define NETHER_BRIGHTNESS 1.00 // [0.00 0.05 0.10 0.20 0.30 0.40 0.50 0.60 0.70 0.80 0.90 1.00 1.10 1.25 1.50 2.00 2.50 3.00 4.00 5.00]

// Nether fog color (RGB, 0.0-1.0)
#define NETHER_FOG_R 0.96 // [0.00 0.05 0.10 0.15 0.20 0.25 0.30 0.35 0.40 0.45 0.50 0.55 0.60 0.65 0.70 0.75 0.80 0.85 0.90 0.95 1.00]
#define NETHER_FOG_G 0.28 // [0.00 0.05 0.10 0.15 0.20 0.25 0.30 0.35 0.40 0.45 0.50 0.55 0.60 0.65 0.70 0.75 0.80 0.85 0.90 0.95 1.00]
#define NETHER_FOG_B 0.50 // [0.00 0.05 0.10 0.15 0.20 0.25 0.30 0.35 0.40 0.45 0.50 0.55 0.60 0.65 0.70 0.75 0.80 0.85 0.90 0.95 1.00]

// ============================================================================
//   End Dimension
// ============================================================================

// Master toggle for all End-specific visuals
#define END_SKY_ENABLED

// --- End Sky Colors ---
// Horizon color (rich purple-blue void edge)
#define END_SKY_HORIZON_R 0.10 // [0.00 0.02 0.04 0.06 0.08 0.10 0.15 0.20 0.25 0.30 0.40 0.50]
#define END_SKY_HORIZON_G 0.06 // [0.00 0.02 0.04 0.06 0.08 0.10 0.15 0.20 0.25 0.30 0.40 0.50]
#define END_SKY_HORIZON_B 0.20 // [0.00 0.02 0.04 0.06 0.08 0.10 0.15 0.20 0.25 0.30 0.40 0.50]

// Mid color (deep purple/indigo zone)
#define END_SKY_MID_R 0.12 // [0.00 0.02 0.04 0.06 0.08 0.10 0.12 0.15 0.20 0.25 0.30 0.40 0.50]
#define END_SKY_MID_G 0.06 // [0.00 0.02 0.04 0.06 0.08 0.10 0.12 0.15 0.20 0.25 0.30 0.40 0.50]
#define END_SKY_MID_B 0.25 // [0.00 0.02 0.04 0.06 0.08 0.10 0.12 0.15 0.20 0.25 0.30 0.40 0.50]

// Zenith color (overhead deep indigo)
#define END_SKY_ZENITH_R 0.08 // [0.00 0.02 0.04 0.06 0.08 0.10 0.15 0.20 0.25 0.30 0.40]
#define END_SKY_ZENITH_G 0.04 // [0.00 0.02 0.04 0.06 0.08 0.10 0.15 0.20 0.25 0.30 0.40]
#define END_SKY_ZENITH_B 0.18 // [0.00 0.02 0.04 0.06 0.08 0.10 0.15 0.20 0.25 0.30 0.40]

// Sky brightness
#define END_SKY_BRIGHTNESS 1.00 // [0.25 0.50 0.75 1.00 1.25 1.50 2.00 3.00 4.00]

// --- End Stars ---
#define END_STARS_ENABLED
#define END_STAR_DENSITY 0.40 // [0.10 0.15 0.20 0.25 0.30 0.35 0.40 0.45 0.50 0.60 0.70 0.80]
#define END_STAR_BRIGHTNESS 1.50 // [0.50 0.75 1.00 1.50 2.00 2.50 3.00 4.00 5.00]
#define END_STAR_COLOR_SHIFT 0.70 // [0.00 0.10 0.20 0.30 0.40 0.50 0.60 0.70 0.80 0.90 1.00]

// --- End Nebula ---
#define END_NEBULA_ENABLED
#define END_NEBULA_INTENSITY 0.60 // [0.00 0.10 0.20 0.30 0.40 0.50 0.60 0.70 0.80 0.90 1.00 1.25 1.50 2.00]
#define END_NEBULA_SCALE 1.5 // [0.5 1.0 1.5 2.0 3.0 4.0 5.0 8.0]
#define END_NEBULA_SPEED 0.03 // [0.00 0.005 0.01 0.02 0.03 0.05 0.06 0.08 0.10 0.15 0.20]
// Nebula primary color (deep indigo-purple)
#define END_NEBULA_R1 0.35 // [0.00 0.05 0.10 0.15 0.20 0.25 0.30 0.35 0.40 0.50 0.60 0.70 0.80 0.90 1.00]
#define END_NEBULA_G1 0.10 // [0.00 0.05 0.10 0.15 0.20 0.25 0.30 0.35 0.40 0.50 0.60 0.70 0.80 0.90 1.00]
#define END_NEBULA_B1 0.60 // [0.00 0.05 0.10 0.15 0.20 0.25 0.30 0.35 0.40 0.50 0.60 0.70 0.80 0.90 1.00]
// Nebula secondary color (dark teal-blue)
#define END_NEBULA_R2 0.15 // [0.00 0.05 0.10 0.15 0.20 0.25 0.30 0.35 0.40 0.50 0.60 0.70 0.80 0.90 1.00]
#define END_NEBULA_G2 0.20 // [0.00 0.05 0.10 0.15 0.20 0.25 0.30 0.35 0.40 0.50 0.60 0.70 0.80 0.90 1.00]
#define END_NEBULA_B2 0.50 // [0.00 0.05 0.10 0.15 0.20 0.25 0.30 0.35 0.40 0.50 0.60 0.70 0.80 0.90 1.00]

// --- End Aurora / Void Shimmer ---
#define END_AURORA_ENABLED
#define END_AURORA_INTENSITY 0.40 // [0.00 0.10 0.20 0.30 0.40 0.50 0.60 0.70 0.80 0.90 1.00 1.25 1.50]
#define END_AURORA_SPEED 0.25 // [0.00 0.05 0.10 0.15 0.20 0.25 0.30 0.40 0.50 0.70]
#define END_AURORA_HEIGHT 0.50 // [0.10 0.20 0.30 0.40 0.50 0.60 0.70 0.80]
// Aurora primary color (deep purple)
#define END_AURORA_R1 0.40 // [0.00 0.10 0.20 0.30 0.40 0.50 0.60 0.70 0.80 0.90 1.00]
#define END_AURORA_G1 0.10 // [0.00 0.10 0.20 0.30 0.40 0.50 0.60 0.70 0.80 0.90 1.00]
#define END_AURORA_B1 0.80 // [0.00 0.10 0.20 0.30 0.40 0.50 0.60 0.70 0.80 0.90 1.00]
// Aurora secondary color (cool blue)
#define END_AURORA_R2 0.20 // [0.00 0.10 0.20 0.30 0.40 0.50 0.60 0.70 0.80 0.90 1.00]
#define END_AURORA_G2 0.40 // [0.00 0.10 0.20 0.30 0.40 0.50 0.60 0.70 0.80 0.90 1.00]
#define END_AURORA_B2 0.75 // [0.00 0.10 0.20 0.30 0.40 0.50 0.60 0.70 0.80 0.90 1.00]

// --- End Void Particles ---
#define END_VOID_PARTICLES_ENABLED
#define END_VOID_PARTICLE_DENSITY 0.40 // [0.00 0.10 0.20 0.30 0.40 0.50 0.60 0.70 0.80 0.90 1.00]
#define END_VOID_PARTICLE_BRIGHTNESS 2.0 // [0.50 0.75 1.00 1.50 2.00 3.00 4.00]

// --- End Warp Streaks (fast-flying debris flashing across the sky) ---
#define END_ASTEROIDS_ENABLED
#define END_ASTEROID_DENSITY 0.15 // [0.05 0.08 0.10 0.15 0.20 0.25 0.30 0.40 0.50 0.60 0.70 0.80]
#define END_ASTEROID_SPEED 0.50 // [0.10 0.20 0.30 0.40 0.50 0.70 1.00 1.50 2.00]
#define END_ASTEROID_BRIGHTNESS 1.20 // [0.20 0.30 0.40 0.50 0.60 0.70 0.80 1.00 1.20 1.50 2.00]
#define END_ASTEROID_LENGTH 0.08 // [0.03 0.05 0.08 0.10 0.12 0.15 0.20 0.25 0.30]
#define END_ASTEROID_THICKNESS 0.004 // [0.002 0.003 0.004 0.005 0.007 0.010 0.012 0.015]

// --- End Vortex (swirling void below the island) ---
#define END_VORTEX_ENABLED
#define END_VORTEX_INTENSITY 1.50 // [0.20 0.40 0.60 0.80 1.00 1.25 1.50 2.00 3.00]
#define END_VORTEX_SPEED 0.12 // [0.00 0.05 0.08 0.10 0.12 0.15 0.20 0.30 0.40 0.50]
#define END_VORTEX_ARMS 5.0 // [2.0 3.0 4.0 5.0 6.0 8.0 10.0]
#define END_VORTEX_TIGHTNESS 3.0 // [0.5 1.0 1.5 2.0 2.5 3.0 4.0 5.0 7.0]
#define END_VORTEX_CORE_SIZE 0.12 // [0.05 0.08 0.10 0.12 0.15 0.20 0.25 0.30]
// Vortex color (light streaks and core glow)
#define END_VORTEX_R2 0.45 // [0.00 0.10 0.20 0.30 0.40 0.45 0.50 0.60 0.70 0.80 0.90 1.00]
#define END_VORTEX_G2 0.35 // [0.00 0.10 0.20 0.30 0.35 0.40 0.50 0.60 0.70 0.80 0.90 1.00]
#define END_VORTEX_B2 1.00 // [0.00 0.10 0.20 0.30 0.40 0.50 0.60 0.70 0.80 0.90 1.00]

// --- End Rings (planetary rings around the center island) ---
#define END_RINGS_ENABLED
#define END_RINGS_COUNT 1 // [1 2 3 4 5]
#define END_RINGS_BRIGHTNESS 1.50 // [0.20 0.40 0.60 0.80 1.00 1.25 1.50 2.00 3.00]
#define END_RINGS_SPEED 0.10 // [0.00 0.01 0.02 0.03 0.05 0.08 0.10 0.15 0.20 0.30 0.50]
#define END_RINGS_INNER 150.0 // [40.0 60.0 80.0 100.0 120.0 150.0 200.0 250.0 300.0]
#define END_RINGS_WIDTH 15.0 // [5.0 10.0 15.0 20.0 30.0 40.0 50.0 60.0 80.0]
#define END_RINGS_DEPTH 6.0 // [2.0 4.0 6.0 8.0 10.0 15.0 20.0 30.0]
// Ring color (purple-blue glow)
#define END_RINGS_R 0.45 // [0.00 0.10 0.20 0.30 0.40 0.45 0.50 0.60 0.70 0.80 0.90 1.00]
#define END_RINGS_G 0.25 // [0.00 0.10 0.20 0.25 0.30 0.40 0.50 0.60 0.70 0.80 0.90 1.00]
#define END_RINGS_B 1.00 // [0.00 0.10 0.20 0.30 0.40 0.50 0.60 0.70 0.80 0.90 1.00]

// --- End Void Clouds (volumetric cloud shell wrapping around the island) ---
#define END_VOID_CLOUDS_ENABLED
#define END_VOID_CLOUD_INTENSITY 0.80 // [0.00 0.10 0.20 0.30 0.40 0.50 0.60 0.70 0.80 0.90 1.00 1.10 1.25 1.50]
#define END_VOID_CLOUD_STEPS 16 // [8 12 16 24 32]
#define END_VOID_CLOUD_COVERAGE 0.40 // [0.10 0.15 0.20 0.25 0.30 0.35 0.40 0.45 0.50 0.55 0.60 0.70 0.80]
#define END_VOID_CLOUD_DENSITY 1.00 // [0.25 0.50 0.75 1.00 1.25 1.50 2.00 3.00]
#define END_VOID_CLOUD_SCALE 1.0 // [0.3 0.5 0.7 1.0 1.5 2.0 3.0 5.0]
#define END_VOID_CLOUD_SPEED 0.02 // [0.00 0.005 0.01 0.02 0.03 0.05 0.08 0.10]
#define END_VOID_CLOUD_SWIRL 3.0 // [0.0 0.5 1.0 1.5 2.0 3.0 4.0 5.0 7.0 10.0]
#define END_VOID_CLOUD_SWIRL_SPEED 0.05 // [0.00 0.01 0.02 0.03 0.05 0.08 0.10 0.15]
#define END_VOID_CLOUD_CLEARING 0.40 // [0.10 0.15 0.20 0.25 0.30 0.35 0.40 0.50 0.60 0.70 0.80]
#define END_VOID_CLOUD_EDGE_GLOW 0.30 // [0.00 0.10 0.20 0.30 0.40 0.50 0.60 0.80 1.00]
// Void cloud primary color (#9269FF)
#define END_VOID_CLOUD_R1 0.57 // [0.00 0.05 0.10 0.15 0.20 0.25 0.30 0.40 0.50 0.57 0.60 0.70 0.80 0.90 1.00]
#define END_VOID_CLOUD_G1 0.41 // [0.00 0.05 0.10 0.15 0.20 0.25 0.30 0.40 0.41 0.50 0.60 0.70 0.80 0.90 1.00]
#define END_VOID_CLOUD_B1 1.00 // [0.00 0.05 0.10 0.15 0.20 0.25 0.30 0.40 0.50 0.60 0.70 0.80 0.90 1.00]
// Void cloud secondary color (darker #9269FF)
#define END_VOID_CLOUD_R2 0.30 // [0.00 0.05 0.10 0.15 0.20 0.25 0.30 0.40 0.50 0.60 0.70 0.80 0.90 1.00]
#define END_VOID_CLOUD_G2 0.20 // [0.00 0.05 0.10 0.15 0.20 0.25 0.30 0.40 0.50 0.60 0.70 0.80 0.90 1.00]
#define END_VOID_CLOUD_B2 0.60 // [0.00 0.05 0.10 0.15 0.20 0.25 0.30 0.40 0.50 0.60 0.70 0.80 0.90 1.00]

// --- End Lighting (separate lightmap and bloom for End dimension) ---
// Blocklight in the End — the primary way lit areas stand out from dark terrain
#define END_BLOCKLIGHT_BRIGHTNESS 1.20 // [0.50 0.75 1.00 1.20 1.50 1.75 2.00 2.50 3.00 4.00 5.00]
// Blocklight tint color in the End (purple-magenta tint to match End atmosphere)
#define END_BLOCKLIGHT_R 0.85 // [0.50 0.60 0.70 0.80 0.85 0.90 1.00]
#define END_BLOCKLIGHT_G 0.65 // [0.40 0.50 0.60 0.65 0.70 0.80 0.90 1.00]
#define END_BLOCKLIGHT_B 1.00 // [0.50 0.60 0.70 0.80 0.90 1.00]
// Emissive brightness boost for End (makes glowing blocks pop against dark terrain)
#define END_EMISSIVE_BOOST 1.50 // [1.00 1.25 1.50 1.75 2.00 2.50 3.00 4.00]
// End bloom intensity multiplier (stacks with base BLOOM_INTENSITY, blocks only)
#define END_BLOOM_BOOST 2.00 // [1.00 1.50 2.00 2.50 3.00 4.00 5.00 6.00]

// --- End Ender Particles (floating motes in world space around the player) ---
#define END_ENDER_PARTICLES_ENABLED
#define END_ENDER_PARTICLE_DENSITY 0.35 // [0.10 0.15 0.20 0.25 0.30 0.35 0.40 0.50 0.60 0.70 0.80]
#define END_ENDER_PARTICLE_BRIGHTNESS 1.25 // [0.10 0.20 0.30 0.40 0.50 0.60 0.80 1.00 1.25 1.50 2.00]
#define END_ENDER_PARTICLE_SIZE 0.03 // [0.01 0.02 0.03 0.04 0.05 0.06 0.08 0.10 0.15 0.20]
#define END_ENDER_PARTICLE_SPACING 4.0 // [2.0 3.0 4.0 5.0 6.0 8.0 10.0]
#define END_ENDER_PARTICLE_RANGE 48.0 // [16.0 24.0 32.0 48.0 64.0 96.0 128.0]

// --- End Void Event (cinematic sky collapse & cosmic eye cycle) ---
#define END_EVENT_ENABLED
#define END_EVENT_CYCLE 300.0 // [60.0 120.0 180.0 240.0 300.0 420.0 600.0 900.0 1200.0]
#define END_EVENT_BLACKOUT 10.0 // [3.0 5.0 7.0 10.0 15.0 20.0 30.0 45.0 60.0 90.0 120.0 180.0 300.0 600.0]
#define END_EVENT_EYE_ENABLED
// Eye iris color (purple glow)
#define END_EVENT_EYE_IRIS_R 0.40 // [0.00 0.10 0.20 0.30 0.40 0.50 0.60 0.70 0.80 0.90 1.00]
#define END_EVENT_EYE_IRIS_G 0.10 // [0.00 0.10 0.20 0.30 0.40 0.50 0.60 0.70 0.80 0.90 1.00]
#define END_EVENT_EYE_IRIS_B 0.80 // [0.00 0.10 0.20 0.30 0.40 0.50 0.60 0.70 0.80 0.90 1.00]
// Eye spotlight — theatre-style light cone on the player when the eye is open
#define END_EVENT_SPOTLIGHT_ENABLED
#ifdef END_EVENT_SPOTLIGHT_ENABLED
#endif
#define END_EVENT_SPOTLIGHT_RADIUS 3.5 // [1.0 1.5 2.0 2.5 3.0 3.5 4.0 5.0 7.0 10.0]
#define END_EVENT_SPOTLIGHT_INTENSITY 1.50 // [0.50 0.75 1.00 1.25 1.50 2.00 2.50 3.00]

// --- End Terrain Patches (darkness variation on ground surfaces) ---
#define END_TERRAIN_PATCHES_ENABLED
#ifdef END_TERRAIN_PATCHES_ENABLED
#endif
#define END_TERRAIN_PATCH_STRENGTH 0.25 // [0.05 0.10 0.15 0.20 0.25 0.30 0.40 0.50]
#define END_TERRAIN_PATCH_SCALE 0.15 // [0.05 0.08 0.10 0.12 0.15 0.20 0.25 0.30]

// --- End Fog (atmospheric purple mist) ---
#define END_FOG_ENABLED
#define END_FOG_DISTANCE 256 // [0 32 48 64 96 128 160 192 256 320 384 512]
#define END_FOG_START 8.0 // [0.0 4.0 8.0 16.0 24.0 32.0 48.0 64.0]
#define END_FOG_DENSITY 0.50 // [0.00 0.10 0.20 0.30 0.40 0.50 0.60 0.70 0.80 0.90 1.00 1.25 1.50 2.00]
// End fog color (purple atmospheric mist)
#define END_FOG_R 0.12 // [0.00 0.02 0.04 0.06 0.08 0.10 0.12 0.15 0.20 0.25 0.30]
#define END_FOG_G 0.06 // [0.00 0.02 0.04 0.06 0.08 0.10 0.15 0.20 0.25 0.30]
#define END_FOG_B 0.22 // [0.00 0.02 0.04 0.06 0.08 0.10 0.15 0.20 0.22 0.25 0.30]


// ----------------------------------------------------------------------------
//   Sun Rays (Screen-Space Crepuscular Rays)
// ----------------------------------------------------------------------------

// Cinematic screen-space sun shafts (crepuscular rays).
// This is NOT volumetric fog: it is a post effect driven by sun screen position + depth occlusion.
// Great for "beams between trees" without turning the whole fog into a wall.
#define SS_SUN_SHAFTS_ENABLED
//#define SS_SUN_SHAFTS_DEBUG

// Where the effect is applied:
// 0 = Sky only (recommended: shows rays without brightening surfaces)
// 1 = Sky + Near Scene (rays can lightly affect nearby geometry)
// 2 = Near Scene only (no rays visible in sky)
#define SS_SHAFT_RECEIVER_MODE 1 // [0 1 2]

// Sample count (higher = smoother, slower)
#define SS_SHAFT_SAMPLES 96// [16 24 32 48 64 96]

// Overall brightness of shafts
#define SS_SHAFT_INTENSITY 0.6 // [0.00 0.05 0.10 0.20 0.30 0.40 0.50 0.60 0.70 0.80 0.90 1.00 1.25 1.50 2.00]

// Decay per step (higher = longer rays)
#define SS_SHAFT_DECAY 0.95// [0.85 0.88 0.90 0.92 0.94 0.95 0.96 0.97 0.98]

// Density controls how quickly we march toward the sun (higher = more concentrated)
#define SS_SHAFT_DENSITY 1.50// [0.25 0.40 0.55 0.70 0.85 1.00 1.25 1.50]

// Weight per sample
#define SS_SHAFT_WEIGHT 0.05// [0.005 0.01 0.015 0.02 0.03 0.04 0.05]

// Skip effect when local skylight is low (prevents indoor/under-bridge blowouts)
#define SS_SHAFT_SKYLIGHT_MIN 0.08 // [0.00 0.02 0.05 0.08 0.10 0.15 0.20 0.30]

// Clamp max luminance contribution (anti-blindness)
#define SS_SHAFT_MAX_LUM 0.70 // [0.20 0.30 0.40 0.50 0.60 0.70 0.80 0.90 1.00]

// Depth limiter: only apply shafts to nearby scene depth (prevents distant haze / sky wash)
// Distances are in blocks (view distance units).
#define SS_SHAFT_DEPTH_START 48.0 // [8.0 16.0 24.0 32.0 48.0 64.0 96.0 128.0]
#define SS_SHAFT_DEPTH_END 180.0 // [64.0 96.0 128.0 160.0 180.0 220.0 260.0 320.0 400.0]

// ----------------------------------------------------------------------------
//   Horizon Fog (Non-Volumetric Distant Layer)
// ----------------------------------------------------------------------------

// Enable horizon fog - a distant atmospheric layer you never reach
//#define HORIZON_FOG_ENABLED

// --- Vertical Position (view angle, not world Y) ---
// Horizon height (0 = horizon line, 1 = zenith, -1 = nadir)
#define HFOG_HEIGHT -0.50// [-0.50 -0.40 -0.30 -0.20 -0.15 -0.10 -0.05 0.00 0.05 0.10 0.15 0.20 0.30 0.40 0.50]

// Bottom of horizon fog layer (view angle, 0 = horizon)
#define HFOG_BOTTOM -0.50// [-0.50 -0.40 -0.30 -0.25 -0.20 -0.15 -0.10 -0.05 0.00 0.05 0.10]

// Top of horizon fog layer (view angle)
#define HFOG_TOP 0.10// [0.00 0.05 0.10 0.15 0.20 0.25 0.30 0.35 0.40 0.50 0.60 0.70 0.80]

// --- Fades ---
// Fade distance at bottom edge (smoother transition)
#define HFOG_FADE_BOTTOM 0.08 // [0.00 0.02 0.04 0.06 0.08 0.10 0.12 0.15 0.20 0.25 0.30]

// Fade distance at top edge
#define HFOG_FADE_TOP 0.30// [0.00 0.02 0.04 0.06 0.08 0.10 0.12 0.15 0.20 0.25 0.30 0.40 0.50]

// --- Appearance ---
// Horizon fog opacity (0 = invisible, 1 = solid)
#define HFOG_OPACITY 0.35// [0.00 0.05 0.10 0.15 0.20 0.25 0.30 0.35 0.40 0.45 0.50 0.55 0.60 0.65 0.70 0.75 0.80 0.85 0.90 0.95 1.00]

// Horizon fog brightness multiplier
#define HFOG_BRIGHTNESS 1.20// [0.20 0.30 0.40 0.50 0.60 0.70 0.80 0.85 0.90 0.95 1.00 1.10 1.20 1.30 1.50 2.00]

// Add bloom/glow to horizon fog
#define HFOG_BLOOM

// Bloom intensity for horizon fog (when HFOG_BLOOM is enabled)
#define HFOG_BLOOM_INTENSITY 0.40// [0.00 0.05 0.10 0.15 0.20 0.25 0.30 0.35 0.40 0.50 0.60 0.70 0.80 1.00]

// Use same color as sky horizon (recommended) or custom color
//#define HFOG_USE_SKY_COLOR

// Custom horizon fog color - Noon (when HFOG_USE_SKY_COLOR is disabled)
#define HFOG_NOON_R 0.55// [0.00 0.05 0.10 0.15 0.20 0.25 0.30 0.35 0.40 0.45 0.50 0.55 0.60 0.65 0.70 0.75 0.80 0.85 0.90 0.95 1.00]
#define HFOG_NOON_G 1.00// [0.00 0.05 0.10 0.15 0.20 0.25 0.30 0.35 0.40 0.45 0.50 0.55 0.60 0.65 0.70 0.75 0.80 0.85 0.90 0.95 1.00]
#define HFOG_NOON_B 1.00 // [0.00 0.05 0.10 0.15 0.20 0.25 0.30 0.35 0.40 0.45 0.50 0.55 0.60 0.65 0.70 0.75 0.80 0.85 0.90 0.95 1.00]

// Custom horizon fog color - Sunset
#define HFOG_SUNSET_R 1.00 // [0.00 0.05 0.10 0.15 0.20 0.25 0.30 0.35 0.40 0.45 0.50 0.55 0.60 0.65 0.70 0.75 0.80 0.85 0.90 0.95 1.00]
#define HFOG_SUNSET_G 0.60 // [0.00 0.05 0.10 0.15 0.20 0.25 0.30 0.35 0.40 0.45 0.50 0.55 0.60 0.65 0.70 0.75 0.80 0.85 0.90 0.95 1.00]
#define HFOG_SUNSET_B 0.40 // [0.00 0.05 0.10 0.15 0.20 0.25 0.30 0.35 0.40 0.45 0.50 0.55 0.60 0.65 0.70 0.75 0.80 0.85 0.90 0.95 1.00]

// Custom horizon fog color - Midnight
#define HFOG_MIDNIGHT_R 0.90// [0.00 0.05 0.10 0.15 0.20 0.25 0.30 0.35 0.40 0.45 0.50 0.55 0.60 0.65 0.70 0.75 0.80 0.85 0.90 0.95 1.00]
#define HFOG_MIDNIGHT_G 0.00// [0.00 0.05 0.10 0.15 0.20 0.25 0.30 0.35 0.40 0.45 0.50 0.55 0.60 0.65 0.70 0.75 0.80 0.85 0.90 0.95 1.00]
#define HFOG_MIDNIGHT_B 1.00// [0.00 0.05 0.10 0.15 0.20 0.25 0.30 0.35 0.40 0.45 0.50 0.55 0.60 0.65 0.70 0.75 0.80 0.85 0.90 0.95 1.00]

// ============================================================================
//   Y-Fade (Global vertical color tint)
// ============================================================================

// Enable/disable the Y-Fade effect
//#define Y_FADE_ENABLED

// World Y level where the tint is at full strength (everything below is fully tinted)
#define YFADE_BOTTOM_Y 0.0// [0.0 10.0 20.0 30.0 40.0 50.0 60.0 70.0 80.0 90.0 100.0]

// World Y level where the tint fades to zero (everything above has no tint)
#define YFADE_TOP_Y 200.0// [40.0 50.0 60.0 70.0 80.0 90.0 100.0 110.0 120.0 128.0 150.0 180.0 200.0 256.0 320.0]

// Fade tint color (RGB)
#define YFADE_COLOR_R 0.60// [0.00 0.05 0.10 0.15 0.20 0.25 0.30 0.35 0.40 0.45 0.50 0.55 0.60 0.65 0.70 0.75 0.80 0.85 0.90 0.95 1.00]
#define YFADE_COLOR_G 0.80// [0.00 0.05 0.10 0.15 0.20 0.25 0.30 0.35 0.40 0.45 0.50 0.55 0.60 0.65 0.70 0.75 0.80 0.85 0.90 0.95 1.00]
#define YFADE_COLOR_B 0.30 // [0.00 0.05 0.10 0.15 0.20 0.25 0.30 0.35 0.40 0.45 0.50 0.55 0.60 0.65 0.70 0.75 0.80 0.85 0.90 0.95 1.00]

// How strong the color tint is (0 = no effect, 1 = full color replacement)
#define YFADE_OPACITY 0.50 // [0.00 0.05 0.10 0.15 0.20 0.25 0.30 0.35 0.40 0.45 0.50 0.55 0.60 0.65 0.70 0.75 0.80 0.85 0.90 0.95 1.00]

// ============================================================================
// =====                          WATER                                   =====
// ============================================================================

// Sea level offset (moves shader world up/down)
#define SEA_LEVEL_OFFSET 65// [-4000 -3999 -3998 -3997 -3996 -3995 -3994 -3993 -3992 -3991 -3990 -3989 -3988 -3987 -3986 -3985 -3984 -3983 -3982 -3981 -3980 -3979 -3978 -3977 -3976 -3975 -3974 -3973 -3972 -3971 -3970 -3969 -3968 -3967 -3966 -3965 -3964 -3963 -3962 -3961 -3960 -3959 -3958 -3957 -3956 -3955 -3954 -3953 -3952 -3951 -3950 -3949 -3948 -3947 -3946 -3945 -3944 -3943 -3942 -3941 -3940 -3939 -3938 -3937 -3936 -3935 -3934 -3933 -3932 -3931 -3930 -3929 -3928 -3927 -3926 -3925 -3924 -3923 -3922 -3921 -3920 -3919 -3918 -3917 -3916 -3915 -3914 -3913 -3912 -3911 -3910 -3909 -3908 -3907 -3906 -3905 -3904 -3903 -3902 -3901 -3900 -3899 -3898 -3897 -3896 -3895 -3894 -3893 -3892 -3891 -3890 -3889 -3888 -3887 -3886 -3885 -3884 -3883 -3882 -3881 -3880 -3879 -3878 -3877 -3876 -3875 -3874 -3873 -3872 -3871 -3870 -3869 -3868 -3867 -3866 -3865 -3864 -3863 -3862 -3861 -3860 -3859 -3858 -3857 -3856 -3855 -3854 -3853 -3852 -3851 -3850 -3849 -3848 -3847 -3846 -3845 -3844 -3843 -3842 -3841 -3840 -3839 -3838 -3837 -3836 -3835 -3834 -3833 -3832 -3831 -3830 -3829 -3828 -3827 -3826 -3825 -3824 -3823 -3822 -3821 -3820 -3819 -3818 -3817 -3816 -3815 -3814 -3813 -3812 -3811 -3810 -3809 -3808 -3807 -3806 -3805 -3804 -3803 -3802 -3801 -3800 -3799 -3798 -3797 -3796 -3795 -3794 -3793 -3792 -3791 -3790 -3789 -3788 -3787 -3786 -3785 -3784 -3783 -3782 -3781 -3780 -3779 -3778 -3777 -3776 -3775 -3774 -3773 -3772 -3771 -3770 -3769 -3768 -3767 -3766 -3765 -3764 -3763 -3762 -3761 -3760 -3759 -3758 -3757 -3756 -3755 -3754 -3753 -3752 -3751 -3750 -3749 -3748 -3747 -3746 -3745 -3744 -3743 -3742 -3741 -3740 -3739 -3738 -3737 -3736 -3735 -3734 -3733 -3732 -3731 -3730 -3729 -3728 -3727 -3726 -3725 -3724 -3723 -3722 -3721 -3720 -3719 -3718 -3717 -3716 -3715 -3714 -3713 -3712 -3711 -3710 -3709 -3708 -3707 -3706 -3705 -3704 -3703 -3702 -3701 -3700 -3699 -3698 -3697 -3696 -3695 -3694 -3693 -3692 -3691 -3690 -3689 -3688 -3687 -3686 -3685 -3684 -3683 -3682 -3681 -3680 -3679 -3678 -3677 -3676 -3675 -3674 -3673 -3672 -3671 -3670 -3669 -3668 -3667 -3666 -3665 -3664 -3663 -3662 -3661 -3660 -3659 -3658 -3657 -3656 -3655 -3654 -3653 -3652 -3651 -3650 -3649 -3648 -3647 -3646 -3645 -3644 -3643 -3642 -3641 -3640 -3639 -3638 -3637 -3636 -3635 -3634 -3633 -3632 -3631 -3630 -3629 -3628 -3627 -3626 -3625 -3624 -3623 -3622 -3621 -3620 -3619 -3618 -3617 -3616 -3615 -3614 -3613 -3612 -3611 -3610 -3609 -3608 -3607 -3606 -3605 -3604 -3603 -3602 -3601 -3600 -3599 -3598 -3597 -3596 -3595 -3594 -3593 -3592 -3591 -3590 -3589 -3588 -3587 -3586 -3585 -3584 -3583 -3582 -3581 -3580 -3579 -3578 -3577 -3576 -3575 -3574 -3573 -3572 -3571 -3570 -3569 -3568 -3567 -3566 -3565 -3564 -3563 -3562 -3561 -3560 -3559 -3558 -3557 -3556 -3555 -3554 -3553 -3552 -3551 -3550 -3549 -3548 -3547 -3546 -3545 -3544 -3543 -3542 -3541 -3540 -3539 -3538 -3537 -3536 -3535 -3534 -3533 -3532 -3531 -3530 -3529 -3528 -3527 -3526 -3525 -3524 -3523 -3522 -3521 -3520 -3519 -3518 -3517 -3516 -3515 -3514 -3513 -3512 -3511 -3510 -3509 -3508 -3507 -3506 -3505 -3504 -3503 -3502 -3501 -3500 -3499 -3498 -3497 -3496 -3495 -3494 -3493 -3492 -3491 -3490 -3489 -3488 -3487 -3486 -3485 -3484 -3483 -3482 -3481 -3480 -3479 -3478 -3477 -3476 -3475 -3474 -3473 -3472 -3471 -3470 -3469 -3468 -3467 -3466 -3465 -3464 -3463 -3462 -3461 -3460 -3459 -3458 -3457 -3456 -3455 -3454 -3453 -3452 -3451 -3450 -3449 -3448 -3447 -3446 -3445 -3444 -3443 -3442 -3441 -3440 -3439 -3438 -3437 -3436 -3435 -3434 -3433 -3432 -3431 -3430 -3429 -3428 -3427 -3426 -3425 -3424 -3423 -3422 -3421 -3420 -3419 -3418 -3417 -3416 -3415 -3414 -3413 -3412 -3411 -3410 -3409 -3408 -3407 -3406 -3405 -3404 -3403 -3402 -3401 -3400 -3399 -3398 -3397 -3396 -3395 -3394 -3393 -3392 -3391 -3390 -3389 -3388 -3387 -3386 -3385 -3384 -3383 -3382 -3381 -3380 -3379 -3378 -3377 -3376 -3375 -3374 -3373 -3372 -3371 -3370 -3369 -3368 -3367 -3366 -3365 -3364 -3363 -3362 -3361 -3360 -3359 -3358 -3357 -3356 -3355 -3354 -3353 -3352 -3351 -3350 -3349 -3348 -3347 -3346 -3345 -3344 -3343 -3342 -3341 -3340 -3339 -3338 -3337 -3336 -3335 -3334 -3333 -3332 -3331 -3330 -3329 -3328 -3327 -3326 -3325 -3324 -3323 -3322 -3321 -3320 -3319 -3318 -3317 -3316 -3315 -3314 -3313 -3312 -3311 -3310 -3309 -3308 -3307 -3306 -3305 -3304 -3303 -3302 -3301 -3300 -3299 -3298 -3297 -3296 -3295 -3294 -3293 -3292 -3291 -3290 -3289 -3288 -3287 -3286 -3285 -3284 -3283 -3282 -3281 -3280 -3279 -3278 -3277 -3276 -3275 -3274 -3273 -3272 -3271 -3270 -3269 -3268 -3267 -3266 -3265 -3264 -3263 -3262 -3261 -3260 -3259 -3258 -3257 -3256 -3255 -3254 -3253 -3252 -3251 -3250 -3249 -3248 -3247 -3246 -3245 -3244 -3243 -3242 -3241 -3240 -3239 -3238 -3237 -3236 -3235 -3234 -3233 -3232 -3231 -3230 -3229 -3228 -3227 -3226 -3225 -3224 -3223 -3222 -3221 -3220 -3219 -3218 -3217 -3216 -3215 -3214 -3213 -3212 -3211 -3210 -3209 -3208 -3207 -3206 -3205 -3204 -3203 -3202 -3201 -3200 -3199 -3198 -3197 -3196 -3195 -3194 -3193 -3192 -3191 -3190 -3189 -3188 -3187 -3186 -3185 -3184 -3183 -3182 -3181 -3180 -3179 -3178 -3177 -3176 -3175 -3174 -3173 -3172 -3171 -3170 -3169 -3168 -3167 -3166 -3165 -3164 -3163 -3162 -3161 -3160 -3159 -3158 -3157 -3156 -3155 -3154 -3153 -3152 -3151 -3150 -3149 -3148 -3147 -3146 -3145 -3144 -3143 -3142 -3141 -3140 -3139 -3138 -3137 -3136 -3135 -3134 -3133 -3132 -3131 -3130 -3129 -3128 -3127 -3126 -3125 -3124 -3123 -3122 -3121 -3120 -3119 -3118 -3117 -3116 -3115 -3114 -3113 -3112 -3111 -3110 -3109 -3108 -3107 -3106 -3105 -3104 -3103 -3102 -3101 -3100 -3099 -3098 -3097 -3096 -3095 -3094 -3093 -3092 -3091 -3090 -3089 -3088 -3087 -3086 -3085 -3084 -3083 -3082 -3081 -3080 -3079 -3078 -3077 -3076 -3075 -3074 -3073 -3072 -3071 -3070 -3069 -3068 -3067 -3066 -3065 -3064 -3063 -3062 -3061 -3060 -3059 -3058 -3057 -3056 -3055 -3054 -3053 -3052 -3051 -3050 -3049 -3048 -3047 -3046 -3045 -3044 -3043 -3042 -3041 -3040 -3039 -3038 -3037 -3036 -3035 -3034 -3033 -3032 -3031 -3030 -3029 -3028 -3027 -3026 -3025 -3024 -3023 -3022 -3021 -3020 -3019 -3018 -3017 -3016 -3015 -3014 -3013 -3012 -3011 -3010 -3009 -3008 -3007 -3006 -3005 -3004 -3003 -3002 -3001 -3000 -2999 -2998 -2997 -2996 -2995 -2994 -2993 -2992 -2991 -2990 -2989 -2988 -2987 -2986 -2985 -2984 -2983 -2982 -2981 -2980 -2979 -2978 -2977 -2976 -2975 -2974 -2973 -2972 -2971 -2970 -2969 -2968 -2967 -2966 -2965 -2964 -2963 -2962 -2961 -2960 -2959 -2958 -2957 -2956 -2955 -2954 -2953 -2952 -2951 -2950 -2949 -2948 -2947 -2946 -2945 -2944 -2943 -2942 -2941 -2940 -2939 -2938 -2937 -2936 -2935 -2934 -2933 -2932 -2931 -2930 -2929 -2928 -2927 -2926 -2925 -2924 -2923 -2922 -2921 -2920 -2919 -2918 -2917 -2916 -2915 -2914 -2913 -2912 -2911 -2910 -2909 -2908 -2907 -2906 -2905 -2904 -2903 -2902 -2901 -2900 -2899 -2898 -2897 -2896 -2895 -2894 -2893 -2892 -2891 -2890 -2889 -2888 -2887 -2886 -2885 -2884 -2883 -2882 -2881 -2880 -2879 -2878 -2877 -2876 -2875 -2874 -2873 -2872 -2871 -2870 -2869 -2868 -2867 -2866 -2865 -2864 -2863 -2862 -2861 -2860 -2859 -2858 -2857 -2856 -2855 -2854 -2853 -2852 -2851 -2850 -2849 -2848 -2847 -2846 -2845 -2844 -2843 -2842 -2841 -2840 -2839 -2838 -2837 -2836 -2835 -2834 -2833 -2832 -2831 -2830 -2829 -2828 -2827 -2826 -2825 -2824 -2823 -2822 -2821 -2820 -2819 -2818 -2817 -2816 -2815 -2814 -2813 -2812 -2811 -2810 -2809 -2808 -2807 -2806 -2805 -2804 -2803 -2802 -2801 -2800 -2799 -2798 -2797 -2796 -2795 -2794 -2793 -2792 -2791 -2790 -2789 -2788 -2787 -2786 -2785 -2784 -2783 -2782 -2781 -2780 -2779 -2778 -2777 -2776 -2775 -2774 -2773 -2772 -2771 -2770 -2769 -2768 -2767 -2766 -2765 -2764 -2763 -2762 -2761 -2760 -2759 -2758 -2757 -2756 -2755 -2754 -2753 -2752 -2751 -2750 -2749 -2748 -2747 -2746 -2745 -2744 -2743 -2742 -2741 -2740 -2739 -2738 -2737 -2736 -2735 -2734 -2733 -2732 -2731 -2730 -2729 -2728 -2727 -2726 -2725 -2724 -2723 -2722 -2721 -2720 -2719 -2718 -2717 -2716 -2715 -2714 -2713 -2712 -2711 -2710 -2709 -2708 -2707 -2706 -2705 -2704 -2703 -2702 -2701 -2700 -2699 -2698 -2697 -2696 -2695 -2694 -2693 -2692 -2691 -2690 -2689 -2688 -2687 -2686 -2685 -2684 -2683 -2682 -2681 -2680 -2679 -2678 -2677 -2676 -2675 -2674 -2673 -2672 -2671 -2670 -2669 -2668 -2667 -2666 -2665 -2664 -2663 -2662 -2661 -2660 -2659 -2658 -2657 -2656 -2655 -2654 -2653 -2652 -2651 -2650 -2649 -2648 -2647 -2646 -2645 -2644 -2643 -2642 -2641 -2640 -2639 -2638 -2637 -2636 -2635 -2634 -2633 -2632 -2631 -2630 -2629 -2628 -2627 -2626 -2625 -2624 -2623 -2622 -2621 -2620 -2619 -2618 -2617 -2616 -2615 -2614 -2613 -2612 -2611 -2610 -2609 -2608 -2607 -2606 -2605 -2604 -2603 -2602 -2601 -2600 -2599 -2598 -2597 -2596 -2595 -2594 -2593 -2592 -2591 -2590 -2589 -2588 -2587 -2586 -2585 -2584 -2583 -2582 -2581 -2580 -2579 -2578 -2577 -2576 -2575 -2574 -2573 -2572 -2571 -2570 -2569 -2568 -2567 -2566 -2565 -2564 -2563 -2562 -2561 -2560 -2559 -2558 -2557 -2556 -2555 -2554 -2553 -2552 -2551 -2550 -2549 -2548 -2547 -2546 -2545 -2544 -2543 -2542 -2541 -2540 -2539 -2538 -2537 -2536 -2535 -2534 -2533 -2532 -2531 -2530 -2529 -2528 -2527 -2526 -2525 -2524 -2523 -2522 -2521 -2520 -2519 -2518 -2517 -2516 -2515 -2514 -2513 -2512 -2511 -2510 -2509 -2508 -2507 -2506 -2505 -2504 -2503 -2502 -2501 -2500 -2499 -2498 -2497 -2496 -2495 -2494 -2493 -2492 -2491 -2490 -2489 -2488 -2487 -2486 -2485 -2484 -2483 -2482 -2481 -2480 -2479 -2478 -2477 -2476 -2475 -2474 -2473 -2472 -2471 -2470 -2469 -2468 -2467 -2466 -2465 -2464 -2463 -2462 -2461 -2460 -2459 -2458 -2457 -2456 -2455 -2454 -2453 -2452 -2451 -2450 -2449 -2448 -2447 -2446 -2445 -2444 -2443 -2442 -2441 -2440 -2439 -2438 -2437 -2436 -2435 -2434 -2433 -2432 -2431 -2430 -2429 -2428 -2427 -2426 -2425 -2424 -2423 -2422 -2421 -2420 -2419 -2418 -2417 -2416 -2415 -2414 -2413 -2412 -2411 -2410 -2409 -2408 -2407 -2406 -2405 -2404 -2403 -2402 -2401 -2400 -2399 -2398 -2397 -2396 -2395 -2394 -2393 -2392 -2391 -2390 -2389 -2388 -2387 -2386 -2385 -2384 -2383 -2382 -2381 -2380 -2379 -2378 -2377 -2376 -2375 -2374 -2373 -2372 -2371 -2370 -2369 -2368 -2367 -2366 -2365 -2364 -2363 -2362 -2361 -2360 -2359 -2358 -2357 -2356 -2355 -2354 -2353 -2352 -2351 -2350 -2349 -2348 -2347 -2346 -2345 -2344 -2343 -2342 -2341 -2340 -2339 -2338 -2337 -2336 -2335 -2334 -2333 -2332 -2331 -2330 -2329 -2328 -2327 -2326 -2325 -2324 -2323 -2322 -2321 -2320 -2319 -2318 -2317 -2316 -2315 -2314 -2313 -2312 -2311 -2310 -2309 -2308 -2307 -2306 -2305 -2304 -2303 -2302 -2301 -2300 -2299 -2298 -2297 -2296 -2295 -2294 -2293 -2292 -2291 -2290 -2289 -2288 -2287 -2286 -2285 -2284 -2283 -2282 -2281 -2280 -2279 -2278 -2277 -2276 -2275 -2274 -2273 -2272 -2271 -2270 -2269 -2268 -2267 -2266 -2265 -2264 -2263 -2262 -2261 -2260 -2259 -2258 -2257 -2256 -2255 -2254 -2253 -2252 -2251 -2250 -2249 -2248 -2247 -2246 -2245 -2244 -2243 -2242 -2241 -2240 -2239 -2238 -2237 -2236 -2235 -2234 -2233 -2232 -2231 -2230 -2229 -2228 -2227 -2226 -2225 -2224 -2223 -2222 -2221 -2220 -2219 -2218 -2217 -2216 -2215 -2214 -2213 -2212 -2211 -2210 -2209 -2208 -2207 -2206 -2205 -2204 -2203 -2202 -2201 -2200 -2199 -2198 -2197 -2196 -2195 -2194 -2193 -2192 -2191 -2190 -2189 -2188 -2187 -2186 -2185 -2184 -2183 -2182 -2181 -2180 -2179 -2178 -2177 -2176 -2175 -2174 -2173 -2172 -2171 -2170 -2169 -2168 -2167 -2166 -2165 -2164 -2163 -2162 -2161 -2160 -2159 -2158 -2157 -2156 -2155 -2154 -2153 -2152 -2151 -2150 -2149 -2148 -2147 -2146 -2145 -2144 -2143 -2142 -2141 -2140 -2139 -2138 -2137 -2136 -2135 -2134 -2133 -2132 -2131 -2130 -2129 -2128 -2127 -2126 -2125 -2124 -2123 -2122 -2121 -2120 -2119 -2118 -2117 -2116 -2115 -2114 -2113 -2112 -2111 -2110 -2109 -2108 -2107 -2106 -2105 -2104 -2103 -2102 -2101 -2100 -2099 -2098 -2097 -2096 -2095 -2094 -2093 -2092 -2091 -2090 -2089 -2088 -2087 -2086 -2085 -2084 -2083 -2082 -2081 -2080 -2079 -2078 -2077 -2076 -2075 -2074 -2073 -2072 -2071 -2070 -2069 -2068 -2067 -2066 -2065 -2064 -2063 -2062 -2061 -2060 -2059 -2058 -2057 -2056 -2055 -2054 -2053 -2052 -2051 -2050 -2049 -2048 -2047 -2046 -2045 -2044 -2043 -2042 -2041 -2040 -2039 -2038 -2037 -2036 -2035 -2034 -2033 -2032 -2031 -2030 -2029 -2028 -2027 -2026 -2025 -2024 -2023 -2022 -2021 -2020 -2019 -2018 -2017 -2016 -2015 -2014 -2013 -2012 -2011 -2010 -2009 -2008 -2007 -2006 -2005 -2004 -2003 -2002 -2001 -2000 -1999 -1998 -1997 -1996 -1995 -1994 -1993 -1992 -1991 -1990 -1989 -1988 -1987 -1986 -1985 -1984 -1983 -1982 -1981 -1980 -1979 -1978 -1977 -1976 -1975 -1974 -1973 -1972 -1971 -1970 -1969 -1968 -1967 -1966 -1965 -1964 -1963 -1962 -1961 -1960 -1959 -1958 -1957 -1956 -1955 -1954 -1953 -1952 -1951 -1950 -1949 -1948 -1947 -1946 -1945 -1944 -1943 -1942 -1941 -1940 -1939 -1938 -1937 -1936 -1935 -1934 -1933 -1932 -1931 -1930 -1929 -1928 -1927 -1926 -1925 -1924 -1923 -1922 -1921 -1920 -1919 -1918 -1917 -1916 -1915 -1914 -1913 -1912 -1911 -1910 -1909 -1908 -1907 -1906 -1905 -1904 -1903 -1902 -1901 -1900 -1899 -1898 -1897 -1896 -1895 -1894 -1893 -1892 -1891 -1890 -1889 -1888 -1887 -1886 -1885 -1884 -1883 -1882 -1881 -1880 -1879 -1878 -1877 -1876 -1875 -1874 -1873 -1872 -1871 -1870 -1869 -1868 -1867 -1866 -1865 -1864 -1863 -1862 -1861 -1860 -1859 -1858 -1857 -1856 -1855 -1854 -1853 -1852 -1851 -1850 -1849 -1848 -1847 -1846 -1845 -1844 -1843 -1842 -1841 -1840 -1839 -1838 -1837 -1836 -1835 -1834 -1833 -1832 -1831 -1830 -1829 -1828 -1827 -1826 -1825 -1824 -1823 -1822 -1821 -1820 -1819 -1818 -1817 -1816 -1815 -1814 -1813 -1812 -1811 -1810 -1809 -1808 -1807 -1806 -1805 -1804 -1803 -1802 -1801 -1800 -1799 -1798 -1797 -1796 -1795 -1794 -1793 -1792 -1791 -1790 -1789 -1788 -1787 -1786 -1785 -1784 -1783 -1782 -1781 -1780 -1779 -1778 -1777 -1776 -1775 -1774 -1773 -1772 -1771 -1770 -1769 -1768 -1767 -1766 -1765 -1764 -1763 -1762 -1761 -1760 -1759 -1758 -1757 -1756 -1755 -1754 -1753 -1752 -1751 -1750 -1749 -1748 -1747 -1746 -1745 -1744 -1743 -1742 -1741 -1740 -1739 -1738 -1737 -1736 -1735 -1734 -1733 -1732 -1731 -1730 -1729 -1728 -1727 -1726 -1725 -1724 -1723 -1722 -1721 -1720 -1719 -1718 -1717 -1716 -1715 -1714 -1713 -1712 -1711 -1710 -1709 -1708 -1707 -1706 -1705 -1704 -1703 -1702 -1701 -1700 -1699 -1698 -1697 -1696 -1695 -1694 -1693 -1692 -1691 -1690 -1689 -1688 -1687 -1686 -1685 -1684 -1683 -1682 -1681 -1680 -1679 -1678 -1677 -1676 -1675 -1674 -1673 -1672 -1671 -1670 -1669 -1668 -1667 -1666 -1665 -1664 -1663 -1662 -1661 -1660 -1659 -1658 -1657 -1656 -1655 -1654 -1653 -1652 -1651 -1650 -1649 -1648 -1647 -1646 -1645 -1644 -1643 -1642 -1641 -1640 -1639 -1638 -1637 -1636 -1635 -1634 -1633 -1632 -1631 -1630 -1629 -1628 -1627 -1626 -1625 -1624 -1623 -1622 -1621 -1620 -1619 -1618 -1617 -1616 -1615 -1614 -1613 -1612 -1611 -1610 -1609 -1608 -1607 -1606 -1605 -1604 -1603 -1602 -1601 -1600 -1599 -1598 -1597 -1596 -1595 -1594 -1593 -1592 -1591 -1590 -1589 -1588 -1587 -1586 -1585 -1584 -1583 -1582 -1581 -1580 -1579 -1578 -1577 -1576 -1575 -1574 -1573 -1572 -1571 -1570 -1569 -1568 -1567 -1566 -1565 -1564 -1563 -1562 -1561 -1560 -1559 -1558 -1557 -1556 -1555 -1554 -1553 -1552 -1551 -1550 -1549 -1548 -1547 -1546 -1545 -1544 -1543 -1542 -1541 -1540 -1539 -1538 -1537 -1536 -1535 -1534 -1533 -1532 -1531 -1530 -1529 -1528 -1527 -1526 -1525 -1524 -1523 -1522 -1521 -1520 -1519 -1518 -1517 -1516 -1515 -1514 -1513 -1512 -1511 -1510 -1509 -1508 -1507 -1506 -1505 -1504 -1503 -1502 -1501 -1500 -1499 -1498 -1497 -1496 -1495 -1494 -1493 -1492 -1491 -1490 -1489 -1488 -1487 -1486 -1485 -1484 -1483 -1482 -1481 -1480 -1479 -1478 -1477 -1476 -1475 -1474 -1473 -1472 -1471 -1470 -1469 -1468 -1467 -1466 -1465 -1464 -1463 -1462 -1461 -1460 -1459 -1458 -1457 -1456 -1455 -1454 -1453 -1452 -1451 -1450 -1449 -1448 -1447 -1446 -1445 -1444 -1443 -1442 -1441 -1440 -1439 -1438 -1437 -1436 -1435 -1434 -1433 -1432 -1431 -1430 -1429 -1428 -1427 -1426 -1425 -1424 -1423 -1422 -1421 -1420 -1419 -1418 -1417 -1416 -1415 -1414 -1413 -1412 -1411 -1410 -1409 -1408 -1407 -1406 -1405 -1404 -1403 -1402 -1401 -1400 -1399 -1398 -1397 -1396 -1395 -1394 -1393 -1392 -1391 -1390 -1389 -1388 -1387 -1386 -1385 -1384 -1383 -1382 -1381 -1380 -1379 -1378 -1377 -1376 -1375 -1374 -1373 -1372 -1371 -1370 -1369 -1368 -1367 -1366 -1365 -1364 -1363 -1362 -1361 -1360 -1359 -1358 -1357 -1356 -1355 -1354 -1353 -1352 -1351 -1350 -1349 -1348 -1347 -1346 -1345 -1344 -1343 -1342 -1341 -1340 -1339 -1338 -1337 -1336 -1335 -1334 -1333 -1332 -1331 -1330 -1329 -1328 -1327 -1326 -1325 -1324 -1323 -1322 -1321 -1320 -1319 -1318 -1317 -1316 -1315 -1314 -1313 -1312 -1311 -1310 -1309 -1308 -1307 -1306 -1305 -1304 -1303 -1302 -1301 -1300 -1299 -1298 -1297 -1296 -1295 -1294 -1293 -1292 -1291 -1290 -1289 -1288 -1287 -1286 -1285 -1284 -1283 -1282 -1281 -1280 -1279 -1278 -1277 -1276 -1275 -1274 -1273 -1272 -1271 -1270 -1269 -1268 -1267 -1266 -1265 -1264 -1263 -1262 -1261 -1260 -1259 -1258 -1257 -1256 -1255 -1254 -1253 -1252 -1251 -1250 -1249 -1248 -1247 -1246 -1245 -1244 -1243 -1242 -1241 -1240 -1239 -1238 -1237 -1236 -1235 -1234 -1233 -1232 -1231 -1230 -1229 -1228 -1227 -1226 -1225 -1224 -1223 -1222 -1221 -1220 -1219 -1218 -1217 -1216 -1215 -1214 -1213 -1212 -1211 -1210 -1209 -1208 -1207 -1206 -1205 -1204 -1203 -1202 -1201 -1200 -1199 -1198 -1197 -1196 -1195 -1194 -1193 -1192 -1191 -1190 -1189 -1188 -1187 -1186 -1185 -1184 -1183 -1182 -1181 -1180 -1179 -1178 -1177 -1176 -1175 -1174 -1173 -1172 -1171 -1170 -1169 -1168 -1167 -1166 -1165 -1164 -1163 -1162 -1161 -1160 -1159 -1158 -1157 -1156 -1155 -1154 -1153 -1152 -1151 -1150 -1149 -1148 -1147 -1146 -1145 -1144 -1143 -1142 -1141 -1140 -1139 -1138 -1137 -1136 -1135 -1134 -1133 -1132 -1131 -1130 -1129 -1128 -1127 -1126 -1125 -1124 -1123 -1122 -1121 -1120 -1119 -1118 -1117 -1116 -1115 -1114 -1113 -1112 -1111 -1110 -1109 -1108 -1107 -1106 -1105 -1104 -1103 -1102 -1101 -1100 -1099 -1098 -1097 -1096 -1095 -1094 -1093 -1092 -1091 -1090 -1089 -1088 -1087 -1086 -1085 -1084 -1083 -1082 -1081 -1080 -1079 -1078 -1077 -1076 -1075 -1074 -1073 -1072 -1071 -1070 -1069 -1068 -1067 -1066 -1065 -1064 -1063 -1062 -1061 -1060 -1059 -1058 -1057 -1056 -1055 -1054 -1053 -1052 -1051 -1050 -1049 -1048 -1047 -1046 -1045 -1044 -1043 -1042 -1041 -1040 -1039 -1038 -1037 -1036 -1035 -1034 -1033 -1032 -1031 -1030 -1029 -1028 -1027 -1026 -1025 -1024 -1023 -1022 -1021 -1020 -1019 -1018 -1017 -1016 -1015 -1014 -1013 -1012 -1011 -1010 -1009 -1008 -1007 -1006 -1005 -1004 -1003 -1002 -1001 -1000 -999 -998 -997 -996 -995 -994 -993 -992 -991 -990 -989 -988 -987 -986 -985 -984 -983 -982 -981 -980 -979 -978 -977 -976 -975 -974 -973 -972 -971 -970 -969 -968 -967 -966 -965 -964 -963 -962 -961 -960 -959 -958 -957 -956 -955 -954 -953 -952 -951 -950 -949 -948 -947 -946 -945 -944 -943 -942 -941 -940 -939 -938 -937 -936 -935 -934 -933 -932 -931 -930 -929 -928 -927 -926 -925 -924 -923 -922 -921 -920 -919 -918 -917 -916 -915 -914 -913 -912 -911 -910 -909 -908 -907 -906 -905 -904 -903 -902 -901 -900 -899 -898 -897 -896 -895 -894 -893 -892 -891 -890 -889 -888 -887 -886 -885 -884 -883 -882 -881 -880 -879 -878 -877 -876 -875 -874 -873 -872 -871 -870 -869 -868 -867 -866 -865 -864 -863 -862 -861 -860 -859 -858 -857 -856 -855 -854 -853 -852 -851 -850 -849 -848 -847 -846 -845 -844 -843 -842 -841 -840 -839 -838 -837 -836 -835 -834 -833 -832 -831 -830 -829 -828 -827 -826 -825 -824 -823 -822 -821 -820 -819 -818 -817 -816 -815 -814 -813 -812 -811 -810 -809 -808 -807 -806 -805 -804 -803 -802 -801 -800 -799 -798 -797 -796 -795 -794 -793 -792 -791 -790 -789 -788 -787 -786 -785 -784 -783 -782 -781 -780 -779 -778 -777 -776 -775 -774 -773 -772 -771 -770 -769 -768 -767 -766 -765 -764 -763 -762 -761 -760 -759 -758 -757 -756 -755 -754 -753 -752 -751 -750 -749 -748 -747 -746 -745 -744 -743 -742 -741 -740 -739 -738 -737 -736 -735 -734 -733 -732 -731 -730 -729 -728 -727 -726 -725 -724 -723 -722 -721 -720 -719 -718 -717 -716 -715 -714 -713 -712 -711 -710 -709 -708 -707 -706 -705 -704 -703 -702 -701 -700 -699 -698 -697 -696 -695 -694 -693 -692 -691 -690 -689 -688 -687 -686 -685 -684 -683 -682 -681 -680 -679 -678 -677 -676 -675 -674 -673 -672 -671 -670 -669 -668 -667 -666 -665 -664 -663 -662 -661 -660 -659 -658 -657 -656 -655 -654 -653 -652 -651 -650 -649 -648 -647 -646 -645 -644 -643 -642 -641 -640 -639 -638 -637 -636 -635 -634 -633 -632 -631 -630 -629 -628 -627 -626 -625 -624 -623 -622 -621 -620 -619 -618 -617 -616 -615 -614 -613 -612 -611 -610 -609 -608 -607 -606 -605 -604 -603 -602 -601 -600 -599 -598 -597 -596 -595 -594 -593 -592 -591 -590 -589 -588 -587 -586 -585 -584 -583 -582 -581 -580 -579 -578 -577 -576 -575 -574 -573 -572 -571 -570 -569 -568 -567 -566 -565 -564 -563 -562 -561 -560 -559 -558 -557 -556 -555 -554 -553 -552 -551 -550 -549 -548 -547 -546 -545 -544 -543 -542 -541 -540 -539 -538 -537 -536 -535 -534 -533 -532 -531 -530 -529 -528 -527 -526 -525 -524 -523 -522 -521 -520 -519 -518 -517 -516 -515 -514 -513 -512 -511 -510 -509 -508 -507 -506 -505 -504 -503 -502 -501 -500 -499 -498 -497 -496 -495 -494 -493 -492 -491 -490 -489 -488 -487 -486 -485 -484 -483 -482 -481 -480 -479 -478 -477 -476 -475 -474 -473 -472 -471 -470 -469 -468 -467 -466 -465 -464 -463 -462 -461 -460 -459 -458 -457 -456 -455 -454 -453 -452 -451 -450 -449 -448 -447 -446 -445 -444 -443 -442 -441 -440 -439 -438 -437 -436 -435 -434 -433 -432 -431 -430 -429 -428 -427 -426 -425 -424 -423 -422 -421 -420 -419 -418 -417 -416 -415 -414 -413 -412 -411 -410 -409 -408 -407 -406 -405 -404 -403 -402 -401 -400 -399 -398 -397 -396 -395 -394 -393 -392 -391 -390 -389 -388 -387 -386 -385 -384 -383 -382 -381 -380 -379 -378 -377 -376 -375 -374 -373 -372 -371 -370 -369 -368 -367 -366 -365 -364 -363 -362 -361 -360 -359 -358 -357 -356 -355 -354 -353 -352 -351 -350 -349 -348 -347 -346 -345 -344 -343 -342 -341 -340 -339 -338 -337 -336 -335 -334 -333 -332 -331 -330 -329 -328 -327 -326 -325 -324 -323 -322 -321 -320 -319 -318 -317 -316 -315 -314 -313 -312 -311 -310 -309 -308 -307 -306 -305 -304 -303 -302 -301 -300 -299 -298 -297 -296 -295 -294 -293 -292 -291 -290 -289 -288 -287 -286 -285 -284 -283 -282 -281 -280 -279 -278 -277 -276 -275 -274 -273 -272 -271 -270 -269 -268 -267 -266 -265 -264 -263 -262 -261 -260 -259 -258 -257 -256 -255 -254 -253 -252 -251 -250 -249 -248 -247 -246 -245 -244 -243 -242 -241 -240 -239 -238 -237 -236 -235 -234 -233 -232 -231 -230 -229 -228 -227 -226 -225 -224 -223 -222 -221 -220 -219 -218 -217 -216 -215 -214 -213 -212 -211 -210 -209 -208 -207 -206 -205 -204 -203 -202 -201 -200 -199 -198 -197 -196 -195 -194 -193 -192 -191 -190 -189 -188 -187 -186 -185 -184 -183 -182 -181 -180 -179 -178 -177 -176 -175 -174 -173 -172 -171 -170 -169 -168 -167 -166 -165 -164 -163 -162 -161 -160 -159 -158 -157 -156 -155 -154 -153 -152 -151 -150 -149 -148 -147 -146 -145 -144 -143 -142 -141 -140 -139 -138 -137 -136 -135 -134 -133 -132 -131 -130 -129 -128 -127 -126 -125 -124 -123 -122 -121 -120 -119 -118 -117 -116 -115 -114 -113 -112 -111 -110 -109 -108 -107 -106 -105 -104 -103 -102 -101 -100 -99 -98 -97 -96 -95 -94 -93 -92 -91 -90 -89 -88 -87 -86 -85 -84 -83 -82 -81 -80 -79 -78 -77 -76 -75 -74 -73 -72 -71 -70 -69 -68 -67 -66 -65 -64 -63 -62 -61 -60 -59 -58 -57 -56 -55 -54 -53 -52 -51 -50 -49 -48 -47 -46 -45 -44 -43 -42 -41 -40 -39 -38 -37 -36 -35 -34 -33 -32 -31 -30 -29 -28 -27 -26 -25 -24 -23 -22 -21 -20 -19 -18 -17 -16 -15 -14 -13 -12 -11 -10 -9 -8 -7 -6 -5 -4 -3 -2 -1 0 1 2 3 4 5 6 7 8 9 10 11 12 13 14 15 16 17 18 19 20 21 22 23 24 25 26 27 28 29 30 31 32 33 34 35 36 37 38 39 40 41 42 43 44 45 46 47 48 49 50 51 52 53 54 55 56 57 58 59 60 61 62 63 64 65 66 67 68 69 70 71 72 73 74 75 76 77 78 79 80 81 82 83 84 85 86 87 88 89 90 91 92 93 94 95 96 97 98 99 100 101 102 103 104 105 106 107 108 109 110 111 112 113 114 115 116 117 118 119 120 121 122 123 124 125 126 127 128 129 130 131 132 133 134 135 136 137 138 139 140 141 142 143 144 145 146 147 148 149 150 151 152 153 154 155 156 157 158 159 160 161 162 163 164 165 166 167 168 169 170 171 172 173 174 175 176 177 178 179 180 181 182 183 184 185 186 187 188 189 190 191 192 193 194 195 196 197 198 199 200 201 202 203 204 205 206 207 208 209 210 211 212 213 214 215 216 217 218 219 220 221 222 223 224 225 226 227 228 229 230 231 232 233 234 235 236 237 238 239 240 241 242 243 244 245 246 247 248 249 250 251 252 253 254 255 256 257 258 259 260 261 262 263 264 265 266 267 268 269 270 271 272 273 274 275 276 277 278 279 280 281 282 283 284 285 286 287 288 289 290 291 292 293 294 295 296 297 298 299 300 301 302 303 304 305 306 307 308 309 310 311 312 313 314 315 316 317 318 319 320 321 322 323 324 325 326 327 328 329 330 331 332 333 334 335 336 337 338 339 340 341 342 343 344 345 346 347 348 349 350 351 352 353 354 355 356 357 358 359 360 361 362 363 364 365 366 367 368 369 370 371 372 373 374 375 376 377 378 379 380 381 382 383 384 385 386 387 388 389 390 391 392 393 394 395 396 397 398 399 400 401 402 403 404 405 406 407 408 409 410 411 412 413 414 415 416 417 418 419 420 421 422 423 424 425 426 427 428 429 430 431 432 433 434 435 436 437 438 439 440 441 442 443 444 445 446 447 448 449 450 451 452 453 454 455 456 457 458 459 460 461 462 463 464 465 466 467 468 469 470 471 472 473 474 475 476 477 478 479 480 481 482 483 484 485 486 487 488 489 490 491 492 493 494 495 496 497 498 499 500 501 502 503 504 505 506 507 508 509 510 511 512 513 514 515 516 517 518 519 520 521 522 523 524 525 526 527 528 529 530 531 532 533 534 535 536 537 538 539 540 541 542 543 544 545 546 547 548 549 550 551 552 553 554 555 556 557 558 559 560 561 562 563 564 565 566 567 568 569 570 571 572 573 574 575 576 577 578 579 580 581 582 583 584 585 586 587 588 589 590 591 592 593 594 595 596 597 598 599 600 601 602 603 604 605 606 607 608 609 610 611 612 613 614 615 616 617 618 619 620 621 622 623 624 625 626 627 628 629 630 631 632 633 634 635 636 637 638 639 640 641 642 643 644 645 646 647 648 649 650 651 652 653 654 655 656 657 658 659 660 661 662 663 664 665 666 667 668 669 670 671 672 673 674 675 676 677 678 679 680 681 682 683 684 685 686 687 688 689 690 691 692 693 694 695 696 697 698 699 700 701 702 703 704 705 706 707 708 709 710 711 712 713 714 715 716 717 718 719 720 721 722 723 724 725 726 727 728 729 730 731 732 733 734 735 736 737 738 739 740 741 742 743 744 745 746 747 748 749 750 751 752 753 754 755 756 757 758 759 760 761 762 763 764 765 766 767 768 769 770 771 772 773 774 775 776 777 778 779 780 781 782 783 784 785 786 787 788 789 790 791 792 793 794 795 796 797 798 799 800 801 802 803 804 805 806 807 808 809 810 811 812 813 814 815 816 817 818 819 820 821 822 823 824 825 826 827 828 829 830 831 832 833 834 835 836 837 838 839 840 841 842 843 844 845 846 847 848 849 850 851 852 853 854 855 856 857 858 859 860 861 862 863 864 865 866 867 868 869 870 871 872 873 874 875 876 877 878 879 880 881 882 883 884 885 886 887 888 889 890 891 892 893 894 895 896 897 898 899 900 901 902 903 904 905 906 907 908 909 910 911 912 913 914 915 916 917 918 919 920 921 922 923 924 925 926 927 928 929 930 931 932 933 934 935 936 937 938 939 940 941 942 943 944 945 946 947 948 949 950 951 952 953 954 955 956 957 958 959 960 961 962 963 964 965 966 967 968 969 970 971 972 973 974 975 976 977 978 979 980 981 982 983 984 985 986 987 988 989 990 991 992 993 994 995 996 997 998 999 1000 1001 1002 1003 1004 1005 1006 1007 1008 1009 1010 1011 1012 1013 1014 1015 1016 1017 1018 1019 1020 1021 1022 1023 1024 1025 1026 1027 1028 1029 1030 1031 1032 1033 1034 1035 1036 1037 1038 1039 1040 1041 1042 1043 1044 1045 1046 1047 1048 1049 1050 1051 1052 1053 1054 1055 1056 1057 1058 1059 1060 1061 1062 1063 1064 1065 1066 1067 1068 1069 1070 1071 1072 1073 1074 1075 1076 1077 1078 1079 1080 1081 1082 1083 1084 1085 1086 1087 1088 1089 1090 1091 1092 1093 1094 1095 1096 1097 1098 1099 1100 1101 1102 1103 1104 1105 1106 1107 1108 1109 1110 1111 1112 1113 1114 1115 1116 1117 1118 1119 1120 1121 1122 1123 1124 1125 1126 1127 1128 1129 1130 1131 1132 1133 1134 1135 1136 1137 1138 1139 1140 1141 1142 1143 1144 1145 1146 1147 1148 1149 1150 1151 1152 1153 1154 1155 1156 1157 1158 1159 1160 1161 1162 1163 1164 1165 1166 1167 1168 1169 1170 1171 1172 1173 1174 1175 1176 1177 1178 1179 1180 1181 1182 1183 1184 1185 1186 1187 1188 1189 1190 1191 1192 1193 1194 1195 1196 1197 1198 1199 1200 1201 1202 1203 1204 1205 1206 1207 1208 1209 1210 1211 1212 1213 1214 1215 1216 1217 1218 1219 1220 1221 1222 1223 1224 1225 1226 1227 1228 1229 1230 1231 1232 1233 1234 1235 1236 1237 1238 1239 1240 1241 1242 1243 1244 1245 1246 1247 1248 1249 1250 1251 1252 1253 1254 1255 1256 1257 1258 1259 1260 1261 1262 1263 1264 1265 1266 1267 1268 1269 1270 1271 1272 1273 1274 1275 1276 1277 1278 1279 1280 1281 1282 1283 1284 1285 1286 1287 1288 1289 1290 1291 1292 1293 1294 1295 1296 1297 1298 1299 1300 1301 1302 1303 1304 1305 1306 1307 1308 1309 1310 1311 1312 1313 1314 1315 1316 1317 1318 1319 1320 1321 1322 1323 1324 1325 1326 1327 1328 1329 1330 1331 1332 1333 1334 1335 1336 1337 1338 1339 1340 1341 1342 1343 1344 1345 1346 1347 1348 1349 1350 1351 1352 1353 1354 1355 1356 1357 1358 1359 1360 1361 1362 1363 1364 1365 1366 1367 1368 1369 1370 1371 1372 1373 1374 1375 1376 1377 1378 1379 1380 1381 1382 1383 1384 1385 1386 1387 1388 1389 1390 1391 1392 1393 1394 1395 1396 1397 1398 1399 1400 1401 1402 1403 1404 1405 1406 1407 1408 1409 1410 1411 1412 1413 1414 1415 1416 1417 1418 1419 1420 1421 1422 1423 1424 1425 1426 1427 1428 1429 1430 1431 1432 1433 1434 1435 1436 1437 1438 1439 1440 1441 1442 1443 1444 1445 1446 1447 1448 1449 1450 1451 1452 1453 1454 1455 1456 1457 1458 1459 1460 1461 1462 1463 1464 1465 1466 1467 1468 1469 1470 1471 1472 1473 1474 1475 1476 1477 1478 1479 1480 1481 1482 1483 1484 1485 1486 1487 1488 1489 1490 1491 1492 1493 1494 1495 1496 1497 1498 1499 1500 1501 1502 1503 1504 1505 1506 1507 1508 1509 1510 1511 1512 1513 1514 1515 1516 1517 1518 1519 1520 1521 1522 1523 1524 1525 1526 1527 1528 1529 1530 1531 1532 1533 1534 1535 1536 1537 1538 1539 1540 1541 1542 1543 1544 1545 1546 1547 1548 1549 1550 1551 1552 1553 1554 1555 1556 1557 1558 1559 1560 1561 1562 1563 1564 1565 1566 1567 1568 1569 1570 1571 1572 1573 1574 1575 1576 1577 1578 1579 1580 1581 1582 1583 1584 1585 1586 1587 1588 1589 1590 1591 1592 1593 1594 1595 1596 1597 1598 1599 1600 1601 1602 1603 1604 1605 1606 1607 1608 1609 1610 1611 1612 1613 1614 1615 1616 1617 1618 1619 1620 1621 1622 1623 1624 1625 1626 1627 1628 1629 1630 1631 1632 1633 1634 1635 1636 1637 1638 1639 1640 1641 1642 1643 1644 1645 1646 1647 1648 1649 1650 1651 1652 1653 1654 1655 1656 1657 1658 1659 1660 1661 1662 1663 1664 1665 1666 1667 1668 1669 1670 1671 1672 1673 1674 1675 1676 1677 1678 1679 1680 1681 1682 1683 1684 1685 1686 1687 1688 1689 1690 1691 1692 1693 1694 1695 1696 1697 1698 1699 1700 1701 1702 1703 1704 1705 1706 1707 1708 1709 1710 1711 1712 1713 1714 1715 1716 1717 1718 1719 1720 1721 1722 1723 1724 1725 1726 1727 1728 1729 1730 1731 1732 1733 1734 1735 1736 1737 1738 1739 1740 1741 1742 1743 1744 1745 1746 1747 1748 1749 1750 1751 1752 1753 1754 1755 1756 1757 1758 1759 1760 1761 1762 1763 1764 1765 1766 1767 1768 1769 1770 1771 1772 1773 1774 1775 1776 1777 1778 1779 1780 1781 1782 1783 1784 1785 1786 1787 1788 1789 1790 1791 1792 1793 1794 1795 1796 1797 1798 1799 1800 1801 1802 1803 1804 1805 1806 1807 1808 1809 1810 1811 1812 1813 1814 1815 1816 1817 1818 1819 1820 1821 1822 1823 1824 1825 1826 1827 1828 1829 1830 1831 1832 1833 1834 1835 1836 1837 1838 1839 1840 1841 1842 1843 1844 1845 1846 1847 1848 1849 1850 1851 1852 1853 1854 1855 1856 1857 1858 1859 1860 1861 1862 1863 1864 1865 1866 1867 1868 1869 1870 1871 1872 1873 1874 1875 1876 1877 1878 1879 1880 1881 1882 1883 1884 1885 1886 1887 1888 1889 1890 1891 1892 1893 1894 1895 1896 1897 1898 1899 1900 1901 1902 1903 1904 1905 1906 1907 1908 1909 1910 1911 1912 1913 1914 1915 1916 1917 1918 1919 1920 1921 1922 1923 1924 1925 1926 1927 1928 1929 1930 1931 1932 1933 1934 1935 1936 1937 1938 1939 1940 1941 1942 1943 1944 1945 1946 1947 1948 1949 1950 1951 1952 1953 1954 1955 1956 1957 1958 1959 1960 1961 1962 1963 1964 1965 1966 1967 1968 1969 1970 1971 1972 1973 1974 1975 1976 1977 1978 1979 1980 1981 1982 1983 1984 1985 1986 1987 1988 1989 1990 1991 1992 1993 1994 1995 1996 1997 1998 1999 2000 2001 2002 2003 2004 2005 2006 2007 2008 2009 2010 2011 2012 2013 2014 2015 2016 2017 2018 2019 2020 2021 2022 2023 2024 2025 2026 2027 2028 2029 2030 2031 2032 2033 2034 2035 2036 2037 2038 2039 2040 2041 2042 2043 2044 2045 2046 2047 2048 2049 2050 2051 2052 2053 2054 2055 2056 2057 2058 2059 2060 2061 2062 2063 2064 2065 2066 2067 2068 2069 2070 2071 2072 2073 2074 2075 2076 2077 2078 2079 2080 2081 2082 2083 2084 2085 2086 2087 2088 2089 2090 2091 2092 2093 2094 2095 2096 2097 2098 2099 2100 2101 2102 2103 2104 2105 2106 2107 2108 2109 2110 2111 2112 2113 2114 2115 2116 2117 2118 2119 2120 2121 2122 2123 2124 2125 2126 2127 2128 2129 2130 2131 2132 2133 2134 2135 2136 2137 2138 2139 2140 2141 2142 2143 2144 2145 2146 2147 2148 2149 2150 2151 2152 2153 2154 2155 2156 2157 2158 2159 2160 2161 2162 2163 2164 2165 2166 2167 2168 2169 2170 2171 2172 2173 2174 2175 2176 2177 2178 2179 2180 2181 2182 2183 2184 2185 2186 2187 2188 2189 2190 2191 2192 2193 2194 2195 2196 2197 2198 2199 2200 2201 2202 2203 2204 2205 2206 2207 2208 2209 2210 2211 2212 2213 2214 2215 2216 2217 2218 2219 2220 2221 2222 2223 2224 2225 2226 2227 2228 2229 2230 2231 2232 2233 2234 2235 2236 2237 2238 2239 2240 2241 2242 2243 2244 2245 2246 2247 2248 2249 2250 2251 2252 2253 2254 2255 2256 2257 2258 2259 2260 2261 2262 2263 2264 2265 2266 2267 2268 2269 2270 2271 2272 2273 2274 2275 2276 2277 2278 2279 2280 2281 2282 2283 2284 2285 2286 2287 2288 2289 2290 2291 2292 2293 2294 2295 2296 2297 2298 2299 2300 2301 2302 2303 2304 2305 2306 2307 2308 2309 2310 2311 2312 2313 2314 2315 2316 2317 2318 2319 2320 2321 2322 2323 2324 2325 2326 2327 2328 2329 2330 2331 2332 2333 2334 2335 2336 2337 2338 2339 2340 2341 2342 2343 2344 2345 2346 2347 2348 2349 2350 2351 2352 2353 2354 2355 2356 2357 2358 2359 2360 2361 2362 2363 2364 2365 2366 2367 2368 2369 2370 2371 2372 2373 2374 2375 2376 2377 2378 2379 2380 2381 2382 2383 2384 2385 2386 2387 2388 2389 2390 2391 2392 2393 2394 2395 2396 2397 2398 2399 2400 2401 2402 2403 2404 2405 2406 2407 2408 2409 2410 2411 2412 2413 2414 2415 2416 2417 2418 2419 2420 2421 2422 2423 2424 2425 2426 2427 2428 2429 2430 2431 2432 2433 2434 2435 2436 2437 2438 2439 2440 2441 2442 2443 2444 2445 2446 2447 2448 2449 2450 2451 2452 2453 2454 2455 2456 2457 2458 2459 2460 2461 2462 2463 2464 2465 2466 2467 2468 2469 2470 2471 2472 2473 2474 2475 2476 2477 2478 2479 2480 2481 2482 2483 2484 2485 2486 2487 2488 2489 2490 2491 2492 2493 2494 2495 2496 2497 2498 2499 2500 2501 2502 2503 2504 2505 2506 2507 2508 2509 2510 2511 2512 2513 2514 2515 2516 2517 2518 2519 2520 2521 2522 2523 2524 2525 2526 2527 2528 2529 2530 2531 2532 2533 2534 2535 2536 2537 2538 2539 2540 2541 2542 2543 2544 2545 2546 2547 2548 2549 2550 2551 2552 2553 2554 2555 2556 2557 2558 2559 2560 2561 2562 2563 2564 2565 2566 2567 2568 2569 2570 2571 2572 2573 2574 2575 2576 2577 2578 2579 2580 2581 2582 2583 2584 2585 2586 2587 2588 2589 2590 2591 2592 2593 2594 2595 2596 2597 2598 2599 2600 2601 2602 2603 2604 2605 2606 2607 2608 2609 2610 2611 2612 2613 2614 2615 2616 2617 2618 2619 2620 2621 2622 2623 2624 2625 2626 2627 2628 2629 2630 2631 2632 2633 2634 2635 2636 2637 2638 2639 2640 2641 2642 2643 2644 2645 2646 2647 2648 2649 2650 2651 2652 2653 2654 2655 2656 2657 2658 2659 2660 2661 2662 2663 2664 2665 2666 2667 2668 2669 2670 2671 2672 2673 2674 2675 2676 2677 2678 2679 2680 2681 2682 2683 2684 2685 2686 2687 2688 2689 2690 2691 2692 2693 2694 2695 2696 2697 2698 2699 2700 2701 2702 2703 2704 2705 2706 2707 2708 2709 2710 2711 2712 2713 2714 2715 2716 2717 2718 2719 2720 2721 2722 2723 2724 2725 2726 2727 2728 2729 2730 2731 2732 2733 2734 2735 2736 2737 2738 2739 2740 2741 2742 2743 2744 2745 2746 2747 2748 2749 2750 2751 2752 2753 2754 2755 2756 2757 2758 2759 2760 2761 2762 2763 2764 2765 2766 2767 2768 2769 2770 2771 2772 2773 2774 2775 2776 2777 2778 2779 2780 2781 2782 2783 2784 2785 2786 2787 2788 2789 2790 2791 2792 2793 2794 2795 2796 2797 2798 2799 2800 2801 2802 2803 2804 2805 2806 2807 2808 2809 2810 2811 2812 2813 2814 2815 2816 2817 2818 2819 2820 2821 2822 2823 2824 2825 2826 2827 2828 2829 2830 2831 2832 2833 2834 2835 2836 2837 2838 2839 2840 2841 2842 2843 2844 2845 2846 2847 2848 2849 2850 2851 2852 2853 2854 2855 2856 2857 2858 2859 2860 2861 2862 2863 2864 2865 2866 2867 2868 2869 2870 2871 2872 2873 2874 2875 2876 2877 2878 2879 2880 2881 2882 2883 2884 2885 2886 2887 2888 2889 2890 2891 2892 2893 2894 2895 2896 2897 2898 2899 2900 2901 2902 2903 2904 2905 2906 2907 2908 2909 2910 2911 2912 2913 2914 2915 2916 2917 2918 2919 2920 2921 2922 2923 2924 2925 2926 2927 2928 2929 2930 2931 2932 2933 2934 2935 2936 2937 2938 2939 2940 2941 2942 2943 2944 2945 2946 2947 2948 2949 2950 2951 2952 2953 2954 2955 2956 2957 2958 2959 2960 2961 2962 2963 2964 2965 2966 2967 2968 2969 2970 2971 2972 2973 2974 2975 2976 2977 2978 2979 2980 2981 2982 2983 2984 2985 2986 2987 2988 2989 2990 2991 2992 2993 2994 2995 2996 2997 2998 2999 3000 3001 3002 3003 3004 3005 3006 3007 3008 3009 3010 3011 3012 3013 3014 3015 3016 3017 3018 3019 3020 3021 3022 3023 3024 3025 3026 3027 3028 3029 3030 3031 3032 3033 3034 3035 3036 3037 3038 3039 3040 3041 3042 3043 3044 3045 3046 3047 3048 3049 3050 3051 3052 3053 3054 3055 3056 3057 3058 3059 3060 3061 3062 3063 3064 3065 3066 3067 3068 3069 3070 3071 3072 3073 3074 3075 3076 3077 3078 3079 3080 3081 3082 3083 3084 3085 3086 3087 3088 3089 3090 3091 3092 3093 3094 3095 3096 3097 3098 3099 3100 3101 3102 3103 3104 3105 3106 3107 3108 3109 3110 3111 3112 3113 3114 3115 3116 3117 3118 3119 3120 3121 3122 3123 3124 3125 3126 3127 3128 3129 3130 3131 3132 3133 3134 3135 3136 3137 3138 3139 3140 3141 3142 3143 3144 3145 3146 3147 3148 3149 3150 3151 3152 3153 3154 3155 3156 3157 3158 3159 3160 3161 3162 3163 3164 3165 3166 3167 3168 3169 3170 3171 3172 3173 3174 3175 3176 3177 3178 3179 3180 3181 3182 3183 3184 3185 3186 3187 3188 3189 3190 3191 3192 3193 3194 3195 3196 3197 3198 3199 3200 3201 3202 3203 3204 3205 3206 3207 3208 3209 3210 3211 3212 3213 3214 3215 3216 3217 3218 3219 3220 3221 3222 3223 3224 3225 3226 3227 3228 3229 3230 3231 3232 3233 3234 3235 3236 3237 3238 3239 3240 3241 3242 3243 3244 3245 3246 3247 3248 3249 3250 3251 3252 3253 3254 3255 3256 3257 3258 3259 3260 3261 3262 3263 3264 3265 3266 3267 3268 3269 3270 3271 3272 3273 3274 3275 3276 3277 3278 3279 3280 3281 3282 3283 3284 3285 3286 3287 3288 3289 3290 3291 3292 3293 3294 3295 3296 3297 3298 3299 3300 3301 3302 3303 3304 3305 3306 3307 3308 3309 3310 3311 3312 3313 3314 3315 3316 3317 3318 3319 3320 3321 3322 3323 3324 3325 3326 3327 3328 3329 3330 3331 3332 3333 3334 3335 3336 3337 3338 3339 3340 3341 3342 3343 3344 3345 3346 3347 3348 3349 3350 3351 3352 3353 3354 3355 3356 3357 3358 3359 3360 3361 3362 3363 3364 3365 3366 3367 3368 3369 3370 3371 3372 3373 3374 3375 3376 3377 3378 3379 3380 3381 3382 3383 3384 3385 3386 3387 3388 3389 3390 3391 3392 3393 3394 3395 3396 3397 3398 3399 3400 3401 3402 3403 3404 3405 3406 3407 3408 3409 3410 3411 3412 3413 3414 3415 3416 3417 3418 3419 3420 3421 3422 3423 3424 3425 3426 3427 3428 3429 3430 3431 3432 3433 3434 3435 3436 3437 3438 3439 3440 3441 3442 3443 3444 3445 3446 3447 3448 3449 3450 3451 3452 3453 3454 3455 3456 3457 3458 3459 3460 3461 3462 3463 3464 3465 3466 3467 3468 3469 3470 3471 3472 3473 3474 3475 3476 3477 3478 3479 3480 3481 3482 3483 3484 3485 3486 3487 3488 3489 3490 3491 3492 3493 3494 3495 3496 3497 3498 3499 3500 3501 3502 3503 3504 3505 3506 3507 3508 3509 3510 3511 3512 3513 3514 3515 3516 3517 3518 3519 3520 3521 3522 3523 3524 3525 3526 3527 3528 3529 3530 3531 3532 3533 3534 3535 3536 3537 3538 3539 3540 3541 3542 3543 3544 3545 3546 3547 3548 3549 3550 3551 3552 3553 3554 3555 3556 3557 3558 3559 3560 3561 3562 3563 3564 3565 3566 3567 3568 3569 3570 3571 3572 3573 3574 3575 3576 3577 3578 3579 3580 3581 3582 3583 3584 3585 3586 3587 3588 3589 3590 3591 3592 3593 3594 3595 3596 3597 3598 3599 3600 3601 3602 3603 3604 3605 3606 3607 3608 3609 3610 3611 3612 3613 3614 3615 3616 3617 3618 3619 3620 3621 3622 3623 3624 3625 3626 3627 3628 3629 3630 3631 3632 3633 3634 3635 3636 3637 3638 3639 3640 3641 3642 3643 3644 3645 3646 3647 3648 3649 3650 3651 3652 3653 3654 3655 3656 3657 3658 3659 3660 3661 3662 3663 3664 3665 3666 3667 3668 3669 3670 3671 3672 3673 3674 3675 3676 3677 3678 3679 3680 3681 3682 3683 3684 3685 3686 3687 3688 3689 3690 3691 3692 3693 3694 3695 3696 3697 3698 3699 3700 3701 3702 3703 3704 3705 3706 3707 3708 3709 3710 3711 3712 3713 3714 3715 3716 3717 3718 3719 3720 3721 3722 3723 3724 3725 3726 3727 3728 3729 3730 3731 3732 3733 3734 3735 3736 3737 3738 3739 3740 3741 3742 3743 3744 3745 3746 3747 3748 3749 3750 3751 3752 3753 3754 3755 3756 3757 3758 3759 3760 3761 3762 3763 3764 3765 3766 3767 3768 3769 3770 3771 3772 3773 3774 3775 3776 3777 3778 3779 3780 3781 3782 3783 3784 3785 3786 3787 3788 3789 3790 3791 3792 3793 3794 3795 3796 3797 3798 3799 3800 3801 3802 3803 3804 3805 3806 3807 3808 3809 3810 3811 3812 3813 3814 3815 3816 3817 3818 3819 3820 3821 3822 3823 3824 3825 3826 3827 3828 3829 3830 3831 3832 3833 3834 3835 3836 3837 3838 3839 3840 3841 3842 3843 3844 3845 3846 3847 3848 3849 3850 3851 3852 3853 3854 3855 3856 3857 3858 3859 3860 3861 3862 3863 3864 3865 3866 3867 3868 3869 3870 3871 3872 3873 3874 3875 3876 3877 3878 3879 3880 3881 3882 3883 3884 3885 3886 3887 3888 3889 3890 3891 3892 3893 3894 3895 3896 3897 3898 3899 3900 3901 3902 3903 3904 3905 3906 3907 3908 3909 3910 3911 3912 3913 3914 3915 3916 3917 3918 3919 3920 3921 3922 3923 3924 3925 3926 3927 3928 3929 3930 3931 3932 3933 3934 3935 3936 3937 3938 3939 3940 3941 3942 3943 3944 3945 3946 3947 3948 3949 3950 3951 3952 3953 3954 3955 3956 3957 3958 3959 3960 3961 3962 3963 3964 3965 3966 3967 3968 3969 3970 3971 3972 3973 3974 3975 3976 3977 3978 3979 3980 3981 3982 3983 3984 3985 3986 3987 3988 3989 3990 3991 3992 3993 3994 3995 3996 3997 3998 3999 4000]

// ============================================================================
// =====                         GLASS FILTER                              =====
// ============================================================================

// Enforce stained-glass style color filtering on everything seen through glass.
// This uses the per-pixel glass tint buffer (colortex4) written by the translucent pass.
#define GLASS_FILTER_ENABLED

// Overall strength multiplier (0 = off, 1 = default, >1 = stronger)
#define GLASS_FILTER_STRENGTH 1.35 // [0.00 0.10 0.25 0.50 0.75 1.00 1.25 1.35 1.50 1.75 2.00]

// 0 = mostly multiply (subtle), 1 = luminance-based enforcement (strong, like your screenshots)
#define GLASS_FILTER_ENFORCEMENT 0.80 // [0.00 0.10 0.20 0.30 0.40 0.50 0.60 0.70 0.80 0.90 1.00]

// Saturation boost for the glass tint color itself
#define GLASS_FILTER_SATURATION 1.80 // [0.50 0.75 1.00 1.25 1.50 1.80 2.00 2.50 3.00]

// ----------------------------------------------------------------------------
//   Water Surface (Above Water View)
// ----------------------------------------------------------------------------

// Water surface color (RGB)
#define WATER_COLOR_R 0.15 // [0.00 0.05 0.10 0.15 0.20 0.25 0.30 0.35 0.40]
#define WATER_COLOR_G 0.35 // [0.10 0.15 0.20 0.25 0.30 0.35 0.40 0.45 0.50]
#define WATER_COLOR_B 0.55 // [0.20 0.30 0.40 0.45 0.50 0.55 0.60 0.65 0.70 0.80]

// Water saturation - increases vibrancy of water color in all biomes
#define WATER_SATURATION 1.0 // [0.5 0.75 1.0 1.25 1.5 1.75 2.0 2.5 3.0]

// Water shadow opacity - controls shadow darkness on water (separate from terrain)
#define WATER_SHADOW_OPACITY 0.5 // [0.0 0.1 0.2 0.3 0.4 0.5 0.6 0.7 0.8 0.9 1.0]

// Water reflection fade brightness - controls the fresnel fade edge brightness
#define WATER_REFLECTION_FADE 1.0 // [0.3 0.5 0.7 1.0 1.3 1.5 2.0 2.5 3.0]

// Water specular (sun/moon reflection intensity)
#define WATER_SPECULAR_INTENSITY 1.50// [0.00 0.25 0.50 0.75 1.00 1.50 2.00 3.00 4.00 5.00]

// --- Water Foam/Edge Effect ---
// Adds a lighter foam-like effect where water meets blocks
#define WATER_FOAM_ENABLED
#define WATER_FOAM_INTENSITY 0.6 // [0.2 0.3 0.4 0.5 0.6 0.7 0.8 0.9 1.0]
#define WATER_FOAM_WIDTH 2.0 // [0.3 0.5 0.8 1.0 1.5 2.0 2.5 3.0] Depth in blocks
#define WATER_FOAM_COLOR_R 1.0 // [0.5 0.6 0.7 0.8 0.9 1.0]
#define WATER_FOAM_COLOR_G 1.0 // [0.5 0.6 0.7 0.8 0.9 1.0]
#define WATER_FOAM_COLOR_B 1.0 // [0.5 0.6 0.7 0.8 0.9 1.0]

// --- Water Waves ---
// Enable animated water waves
#define WATER_WAVES_ENABLED

// Wave height in blocks (how tall the waves are)
#define WATER_WAVE_HEIGHT 0.08 // [0.02 0.04 0.06 0.08 0.10 0.12 0.15 0.20 0.25 0.30 0.40 0.50]

// Wave speed (cycles per second)
#define WATER_WAVE_SPEED 1.0 // [0.25 0.50 0.75 1.00 1.25 1.50 2.00 2.50 3.00]

// Wave scale/frequency (smaller = larger waves)
#define WATER_WAVE_SCALE 0.20// [0.05 0.08 0.10 0.12 0.15 0.20 0.25 0.30 0.40 0.50]

// Secondary wave intensity (adds detail)
#define WATER_WAVE_DETAIL 0.25// [0.00 0.25 0.50 0.75 1.00]

// --- Minecraft Chunk Water ---
// Water opacity for nearby chunks (0 = transparent, 1 = solid)
#define MC_WATER_OPACITY 0.65// [0.30 0.40 0.50 0.60 0.65 0.70 0.75 0.80 0.85 0.90 0.95 1.00]

// --- Distant Horizons Water ---
// Water opacity for DH LODs (0 = transparent, 1 = solid)
#define DH_WATER_OPACITY 1.0 // [0.50 0.60 0.70 0.80 0.85 0.90 0.95 1.00]

// ----------------------------------------------------------------------------
//   Underwater Effects
// ----------------------------------------------------------------------------

// Enable underwater fog
#define UNDERWATER_FOG_ENABLED

// Underwater fog color (RGB)
#define UNDERWATER_FOG_R 0.05 // [0.00 0.02 0.05 0.08 0.10 0.12 0.15 0.18 0.20 0.25 0.30]
#define UNDERWATER_FOG_G 0.20 // [0.00 0.05 0.10 0.12 0.15 0.18 0.20 0.22 0.25 0.30 0.35 0.40]
#define UNDERWATER_FOG_B 0.40 // [0.00 0.05 0.10 0.15 0.20 0.25 0.30 0.35 0.40 0.45 0.50]

// Underwater fog density (higher = murkier water)
#define UNDERWATER_FOG_DENSITY 0.08// [0.005 0.01 0.015 0.02 0.025 0.03 0.04 0.05 0.06 0.08 0.10 0.15 0.20]

// Underwater fog opacity (0 = no fog, 1 = full fog)
#define UNDERWATER_FOG_OPACITY 0.90// [0.00 0.10 0.20 0.30 0.40 0.50 0.60 0.70 0.80 0.90 1.00]

// Distance where underwater visibility is fully faded into fog tint
#define UNDERWATER_VISIBILITY_DISTANCE 96.0 // [24.0 32.0 48.0 64.0 80.0 96.0 128.0 160.0 192.0 256.0]

// Visibility of the water surface while submerged (0 = hidden, 1 = normal)
#define UNDERWATER_SURFACE_VISIBILITY 0.03 // [0.00 0.01 0.02 0.03 0.05 0.08 0.10 0.15 0.20 0.25 0.30]

// Underwater brightness
#define UNDERWATER_BRIGHTNESS 0.9 // [0.20 0.30 0.40 0.50 0.60 0.70 0.80 0.90 1.00]

// ----------------------------------------------------------------------------
//   Underwater Light Shafts
// ----------------------------------------------------------------------------

// Enable underwater light shafts (shadow-based god rays from surface)
#define UNDERWATER_LIGHT_SHAFTS

// Light shaft intensity
#define UNDERWATER_SHAFT_INTENSITY 1.5 // [0.10 0.20 0.30 0.40 0.50 0.60 0.70 0.80 0.90 1.00 1.25 1.50 2.00]

// Light shaft samples (more = smoother but slower)
#define UNDERWATER_SHAFT_SAMPLES 48// [8 12 16 24 32 48]

// ----------------------------------------------------------------------------
//   Water Reflections (ILV-style)
// ----------------------------------------------------------------------------

// Enable water reflections (screen-space reflections)
#define WATER_REFLECTIONS_ENABLED

// Debug mode - makes water pink to verify detection
//#define WATER_REFLECTION_DEBUG

// ILV Reflection Settings
#define REFLECTION_ITERATIONS 40 // [20 30 40 50 60 80 100 150 200 300]
#define REFLECTION_DITHER_AMOUNT 1.0 // [0.0 0.25 0.5 0.75 1.0]
#define REFLECTION_FRESNEL 0.5 // [0.0 0.25 0.5 0.75 1.0]

// Water reflection strength (how reflective water is)
#define WATER_REFLECTION_AMOUNT 0.35 // [0.10 0.20 0.30 0.35 0.40 0.50 0.60 0.70 0.80 0.90 1.00]

// Legacy settings (kept for compatibility)
#define WATER_REFLECTION_STRENGTH 0.70// [0.10 0.20 0.30 0.40 0.50 0.60 0.70 0.80 0.90 1.00]
#define WATER_FRESNEL_STRENGTH 0.40// [0.00 0.20 0.40 0.60 0.80 1.00]
#define WATER_SKY_REFLECTION 1.0 // [0.00 0.20 0.40 0.60 0.70 0.80 0.90 1.00]
#define SSR_STEPS 64 // [8 12 16 24 32 48 64 96 128]
#define WATER_SSR_MAX_DISTANCE 512.0// [16.0 32.0 48.0 64.0 96.0 128.0 192.0 256.0 384.0 512.0]

// ----------------------------------------------------------------------------
//   Material Reflections (SSR on polished/smooth/glazed blocks)
// ----------------------------------------------------------------------------

// Enable material reflections (separate from water reflections)
#define MATERIAL_REFLECTIONS_ENABLED

// Reflection strength (how reflective the material is)
#define MATERIAL_REFLECTION_AMOUNT 0.25// [0.05 0.10 0.15 0.20 0.25 0.30 0.40 0.50 0.60 0.70 0.80]

// Fresnel strength (edge reflection boost)
#define MATERIAL_REFLECTION_FRESNEL 0.6// [0.0 0.2 0.4 0.6 0.8 1.0]

// ============================================================================
// =====                    ANIMATION                                     =====
// ============================================================================

// ----------------------------------------------------------------------------
//   Waving Foliage
// ----------------------------------------------------------------------------

// Enable when using a 3D grass resource pack. When OFF, grass_block behaves
// like a normal solid block: casts/receives shadows, has outlines, face shading.
#define GRASS_3D_RP_MODE

// Enable waving plants
#define WAVING_PLANTS

// Enable waving leaves
#define WAVING_LEAVES

// Waving style: 0 = Photon-style, 1 = Custom
#define WAVING_STYLE 1 // [0 1]

// Enable player plant interaction
#define PLAYER_PLANT_INTERACTION

// Enable swaying lanterns
#define SWAYING_LANTERNS

// --- General Waving ---
// Global waving speed
#define WAVING_SPEED 0.50// [0.10 0.20 0.30 0.40 0.50 0.60 0.70 0.80 0.90 1.00 1.10 1.20 1.30 1.40 1.50 1.75 2.00 2.50 3.00]

// Global waving intensity
#define WAVING_INTENSITY 1.30// [0.10 0.20 0.30 0.40 0.50 0.60 0.70 0.80 0.90 1.00 1.10 1.20 1.30 1.40 1.50 1.75 2.00 2.50 3.00]

// --- Grass Specific ---
// Grass waving speed multiplier
#define GRASS_WAVING_SPEED 1.0// [0.25 0.50 0.75 1.00 1.25 1.35 1.50 1.75 2.00 2.25 2.50 3.00]

// Grass waving intensity multiplier
#define GRASS_WAVING_INTENSITY 1.8// [0.25 0.50 0.75 1.00 1.25 1.50 1.75 2.00 2.25 2.50 3.00]

// --- Lantern Sway ---
// Lantern sway speed
#define LANTERN_SWAY_SPEED 1.5// [0.25 0.50 0.75 1.00 1.25 1.50 1.75 2.00 2.50 3.00]

// Lantern sway intensity
#define LANTERN_SWAY_INTENSITY 1.8// [0.25 0.50 0.75 1.00 1.25 1.50 1.75 2.00 2.50 3.00]

// --- Distance Boost ---
// Maximum distance boost multiplier
#define WAVING_DISTANCE_BOOST_MAX 4.0// [1.00 1.25 1.50 1.75 2.00 2.25 2.50 2.75 3.00 3.50 4.00]

// Distance boost start (blocks)
#define WAVING_DISTANCE_BOOST_START 24 // [0.0 8.0 16.0 24.0 32.0 48.0 64.0 80.0 96.0]

// Distance boost end (blocks)
#define WAVING_DISTANCE_BOOST_END 320// [64.0 80.0 96.0 112.0 128.0 160.0 192.0 224.0 256.0 320.0]

// --- Player Interaction ---
// General interaction intensity
#define PLAYER_INTERACTION_INTENSITY 1.5// [0.25 0.50 0.75 1.00 1.25 1.50 1.75 2.00 2.50 3.00]

// Grass interaction intensity
#define GRASS_INTERACTION_INTENSITY 2.2// [0.50 0.75 1.00 1.25 1.50 1.75 2.00 2.25 2.50 3.00]

// Grass interaction radius (blocks)
#define GRASS_INTERACTION_RADIUS 4.0// [1.00 1.50 2.00 2.50 2.75 3.00 3.50 4.00 5.00]

// ============================================================================
// =====                          SKY                                     =====
// ============================================================================

// ----------------------------------------------------------------------------
//   Sky Gradient
// ----------------------------------------------------------------------------

// Gradient curve (higher = sharper horizon transition)
#define SKY_GRADIENT_CURVE 3.00// [0.10 0.20 0.30 0.40 0.50 0.60 0.65 0.70 0.80 0.90 1.00 1.25 1.50 2.00 3.00 5.00 7.00 10.00 15.00 20.00]

// Global sky saturation
#define SKY_SATURATION 1.40// [0.00 0.10 0.20 0.30 0.40 0.50 0.60 0.70 0.80 0.90 1.00 1.10 1.20 1.30 1.40 1.50 1.75 2.00]

// Biome color blend (0 = custom colors only, 1 = full biome colors)
#define SKY_BIOME_BLEND 0.70// [0.00 0.10 0.20 0.30 0.40 0.50 0.60 0.70 0.80 0.90 1.00]

// NOTE: Biome sky tint in lighting is now folded into the unified skylight tint controls:
// - Strength: SKYLIGHT_COLOR_TINT
// - Saturation: SKYLIGHT_TINT_SATURATION (+ SKYLIGHT_TINT_LIGHT_SATURATION)

// ----------------------------------------------------------------------------
//   Sun & Moon
// ----------------------------------------------------------------------------

// Sun path rotation angle (degrees)
const float sunPathRotation = -20.0; // [-60.0 -55.0 -50.0 -45.0 -40.0 -35.0 -30.0 -25.0 -20.0 -15.0 -10.0 -5.0 0.0 5.0 10.0 15.0 20.0 25.0 30.0 35.0 40.0 45.0 50.0 55.0 60.0]

// Enable sun/moon size control
#define SUN_MOON_SIZE_ENABLED

// Sun/moon scale (1.0 = vanilla)
#define SUN_MOON_SCALE 1.00// [0.05 0.10 0.15 0.20 0.25 0.30 0.35 0.40 0.45 0.50 0.55 0.60 0.65 0.70 0.75 0.80 0.85 0.90 0.95 1.00]

// Sun/moon bloom intensity
#define SUN_MOON_BLOOM 1.0 // [0.0 0.25 0.5 0.75 1.0 1.5 2.0 3.0 4.0 5.0]

// ----------------------------------------------------------------------------
//   Stars
// ----------------------------------------------------------------------------

// Enable procedural stars
#define STARS_ENABLED

// Star grid scale (lower = bigger cells = larger stars, higher = more stars)
#define STAR_SCALE 50.0// [10.0 15.0 20.0 25.0 30.0 40.0 50.0]

// Star size (radius of each star)
#define STAR_SIZE 0.18// [0.04 0.06 0.08 0.10 0.12 0.15 0.18 0.20 0.25]

// Star brightness
#define STAR_BRIGHTNESS 1.5// [0.5 0.75 1.0 1.5 2.0 2.5 3.0 4.0 5.0]

// Star density (chance per cell, higher = more stars)
#define STAR_DENSITY 0.30// [0.05 0.08 0.10 0.12 0.15 0.20 0.25 0.30 0.40]

// Star twinkling intensity (0 = no twinkle, 1 = full twinkle)
#define STAR_TWINKLE 0.9// [0.0 0.2 0.4 0.5 0.6 0.7 0.8 0.9 1.0]

// --- Shooting Stars ---
// Enable shooting stars / meteors
#define STAR_SHOOTING_ENABLED

// Shooting star brightness
#define STAR_SHOOTING_BRIGHTNESS 4.0// [1.0 1.5 2.0 2.5 3.0 4.0 5.0]

// --- Night Sky Nebula ---
// Colored cloud patches visible at night (like the End sky texture feel)
#define NIGHT_NEBULA_ENABLED

// Overall intensity of the nebula glow
#define NIGHT_NEBULA_INTENSITY 0.40// [0.05 0.08 0.10 0.12 0.15 0.18 0.20 0.25 0.30 0.40 0.50 0.60 0.80 1.00]

// Scale of the nebula patches (lower = bigger, higher = more detailed)
#define NIGHT_NEBULA_SCALE 0.8// [0.3 0.4 0.5 0.6 0.8 1.0 1.2 1.5 2.0]

// Drift speed of the nebula clouds
#define NIGHT_NEBULA_SPEED 0.003// [0.001 0.002 0.003 0.005 0.008 0.010 0.015]

// Primary nebula color
#define NIGHT_NEBULA_R1 0.50// [0.0 0.1 0.2 0.3 0.4 0.5 0.6 0.7 0.8 0.9 1.0]
#define NIGHT_NEBULA_G1 0.10// [0.0 0.1 0.2 0.3 0.4 0.5 0.6 0.7 0.8 0.9 1.0]
#define NIGHT_NEBULA_B1 0.80// [0.0 0.1 0.2 0.3 0.4 0.5 0.6 0.7 0.8 0.9 1.0]

// Secondary nebula color
#define NIGHT_NEBULA_R2 0.10// [0.0 0.1 0.2 0.3 0.4 0.5 0.6 0.7 0.8 0.9 1.0]
#define NIGHT_NEBULA_G2 0.40// [0.0 0.1 0.2 0.3 0.4 0.5 0.6 0.7 0.8 0.9 1.0]
#define NIGHT_NEBULA_B2 0.90// [0.0 0.1 0.2 0.3 0.4 0.5 0.6 0.7 0.8 0.9 1.0]

// --- Night Asteroids ---
// Bright fast-moving rock streaks flying across the night sky
#define NIGHT_ASTEROIDS_ENABLED

// Number of concurrent asteroid slots (more = busier sky)
#define NIGHT_ASTEROID_COUNT 5// [2 3 4 5 6 8 10]

// Asteroid brightness
#define NIGHT_ASTEROID_BRIGHTNESS 4.0// [0.5 1.0 1.5 2.0 2.5 3.0 4.0 5.0]

// Asteroid trail length
#define NIGHT_ASTEROID_LENGTH 0.30// [0.04 0.06 0.08 0.10 0.12 0.15 0.20 0.25 0.30]

// Asteroid trail width
#define NIGHT_ASTEROID_THICKNESS 0.003// [0.002 0.003 0.004 0.005 0.006 0.008 0.010 0.015]

// Asteroid speed
#define NIGHT_ASTEROID_SPEED 0.30// [0.05 0.10 0.15 0.20 0.25 0.30 0.40 0.50 0.70]

// Average time between asteroid appearances (seconds)
#define NIGHT_ASTEROID_INTERVAL 30.0// [10.0 15.0 20.0 25.0 30.0 40.0 50.0 60.0 80.0]

// --- Ringed Planet ---
// Enable ringed planet in the sky (inspired by IterationT End sky)
// #define RINGED_PLANET_ENABLED  // Disabled - not working properly

// Planet brightness
#define PLANET_BRIGHTNESS 1.0 // [0.5 1.0 1.5 2.0 3.0 4.0 5.0 7.0 10.0 15.0 20.0]

// Planet size (apparent angular size in sky)
#define PLANET_SIZE 1.0 // [0.3 0.5 0.7 1.0 1.5 2.0 3.0 4.0 5.0]

// Planet position - azimuth angle (0-360 degrees, 0 = north)
#define PLANET_AZIMUTH 45.0 // [0.0 15.0 30.0 45.0 60.0 75.0 90.0 105.0 120.0 135.0 150.0 165.0 172.0 180.0 195.0 210.0 225.0 240.0 255.0 270.0 285.0 300.0 315.0 330.0 345.0]

// Planet position - elevation angle (degrees above horizon)
#define PLANET_ELEVATION 10.0// [5.0 10.0 15.0 20.0 25.0 30.0 35.0 40.0 45.0 50.0 60.0 70.0 80.0]

// Planet surface color
#define PLANET_COLOR_R 1.0 // [0.0 0.1 0.2 0.3 0.4 0.5 0.6 0.7 0.8 0.9 1.0]
#define PLANET_COLOR_G 0.87 // [0.0 0.1 0.2 0.3 0.4 0.5 0.6 0.7 0.8 0.9 1.0]
#define PLANET_COLOR_B 0.55 // [0.0 0.1 0.2 0.3 0.4 0.5 0.6 0.7 0.8 0.9 1.0]

// Ring color tint
#define RING_COLOR_R 1.0 // [0.0 0.1 0.2 0.3 0.4 0.5 0.6 0.7 0.8 0.9 1.0]
#define RING_COLOR_G 0.85 // [0.0 0.1 0.2 0.3 0.4 0.5 0.6 0.7 0.8 0.9 1.0]
#define RING_COLOR_B 0.60 // [0.0 0.1 0.2 0.3 0.4 0.5 0.6 0.7 0.8 0.9 1.0]

// Ring tilt angle (0 = edge-on, higher = more visible)
#define RING_TILT 8.0 // [0.0 2.0 4.0 6.0 8.0 10.0 15.0 20.0 25.0 30.0 35.0 40.0 45.0]


// ----------------------------------------------------------------------------
//   2D Clouds
// ----------------------------------------------------------------------------

// Enable stylized 2D clouds
//#define CLOUDS_2D_ENABLED

// Enable cloud shadows on terrain
#define CLOUD_SHADOWS_ENABLED

// Cloud layer height (blocks above sea level)
#define CLOUD_HEIGHT 4000.0// [80.0 100.0 120.0 150.0 180.0 200.0 250.0 300.0 400.0 500.0 1000.0 2000.0 4000.0]

// Cloud coverage (0 = clear, 1 = overcast)
#define CLOUD_COVERAGE 0.6// [0.1 0.2 0.3 0.4 0.5 0.6 0.7 0.8 0.9 1.0]

// Cloud scale (smaller = bigger clouds)
#define CLOUD_SCALE 0.0007// [0.0001 0.0002 0.0003 0.0004 0.0005 0.0007 0.001 0.0015 0.002]

// Cloud movement speed
#define CLOUD_SPEED 15.0// [0.0 2.0 5.0 10.0 15.0 20.0 30.0 50.0]

// Cloud shadow strength (0 = no shadows)
#define CLOUD_SHADOW_STRENGTH 0.0// [0.0 0.1 0.2 0.3 0.4 0.5 0.6 0.7 0.8 0.9 1.0]

// Cloud edge style (0 = soft/realistic, 1 = hard/toon)
#define CLOUD_TOON_EDGES 1// [0 1]

// Cloud brightness multiplier
#define CLOUD_BRIGHTNESS 3.0// [0.5 0.7 0.8 0.9 1.0 1.1 1.2 1.3 1.5 2.0 2.5 3.0]

// Cloud thickness (affects 3D look from parallax)
#define CLOUD_THICKNESS 200.0// [10.0 20.0 30.0 50.0 75.0 100.0 150.0 200.0]

// Cloud shadow color setup (customizable)
#define CLOUD_SHADOW_R 0.9 // [0.5 0.6 0.7 0.8 0.9 1.0]
#define CLOUD_SHADOW_G 0.9 // [0.5 0.6 0.7 0.8 0.9 1.0]
#define CLOUD_SHADOW_B 0.95 // [0.5 0.6 0.7 0.8 0.9 1.0]

// ----------------------------------------------------------------------------
//   Vanilla-Style Clouds
// ----------------------------------------------------------------------------

// Enable vanilla-style blocky clouds (grid-snapped, pixelated, 3D extruded)
//#define CLOUDS_VANILLA_ENABLED

// Height of vanilla cloud layer (blocks above sea level)
#define VANILLA_CLOUD_HEIGHT 192.0 // [80.0 100.0 128.0 150.0 192.0 200.0 250.0 300.0 400.0 500.0]

// Cloud thickness (vertical size in blocks — vanilla is 4)
#define VANILLA_CLOUD_THICKNESS 16.0 // [2.0 4.0 6.0 8.0 12.0 16.0 24.0 32.0]

// Grid cell size (blocks per cloud pixel)
#define VANILLA_CLOUD_CELL_SIZE 12.0 // [6.0 8.0 12.0 16.0 24.0]

// Cloud coverage (0 = clear, 1 = overcast)
#define VANILLA_CLOUD_COVERAGE 0.20 // [0.10 0.15 0.20 0.25 0.30 0.35 0.40 0.45 0.50 0.55 0.60 0.70 0.80]

// Cloud movement speed
#define VANILLA_CLOUD_SPEED 12.0 // [0.0 2.0 4.0 6.0 8.0 12.0 16.0 24.0 32.0]

// Cloud brightness
#define VANILLA_CLOUD_BRIGHTNESS 1.2 // [0.5 0.7 0.8 0.9 1.0 1.1 1.2 1.4 1.6 1.8 2.0]

// Cloud render distance (blocks)
#define VANILLA_CLOUD_DISTANCE 8000 // [2000 3000 4000 5000 6000 8000 10000 16000 30000]
// Global cloud opacity reduction at night (% at full night)
#define VANILLA_CLOUD_NIGHT_OPACITY_REDUCTION 40 // [0 5 10 15 20 25 30 35 40 45 50 55 60 65 70 75 80 85 90 95 100]
// Extra darkness on cloud side-face shading (%)
#define VANILLA_CLOUD_SIDE_DARKNESS 20 // [0 5 10 15 20 25 30 35 40 45 50 55 60 65 70 75 80 85 90 95 100]
// Extra darkness on cloud underside surface shading (%)
#define VANILLA_CLOUD_BOTTOM_DARKNESS 20 // [0 5 10 15 20 25 30 35 40 45 50 55 60 65 70 75 80 85 90 95 100]

// Cloud color
#define VANILLA_CLOUD_R 1.00 // [0.00 0.05 0.10 0.15 0.20 0.25 0.30 0.35 0.40 0.45 0.50 0.55 0.60 0.65 0.70 0.75 0.80 0.85 0.90 0.95 1.00]
#define VANILLA_CLOUD_G 1.00 // [0.00 0.05 0.10 0.15 0.20 0.25 0.30 0.35 0.40 0.45 0.50 0.55 0.60 0.65 0.70 0.75 0.80 0.85 0.90 0.95 1.00]
#define VANILLA_CLOUD_B 1.00 // [0.00 0.05 0.10 0.15 0.20 0.25 0.30 0.35 0.40 0.45 0.50 0.55 0.60 0.65 0.70 0.75 0.80 0.85 0.90 0.95 1.00]

// Raymarch quality (samples per ray — higher = sharper but slower)
#define VANILLA_CLOUD_STEPS 256 // [16 24 32 48 64 96 128 192 256 384 512]

// Layer spacing — vertical distance between cloud layers (blocks)
#define VANILLA_CLOUD_LAYER_SPACING 8.0 // [2.0 4.0 6.0 8.0 12.0 16.0 24.0 32.0 48.0 64.0 96.0 128.0 192.0 256.0]

// Layer 1 (bottom) — coverage, cell size, and opacity
#define VANILLA_CLOUD_L1_COVERAGE 0.40 // [0.10 0.15 0.20 0.25 0.30 0.35 0.40 0.45 0.50 0.55 0.60 0.70 0.80]
#define VANILLA_CLOUD_L1_PIXEL_SIZE 12.0 // [4.0 6.0 8.0 10.0 12.0 16.0 20.0 24.0 32.0]
#define VANILLA_CLOUD_L1_OPACITY 100 // [0 5 10 15 20 25 30 35 40 45 50 55 60 65 70 75 80 85 90 95 100]

// Layer 2 (middle/main) — coverage, cell size, and opacity
#define VANILLA_CLOUD_L2_COVERAGE 0.10 // [0.10 0.15 0.20 0.25 0.30 0.35 0.40 0.45 0.50 0.55 0.60 0.70 0.80]
#define VANILLA_CLOUD_L2_PIXEL_SIZE 16.0 // [4.0 6.0 8.0 10.0 12.0 16.0 20.0 24.0 32.0]
#define VANILLA_CLOUD_L2_OPACITY 100 // [0 5 10 15 20 25 30 35 40 45 50 55 60 65 70 75 80 85 90 95 100]

// Layer 3 (top) — coverage, cell size, and opacity
#define VANILLA_CLOUD_L3_COVERAGE 0.10 // [0.10 0.15 0.20 0.25 0.30 0.35 0.40 0.45 0.50 0.55 0.60 0.65 0.70 0.80]
#define VANILLA_CLOUD_L3_PIXEL_SIZE 10.0 // [4.0 6.0 8.0 10.0 12.0 16.0 20.0 24.0 32.0]
#define VANILLA_CLOUD_L3_OPACITY 100 // [0 5 10 15 20 25 30 35 40 45 50 55 60 65 70 75 80 85 90 95 100]

// Corner rounding radius — fraction of cell size [0 = sharp, 0.3 = very round]
#define VANILLA_CLOUD_CORNER_RADIUS 0.18 // [0.0 0.05 0.10 0.15 0.18 0.20 0.25 0.30]

// ----------------------------------------------------------------------------
//   3D Volumetric Clouds
// ----------------------------------------------------------------------------

// Enable 3D volumetric raymarched clouds
#define CLOUDS_3D_ENABLED

// Raymarch quality (steps). Higher = better but slower
#define CLOUD_3D_STEPS 64 // [8 12 16 20 24 32 48 64 96 128]

// Cloud coverage (0 = clear, 1 = overcast)
#define CLOUD_3D_COVERAGE 0.45 // [0.10 0.15 0.20 0.25 0.30 0.35 0.40 0.45 0.50 0.55 0.60 0.65 0.70 0.75 0.80 0.85 0.90]

// Cloud density (optical thickness)
#define CLOUD_3D_DENSITY 1.5 // [0.25 0.50 0.75 1.00 1.25 1.50 2.00 3.00 4.00]

// Cloud layer height (blocks above sea level)
#define CLOUD_3D_HEIGHT 300.0 // [100.0 150.0 200.0 250.0 300.0 400.0 500.0 600.0 800.0 1000.0 2000.0]

// Cloud layer thickness (vertical size in blocks)
#define CLOUD_3D_THICKNESS 150.0 // [40.0 60.0 80.0 100.0 120.0 150.0 200.0 300.0]

// Cloud pattern scale (lower = bigger clouds)
#define CLOUD_3D_SCALE 1.0 // [0.3 0.5 0.7 0.8 1.0 1.2 1.5 2.0 3.0]

// Grid cell size in blocks (controls cloud "pixel" size — vanilla-style blockiness)
#define CLOUD_3D_CELL_SIZE 25.0 // [8.0 12.0 16.0 20.0 25.0 30.0 40.0 50.0 60.0 80.0 100.0 120.0]

// Detail erosion strength (puffy cauliflower bumps)
#define CLOUD_3D_DETAIL 1.0 // [0.0 0.25 0.50 0.75 1.00 1.25 1.50 1.75 2.00 2.25 2.50 2.75 3.00 3.25 3.50 3.75 4.00 4.25 4.50 4.75 5.00 5.25 5.50 5.75 6.00]

// Cloud movement speed
#define CLOUD_3D_SPEED 16.0 // [0.0 2.0 4.0 6.0 8.0 12.0 16.0 24.0 32.0]

// Cloud brightness
#define CLOUD_3D_BRIGHTNESS 1.4 // [0.3 0.5 0.7 0.8 0.9 1.0 1.1 1.2 1.3 1.4 1.6 1.8 2.0 2.5 3.0]

// Render distance for 3D clouds (blocks from player). Clouds fade out near the edge.
#define CLOUD_3D_DISTANCE 8000 // [1000 2000 3000 4000 5000 6000 8000 10000 12000 16000 20000 30000]

// Edge glow intensity (silver lining on thin edges)
#define CLOUD_3D_EDGE_GLOW 0.0 // [0.0 0.1 0.2 0.3 0.4 0.5 0.6 0.8 1.0]

// Cloud color (white by default — stylized cartoon clouds)
#define CLOUD_3D_R 1.00 // [0.00 0.05 0.10 0.15 0.20 0.25 0.30 0.35 0.40 0.45 0.50 0.55 0.60 0.65 0.70 0.75 0.80 0.85 0.90 0.95 1.00]
#define CLOUD_3D_G 1.00 // [0.00 0.05 0.10 0.15 0.20 0.25 0.30 0.35 0.40 0.45 0.50 0.55 0.60 0.65 0.70 0.75 0.80 0.85 0.90 0.95 1.00]
#define CLOUD_3D_B 1.00 // [0.00 0.05 0.10 0.15 0.20 0.25 0.30 0.35 0.40 0.45 0.50 0.55 0.60 0.65 0.70 0.75 0.80 0.85 0.90 0.95 1.00]

// ----------------------------------------------------------------------------
//   Sky Colors - Day
// ----------------------------------------------------------------------------

#define DAY_BRIGHTNESS 0.95// [0.25 0.30 0.35 0.40 0.45 0.50 0.55 0.60 0.65 0.70 0.75 0.80 0.85 0.90 0.95 1.00 1.05 1.10 1.15 1.20 1.25 1.50 1.75 2.00]

// Day horizon color (light blue)
#define DAY_HORIZON_R 0.85// [0.00 0.05 0.10 0.15 0.20 0.25 0.30 0.35 0.40 0.45 0.50 0.55 0.60 0.65 0.70 0.75 0.80 0.85 0.90 0.95 1.00]
#define DAY_HORIZON_G 0.98// [0.00 0.05 0.10 0.15 0.20 0.25 0.30 0.35 0.40 0.45 0.50 0.55 0.60 0.65 0.70 0.75 0.80 0.85 0.90 0.95 1.00]
#define DAY_HORIZON_B 1.00// [0.00 0.05 0.10 0.15 0.20 0.25 0.30 0.35 0.40 0.45 0.50 0.55 0.60 0.65 0.70 0.75 0.80 0.85 0.90 0.95 1.00]

// Day mid color (medium blue)
#define DAY_MID_R 0.70// [0.00 0.05 0.10 0.15 0.20 0.25 0.30 0.35 0.40 0.45 0.50 0.55 0.60 0.65 0.70 0.75 0.80 0.85 0.90 0.95 1.00]
#define DAY_MID_G 0.87// [0.00 0.05 0.10 0.15 0.20 0.25 0.30 0.35 0.40 0.45 0.50 0.55 0.60 0.65 0.70 0.75 0.80 0.85 0.90 0.95 1.00]
#define DAY_MID_B 1.00// [0.00 0.05 0.10 0.15 0.20 0.25 0.30 0.35 0.40 0.45 0.50 0.55 0.60 0.65 0.70 0.75 0.80 0.85 0.90 0.95 1.00]

// Day zenith color (deep blue)
#define DAY_ZENITH_R 0.60// [0.00 0.05 0.10 0.15 0.20 0.25 0.30 0.35 0.40 0.45 0.50 0.55 0.60 0.65 0.70 0.75 0.80 0.85 0.90 0.95 1.00]
#define DAY_ZENITH_G 0.69// [0.00 0.05 0.10 0.15 0.20 0.25 0.30 0.35 0.40 0.45 0.50 0.55 0.60 0.65 0.70 0.75 0.80 0.85 0.90 0.95 1.00]
#define DAY_ZENITH_B 0.98// [0.00 0.05 0.10 0.15 0.20 0.25 0.30 0.35 0.40 0.45 0.50 0.55 0.60 0.65 0.70 0.75 0.80 0.85 0.90 0.95 1.00]

// Layer blend heights
#define DAY_MID_HEIGHT 0.40// [0.05 0.10 0.15 0.20 0.25 0.30 0.35 0.40 0.45 0.50 0.55 0.60]
#define DAY_ZENITH_HEIGHT 0.80// [0.40 0.45 0.50 0.55 0.60 0.65 0.70 0.75 0.80 0.85 0.90 0.95]

// ----------------------------------------------------------------------------
//   Sky Colors - Sunset
// ----------------------------------------------------------------------------

#define SUNSET_BRIGHTNESS 1.15// [0.25 0.30 0.35 0.40 0.45 0.50 0.55 0.60 0.65 0.70 0.75 0.80 0.85 0.90 0.95 1.00 1.05 1.10 1.15 1.20 1.25 1.50 1.75 2.00]

// Sunset horizon color (orange)
#define SUNSET_HORIZON_R 1.00 // [0.00 0.05 0.10 0.15 0.20 0.25 0.30 0.35 0.40 0.45 0.50 0.55 0.60 0.65 0.70 0.75 0.80 0.85 0.90 0.95 1.00]
#define SUNSET_HORIZON_G 0.85 // [0.00 0.05 0.10 0.15 0.20 0.25 0.30 0.35 0.40 0.45 0.50 0.55 0.60 0.65 0.70 0.75 0.80 0.85 0.90 0.95 1.00]
#define SUNSET_HORIZON_B 0.24 // [0.00 0.05 0.10 0.15 0.20 0.25 0.30 0.35 0.40 0.45 0.50 0.55 0.60 0.65 0.70 0.75 0.80 0.85 0.90 0.95 1.00]

// Sunset mid color (orange x yellow)
#define SUNSET_MID_R 1.00// [0.00 0.05 0.10 0.15 0.20 0.25 0.30 0.35 0.40 0.45 0.50 0.55 0.60 0.65 0.70 0.75 0.80 0.85 0.90 0.95 1.00]
#define SUNSET_MID_G 0.72// [0.00 0.05 0.10 0.15 0.20 0.25 0.30 0.35 0.40 0.45 0.50 0.55 0.60 0.65 0.70 0.75 0.80 0.85 0.90 0.95 1.00]
#define SUNSET_MID_B 0.20// [0.00 0.05 0.10 0.15 0.20 0.25 0.30 0.35 0.40 0.45 0.50 0.55 0.60 0.65 0.70 0.75 0.80 0.85 0.90 0.95 1.00]

// Sunset zenith color (orange)
#define SUNSET_ZENITH_R 1.00// [0.00 0.05 0.10 0.15 0.20 0.25 0.30 0.35 0.40 0.45 0.50 0.55 0.60 0.65 0.70 0.75 0.80 0.85 0.90 0.95 1.00]
#define SUNSET_ZENITH_G 0.58// [0.00 0.05 0.10 0.15 0.20 0.25 0.30 0.35 0.40 0.45 0.50 0.55 0.60 0.65 0.70 0.75 0.80 0.85 0.90 0.95 1.00]
#define SUNSET_ZENITH_B 0.17// [0.00 0.05 0.10 0.15 0.20 0.25 0.30 0.35 0.40 0.45 0.50 0.55 0.60 0.65 0.70 0.75 0.80 0.85 0.90 0.95 1.00]

// Layer blend heights
#define SUNSET_MID_HEIGHT 0.32// [0.05 0.10 0.15 0.20 0.25 0.30 0.35 0.40 0.45 0.50 0.55 0.60]
#define SUNSET_ZENITH_HEIGHT 0.67// [0.40 0.45 0.50 0.55 0.60 0.65 0.70 0.75 0.80 0.85 0.90 0.95]

// ----------------------------------------------------------------------------
//   Sky Colors - Blue Hour
// ----------------------------------------------------------------------------

#define BLUEHOUR_BRIGHTNESS 1.05// [0.25 0.30 0.35 0.40 0.45 0.50 0.55 0.60 0.65 0.70 0.75 0.80 0.85 0.90 0.95 1.00 1.05 1.10 1.15 1.20 1.25 1.50 1.75 2.00]

// Blue hour horizon color (pink/salmon)
#define BLUEHOUR_HORIZON_R 0.70 // [0.00 0.05 0.10 0.15 0.20 0.25 0.30 0.35 0.40 0.45 0.50 0.55 0.60 0.65 0.70 0.75 0.80 0.85 0.90 0.95 1.00]
#define BLUEHOUR_HORIZON_G 0.45 // [0.00 0.05 0.10 0.15 0.20 0.25 0.30 0.35 0.40 0.45 0.50 0.55 0.60 0.65 0.70 0.75 0.80 0.85 0.90 0.95 1.00]
#define BLUEHOUR_HORIZON_B 0.50 // [0.00 0.05 0.10 0.15 0.20 0.25 0.30 0.35 0.40 0.45 0.50 0.55 0.60 0.65 0.70 0.75 0.80 0.85 0.90 0.95 1.00]

// Blue hour mid color (lavender)
#define BLUEHOUR_MID_R 0.45 // [0.00 0.05 0.10 0.15 0.20 0.25 0.30 0.35 0.40 0.45 0.50 0.55 0.60 0.65 0.70 0.75 0.80 0.85 0.90 0.95 1.00]
#define BLUEHOUR_MID_G 0.38 // [0.00 0.05 0.10 0.15 0.20 0.25 0.30 0.35 0.40 0.45 0.50 0.55 0.60 0.65 0.70 0.75 0.80 0.85 0.90 0.95 1.00]
#define BLUEHOUR_MID_B 0.55 // [0.00 0.05 0.10 0.15 0.20 0.25 0.30 0.35 0.40 0.45 0.50 0.55 0.60 0.65 0.70 0.75 0.80 0.85 0.90 0.95 1.00]

// Blue hour zenith color (deep blue)
#define BLUEHOUR_ZENITH_R 0.22 // [0.00 0.05 0.10 0.15 0.20 0.25 0.30 0.35 0.40 0.45 0.50 0.55 0.60 0.65 0.70 0.75 0.80 0.85 0.90 0.95 1.00]
#define BLUEHOUR_ZENITH_G 0.25 // [0.00 0.05 0.10 0.15 0.20 0.25 0.30 0.35 0.40 0.45 0.50 0.55 0.60 0.65 0.70 0.75 0.80 0.85 0.90 0.95 1.00]
#define BLUEHOUR_ZENITH_B 0.48 // [0.00 0.05 0.10 0.15 0.20 0.25 0.30 0.35 0.40 0.45 0.50 0.55 0.60 0.65 0.70 0.75 0.80 0.85 0.90 0.95 1.00]

// Layer blend heights
#define BLUEHOUR_MID_HEIGHT 0.30 // [0.05 0.10 0.15 0.20 0.25 0.30 0.35 0.40 0.45 0.50 0.55 0.60]
#define BLUEHOUR_ZENITH_HEIGHT 0.65 // [0.40 0.45 0.50 0.55 0.60 0.65 0.70 0.75 0.80 0.85 0.90 0.95]

// ----------------------------------------------------------------------------
//   Sky Colors - Night
// ----------------------------------------------------------------------------

#define NIGHT_BRIGHTNESS 0.75// [0.25 0.30 0.35 0.40 0.45 0.50 0.55 0.60 0.65 0.70 0.75 0.80 0.85 0.90 0.95 1.00 1.25 1.50 1.75 2.00 2.50 3.00 4.00 5.00 6.00 7.00 8.00 10.00 15.00 20.00]
#define NIGHT_BIOME_STRENGTH 1.00// [0.00 0.02 0.04 0.06 0.08 0.10 0.15 0.20 0.25 0.30 0.40 0.50 0.60 0.70 0.80 0.90 1.00]

// Night horizon color (dark gray-blue)
#define NIGHT_HORIZON_R 0.39// [0.00 0.02 0.04 0.06 0.08 0.10 0.12 0.15 0.20 0.25 0.30 0.35 0.40 0.50]
#define NIGHT_HORIZON_G 0.00// [0.00 0.02 0.04 0.06 0.08 0.10 0.12 0.15 0.20 0.25 0.30 0.35 0.40 0.50]
#define NIGHT_HORIZON_B 0.62// [0.00 0.02 0.04 0.06 0.08 0.10 0.12 0.15 0.20 0.25 0.30 0.35 0.40 0.50]

// Night mid color (darker blue)
#define NIGHT_MID_R 0.18// [0.00 0.02 0.04 0.06 0.08 0.10 0.12 0.15 0.20 0.25 0.30 0.35 0.40 0.50]
#define NIGHT_MID_G 0.10// [0.00 0.02 0.04 0.06 0.08 0.10 0.12 0.15 0.20 0.25 0.30 0.35 0.40 0.50]
#define NIGHT_MID_B 0.39// [0.00 0.02 0.04 0.06 0.08 0.10 0.12 0.15 0.20 0.25 0.30 0.35 0.40 0.50]

// Night zenith color (deep blue)
#define NIGHT_ZENITH_R 0.14// [0.00 0.02 0.04 0.06 0.08 0.10 0.12 0.15 0.20 0.25 0.30 0.35 0.40 0.50]
#define NIGHT_ZENITH_G 0.13// [0.00 0.02 0.04 0.06 0.08 0.10 0.12 0.15 0.20 0.25 0.30 0.35 0.40 0.50]
#define NIGHT_ZENITH_B 0.27// [0.00 0.02 0.04 0.06 0.08 0.10 0.12 0.15 0.20 0.25 0.30 0.35 0.40 0.50]

// Layer blend heights
#define NIGHT_MID_HEIGHT 0.47// [0.05 0.10 0.15 0.20 0.25 0.30 0.35 0.40 0.45 0.50 0.55 0.60]
#define NIGHT_ZENITH_HEIGHT 0.68// [0.40 0.45 0.50 0.55 0.60 0.65 0.70 0.75 0.80 0.85 0.90 0.95]

// ============================================================================
// =====                    COMPATIBILITY                                 =====
// ============================================================================

// ----------------------------------------------------------------------------
//   Distant Horizons
// ----------------------------------------------------------------------------

// DH terrain brightness multiplier
#define DH_BRIGHTNESS 1.00 // [0.50 0.55 0.60 0.65 0.70 0.75 0.80 0.85 0.90 0.95 1.00 1.05 1.10 1.15 1.20 1.25 1.30 1.40 1.50 1.75 2.00 2.50 3.00 4.00 5.00 6.00 7.00 8.00 9.00 10.00]

// DH terrain contrast multiplier (1.0 = unchanged, higher = punchier darks/lights)
#define DH_CONTRAST 1.00 // [0.50 0.60 0.70 0.80 0.90 0.95 1.00 1.05 1.10 1.15 1.20 1.30 1.40 1.50 1.75 2.00]

// DH color saturation (0.0 = grayscale, 1.0 = unchanged, higher = oversaturated)
#define DH_SATURATION 1.00 // [0.00 0.10 0.20 0.30 0.40 0.50 0.60 0.70 0.80 0.90 1.00 1.10 1.20 1.30 1.40 1.50 1.75 2.00]

// DH emissive/bloom intensity (0 = disabled, 1 = same as regular blocks)
#define DH_EMISSIVE_INTENSITY 0.70// [0.00 0.10 0.20 0.30 0.40 0.50 0.60 0.70 0.80 0.90 1.00 1.25 1.50 2.00]

// DH emissive color strength - how much original color vs white (0 = full white, 1 = full original color)
#define DH_EMISSIVE_COLOR_STRENGTH 1.0// [0.0 0.1 0.2 0.3 0.4 0.5 0.6 0.7 0.8 0.9 1.0]

// DH emissive brightness cap - limits maximum brightness of emissive LODs (lower = less white blowout)
#define DH_EMISSIVE_BRIGHTNESS_CAP 1.0// [0.3 0.4 0.5 0.6 0.7 0.8 0.9 1.0 1.2 1.5 2.0]

// DH emissive detection brightness threshold (lower = more blocks glow, may cause false positives)
#define DH_EMISSIVE_THRESHOLD 0.55// [0.50 0.55 0.60 0.65 0.70 0.75 0.80 0.85 0.90 0.95]

// Debug: show detected emissive blocks in magenta
//#define DH_EMISSIVE_DEBUG

// Procedural Mob Glow Strength (Piglins, Strays, etc.)
#define PROCEDURAL_GLOW_STRENGTH 1.0// [0.0 0.25 0.5 0.75 1.0 1.25 1.5 2.0 3.0]

// Overdraw blend start distance
#define DH_OVERDRAW_DISTANCE 64.0// [0.0 4.0 8.0 12.0 16.0 20.0 24.0 28.0 32.0 40.0 48.0 64.0]

// Overdraw blend fade length
#define DH_OVERDRAW_FADE_LENGTH 64.0// [0.0 4.0 8.0 12.0 16.0 20.0 24.0 28.0 32.0 40.0 48.0 64.0]


// ============================================================================
// FAKE HORIZON WATER (fills beyond DH LODs with ocean)
// ============================================================================

// Enable fake water plane where DH LODs don't exist
#define FAKE_TERRAIN_ENABLED

// Y level of the water plane (world coordinates)
#define FAKE_TERRAIN_Y 63 // [-64 0 15 32 48 63 64 80 96 100 128]

// Distance where fake water starts fading in (blocks from camera)
// Lower values fill gaps closer to the player (set near your DH render distance)
#define FAKE_TERRAIN_START 50.0// [0.0 50.0 100.0 200.0 300.0 500.0 750.0 1000.0 1500.0 2000.0]

// Maximum render distance for fake water
#define FAKE_TERRAIN_DISTANCE 50000.0// [5000.0 10000.0 15000.0 20000.0 30000.0 50000.0]

#endif



