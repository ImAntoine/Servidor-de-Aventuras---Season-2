#ifndef REFLECTIONS_GLSL
#define REFLECTIONS_GLSL

#include "/include/sky_fallback.glsl"

// Bayer dithering for SSR temporal stability
float bayer2(vec2 a) { a = 0.5 * floor(a); return fract(1.5 * fract(a.y) + a.x); }
float bayer4(vec2 a) { return 0.25 * bayer2(0.5 * a) + bayer2(a); }
float bayer8(vec2 a) { return 0.25 * bayer4(0.5 * a) + bayer2(a); }
float bayer64(vec2 a) { return 0.25 * bayer8(0.5 * a) + bayer2(a); }

float getDepth(vec2 uv) {
    return texture(depthtex0, uv).r;
}

float SSR_linearizeDepth(float depth) {
    return (2.0 * near) / (far + near - depth * (far - near));
}

// Screen-space raytracing for reflections
bool raytraceSSR(vec3 viewPos, vec3 reflectDir, out vec2 hitPos, out float hitConfidence) {
    hitConfidence = 0.0;
    
    // Project start position to screen space
    vec4 rayStartClip = gbufferProjection * vec4(viewPos, 1.0);
    vec3 rayStart = (rayStartClip.xyz / rayStartClip.w) * 0.5 + 0.5;
    
    // Project end position
    float rayLength = WATER_SSR_MAX_DISTANCE;
    vec4 rayEndClip = gbufferProjection * vec4(viewPos + reflectDir * rayLength, 1.0);
    vec3 rayEnd = (rayEndClip.xyz / rayEndClip.w) * 0.5 + 0.5;
    
    vec3 rayDir = rayEnd - rayStart;
    
    // Clamp ray to screen bounds
    float tMax = 1.0;
    if (abs(rayDir.x) > 0.0001) {
        float t0 = -rayStart.x / rayDir.x;
        float t1 = (1.0 - rayStart.x) / rayDir.x;
        tMax = min(tMax, max(t0, t1));
    }
    if (abs(rayDir.y) > 0.0001) {
        float t0 = -rayStart.y / rayDir.y;
        float t1 = (1.0 - rayStart.y) / rayDir.y;
        tMax = min(tMax, max(t0, t1));
    }
    tMax = max(tMax, 0.0);
    
    int numSteps = SSR_STEPS;
    vec3 stepVec = rayDir * tMax / float(numSteps);
    
    // Dithered start
    float dither = bayer64(gl_FragCoord.xy);
    vec3 currentPos = rayStart + stepVec * (1.0 + dither);
    
    for (int i = 0; i < numSteps; i++) {
        if (currentPos.x < 0.0 || currentPos.x > 1.0 || 
            currentPos.y < 0.0 || currentPos.y > 1.0 ||
            currentPos.z < 0.0 || currentPos.z > 1.0) {
            return false;
        }
        
        float sceneDepth = getDepth(currentPos.xy);
        
        if (currentPos.z > sceneDepth && sceneDepth < 1.0) {
            float linearRay = SSR_linearizeDepth(currentPos.z);
            float linearScene = SSR_linearizeDepth(sceneDepth);
            float thickness = linearRay - linearScene;
            
            if (thickness > 0.0 && thickness < 2.0 + linearScene * 0.1) {
                // Binary search refinement
                vec3 refineStep = stepVec * 0.5;
                vec3 refinePos = currentPos - stepVec;
                
                for (int j = 0; j < 4; j++) {
                    float refineDepth = getDepth(refinePos.xy);
                    if (refinePos.z > refineDepth) {
                        refinePos -= refineStep;
                    } else {
                        refinePos += refineStep;
                    }
                    refineStep *= 0.5;
                }
                
                hitPos = refinePos.xy;
                
                // Edge fade
                vec2 edgeDist = abs(hitPos * 2.0 - 1.0);
                hitConfidence = 1.0 - max(edgeDist.x, edgeDist.y);
                hitConfidence = smoothstep(0.0, 0.2, hitConfidence);
                
                return true;
            }
        }
        
        currentPos += stepVec;
    }
    
    return false;
}

// Main reflection calculation for water surfaces
vec3 calculateWaterReflection(vec3 viewPos, vec3 normal, float sunAngle) {
    vec3 viewDir = normalize(viewPos);
    vec3 reflectDir = reflect(viewDir, normal);
    
    // Fresnel - Schlick approximation
    // Water has IOR ~1.33, F0 = ((1.33-1)/(1.33+1))^2 = 0.02
    float NdotV = max(dot(-viewDir, normal), 0.0);
    float F0 = 0.02;
    float fresnel = F0 + (1.0 - F0) * pow(1.0 - NdotV, WATER_FRESNEL_STRENGTH * 5.0);
    
    // Always start with sky reflection
    vec3 reflectionColor = getSkyFallback(reflectDir, sunAngle);
    
    // Try SSR for nearby geometry
    vec2 hitPos;
    float hitConfidence;
    if (raytraceSSR(viewPos, reflectDir, hitPos, hitConfidence)) {
        vec3 hitColor = texture(colortex0, hitPos).rgb;
        reflectionColor = mix(reflectionColor, hitColor, hitConfidence);
    }
    
    return reflectionColor * fresnel * WATER_SKY_REFLECTION;
}

#endif
