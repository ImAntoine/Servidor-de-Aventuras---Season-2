#ifndef SKY_FALLBACK_GLSL
#define SKY_FALLBACK_GLSL

// Procedural sky for reflection fallbacks
vec3 getSkyFallback(vec3 reflectDir, float sunAngle) {
    float angle = fract(sunAngle);
    
    // Time of day factors
    float dayFactor = smoothstep(0.02, 0.10, angle) * smoothstep(0.48, 0.40, angle);
    float twilightFactor = smoothstep(0.40, 0.46, angle) * smoothstep(0.58, 0.52, angle)
                         + smoothstep(0.94, 1.0, angle) + smoothstep(0.06, 0.0, angle);
    float nightFactor = smoothstep(0.58, 0.64, angle) * smoothstep(0.98, 0.92, angle);
    
    // Normalize factors
    float total = dayFactor + twilightFactor + nightFactor;
    if (total < 0.01) {
        dayFactor = 1.0;
        total = 1.0;
    }
    dayFactor /= total;
    twilightFactor /= total;
    nightFactor /= total;
    
    // Convert reflect direction from view space to world space
    vec3 worldReflect = normalize(mat3(gbufferModelViewInverse) * reflectDir);
    
    // Height-based gradient
    float height = clamp(worldReflect.y * 0.5 + 0.5, 0.0, 1.0);
    
    // Sky colors - brighter for visibility
    vec3 dayZenith = vec3(0.3, 0.5, 0.9);
    vec3 dayHorizon = vec3(0.6, 0.75, 0.95);
    
    vec3 sunsetZenith = vec3(0.15, 0.15, 0.35);
    vec3 sunsetHorizon = vec3(0.95, 0.55, 0.35);
    
    vec3 nightZenith = vec3(0.02, 0.03, 0.06);
    vec3 nightHorizon = vec3(0.05, 0.06, 0.12);
    
    // Blend layers based on height
    vec3 daySky = mix(dayHorizon, dayZenith, height);
    vec3 sunsetSky = mix(sunsetHorizon, sunsetZenith, height);
    vec3 nightSky = mix(nightHorizon, nightZenith, height);
    
    vec3 sky = daySky * dayFactor + sunsetSky * twilightFactor + nightSky * nightFactor;
    
    // Darken below horizon but not completely
    if (worldReflect.y < 0.0) {
        sky *= 0.5 + 0.5 * (1.0 + worldReflect.y);
    }
    
    // Sun/moon glow
    vec3 worldSunDir = normalize(mat3(gbufferModelViewInverse) * shadowLightPosition);
    float sunDot = dot(worldReflect, worldSunDir);
    
    // Sun glow
    float sunGlow = pow(max(sunDot, 0.0), 32.0);
    vec3 sunColor = mix(vec3(1.0, 0.95, 0.8), vec3(1.0, 0.6, 0.3), twilightFactor);
    sky += sunColor * sunGlow * (dayFactor + twilightFactor * 0.5) * 0.6;
    
    // Moon glow
    float moonGlow = pow(max(-sunDot, 0.0), 16.0);
    sky += vec3(0.4, 0.5, 0.7) * moonGlow * nightFactor * 0.3;
    
    return sky;
}

#endif
