// Forced vanilla-biome sky/fog overrides.
// Uses Iris biome IDs when available; each check is guarded for compatibility.

#ifndef INCLUDE_BIOME_OVERRIDES_GLSL
#define INCLUDE_BIOME_OVERRIDES_GLSL

bool isForcedDesertBiome(int b) {
    bool m = false;
    #ifdef BIOME_DESERT
    m = m || (b == BIOME_DESERT);
    #endif
    #ifdef BIOME_BADLANDS
    m = m || (b == BIOME_BADLANDS);
    #endif
    #ifdef BIOME_ERODED_BADLANDS
    m = m || (b == BIOME_ERODED_BADLANDS);
    #endif
    #ifdef BIOME_WOODED_BADLANDS
    m = m || (b == BIOME_WOODED_BADLANDS);
    #endif
    return m;
}

bool isForcedSwampyBiome(int b) {
    bool m = false;
    #ifdef BIOME_SWAMP
    m = m || (b == BIOME_SWAMP);
    #endif
    #ifdef BIOME_MANGROVE_SWAMP
    m = m || (b == BIOME_MANGROVE_SWAMP);
    #endif
    return m;
}

bool isForcedJungleBiome(int b) {
    bool m = false;
    #ifdef BIOME_JUNGLE
    m = m || (b == BIOME_JUNGLE);
    #endif
    #ifdef BIOME_BAMBOO_JUNGLE
    m = m || (b == BIOME_BAMBOO_JUNGLE);
    #endif
    #ifdef BIOME_SPARSE_JUNGLE
    m = m || (b == BIOME_SPARSE_JUNGLE);
    #endif
    return m;
}

bool isForcedSavannaBiome(int b) {
    bool m = false;
    #ifdef BIOME_SAVANNA
    m = m || (b == BIOME_SAVANNA);
    #endif
    #ifdef BIOME_SAVANNA_PLATEAU
    m = m || (b == BIOME_SAVANNA_PLATEAU);
    #endif
    #ifdef BIOME_WINDSWEPT_SAVANNA
    m = m || (b == BIOME_WINDSWEPT_SAVANNA);
    #endif
    return m;
}

bool isForcedSnowyBiome(int b) {
    bool m = false;
    #ifdef BIOME_SNOWY_PLAINS
    m = m || (b == BIOME_SNOWY_PLAINS);
    #endif
    #ifdef BIOME_SNOWY_TAIGA
    m = m || (b == BIOME_SNOWY_TAIGA);
    #endif
    #ifdef BIOME_SNOWY_BEACH
    m = m || (b == BIOME_SNOWY_BEACH);
    #endif
    #ifdef BIOME_SNOWY_SLOPES
    m = m || (b == BIOME_SNOWY_SLOPES);
    #endif
    #ifdef BIOME_FROZEN_RIVER
    m = m || (b == BIOME_FROZEN_RIVER);
    #endif
    #ifdef BIOME_FROZEN_OCEAN
    m = m || (b == BIOME_FROZEN_OCEAN);
    #endif
    #ifdef BIOME_FROZEN_PEAKS
    m = m || (b == BIOME_FROZEN_PEAKS);
    #endif
    #ifdef BIOME_ICE_SPIKES
    m = m || (b == BIOME_ICE_SPIKES);
    #endif
    #ifdef BIOME_GROVE
    m = m || (b == BIOME_GROVE);
    #endif
    return m;
}

bool isForcedNetherBiome(int b) {
    bool m = false;
    #ifdef BIOME_NETHER_WASTES
    m = m || (b == BIOME_NETHER_WASTES);
    #endif
    #ifdef BIOME_CRIMSON_FOREST
    m = m || (b == BIOME_CRIMSON_FOREST);
    #endif
    #ifdef BIOME_WARPED_FOREST
    m = m || (b == BIOME_WARPED_FOREST);
    #endif
    #ifdef BIOME_SOUL_SAND_VALLEY
    m = m || (b == BIOME_SOUL_SAND_VALLEY);
    #endif
    #ifdef BIOME_BASALT_DELTAS
    m = m || (b == BIOME_BASALT_DELTAS);
    #endif
    return m;
}

bool isForcedEndBiome(int b) {
    bool m = false;
    #ifdef BIOME_THE_END
    m = m || (b == BIOME_THE_END);
    #endif
    #ifdef BIOME_END_BARRENS
    m = m || (b == BIOME_END_BARRENS);
    #endif
    #ifdef BIOME_END_HIGHLANDS
    m = m || (b == BIOME_END_HIGHLANDS);
    #endif
    #ifdef BIOME_END_MIDLANDS
    m = m || (b == BIOME_END_MIDLANDS);
    #endif
    #ifdef BIOME_SMALL_END_ISLANDS
    m = m || (b == BIOME_SMALL_END_ISLANDS);
    #endif
    return m;
}

bool isCategoryDesert(int c) {
    // Iris BiomeCategories ordinals:
    // DESERT=12, MESA=4
    bool m = (c == 12) || (c == 4);
    #ifdef CAT_DESERT
    m = m || (c == CAT_DESERT);
    #endif
    #ifdef CAT_BADLANDS
    m = m || (c == CAT_BADLANDS);
    #endif
    return m;
}

bool isCategorySwampy(int c) {
    // Iris BiomeCategories ordinals: SWAMP=14
    bool m = (c == 14);
    #ifdef CAT_SWAMP
    m = m || (c == CAT_SWAMP);
    #endif
    return m;
}

bool isCategoryJungle(int c) {
    // Iris BiomeCategories ordinals: JUNGLE=3
    bool m = (c == 3);
    #ifdef CAT_JUNGLE
    m = m || (c == CAT_JUNGLE);
    #endif
    return m;
}

bool isCategorySnowy(int c) {
    // Iris BiomeCategories ordinals: ICY=7
    bool m = (c == 7);
    #ifdef CAT_ICY
    m = m || (c == CAT_ICY);
    #endif
    #ifdef CAT_SNOWY
    m = m || (c == CAT_SNOWY);
    #endif
    return m;
}

bool isCategorySavanna(int c) {
    // Iris BiomeCategories ordinals: SAVANNA=6
    bool m = (c == 6);
    #ifdef CAT_SAVANNA
    m = m || (c == CAT_SAVANNA);
    #endif
    return m;
}

vec3 getForcedBiomeFogColor(int biomeId, vec3 fallbackFog) {
    // End-specific fog color
    #ifdef END_FOG_ENABLED
    if (isForcedEndBiome(biomeId)) return vec3(END_FOG_R, END_FOG_G, END_FOG_B);
    #endif

    // Nether-specific fog overrides
    #ifdef BIOME_CRIMSON_FOREST
    if (biomeId == BIOME_CRIMSON_FOREST) return vec3(0.75, 0.12, 0.08); // red fog
    #endif
    #ifdef BIOME_BASALT_DELTAS
    if (biomeId == BIOME_BASALT_DELTAS) return vec3(0.38, 0.38, 0.40); // gray fog
    #endif
    #if defined(BIOME_WARPED_FOREST) || defined(BIOME_SOUL_SAND_VALLEY)
    #ifdef BIOME_WARPED_FOREST
    if (biomeId == BIOME_WARPED_FOREST) return vec3(0.09, 0.83, 1.00); // #17D4FF cyan fog
    #endif
    #ifdef BIOME_SOUL_SAND_VALLEY
    if (biomeId == BIOME_SOUL_SAND_VALLEY) return vec3(0.10, 0.72, 0.76); // cyan fog
    #endif
    #endif
    // Fallback for other nether biomes (e.g. nether wastes) — uses custom color
    if (isForcedNetherBiome(biomeId)) return fallbackFog;

    if (isForcedSnowyBiome(biomeId)) return vec3(0.85, 0.88, 0.92); // white fog
    if (isForcedDesertBiome(biomeId)) return vec3(235.0, 213.0, 185.0) / 255.0; // desert/savanna horizon fog
    if (isForcedSwampyBiome(biomeId)) return vec3(0.32, 0.42, 0.28); // muted olive-green haze
    if (isForcedJungleBiome(biomeId)) return vec3(0.36, 0.62, 0.28); // light green fog
    return fallbackFog;
}

vec3 getForcedBiomeSkyColor(int biomeId, vec3 fallbackSky) {
    #ifdef END_SKY_ENABLED
    if (isForcedEndBiome(biomeId)) return vec3(END_SKY_ZENITH_R, END_SKY_ZENITH_G, END_SKY_ZENITH_B);
    #endif
    if (isForcedSnowyBiome(biomeId)) return vec3(0.65, 0.78, 0.92); // washed out light blue sky
    if (isForcedDesertBiome(biomeId)) return vec3(191.0, 198.0, 255.0) / 255.0; // desert/savanna zenith
    if (isForcedSavannaBiome(biomeId)) return vec3(191.0, 198.0, 255.0) / 255.0; // desert/savanna zenith
    if (isForcedSwampyBiome(biomeId)) return vec3(0.45, 0.55, 0.42); // hazy warm green sky
    if (isForcedJungleBiome(biomeId)) return vec3(0.28, 0.56, 0.24); // green sky
    // Nether request was fog-only.
    return fallbackSky;
}

vec3 getForcedBiomeFogColorCat(int biomeId, int biomeCategory, vec3 fallbackFog) {
    // Fog follows biome horizon sky color.
    if (isForcedSnowyBiome(biomeId) || isCategorySnowy(biomeCategory)) return vec3(230.0, 241.0, 252.0) / 255.0;
    if (isForcedJungleBiome(biomeId) || isCategoryJungle(biomeCategory)) return vec3(81.0, 189.0, 92.0) / 255.0;
    if (isForcedSwampyBiome(biomeId) || isCategorySwampy(biomeCategory)) return vec3(66.0, 128.0, 75.0) / 255.0;
    if (isForcedSavannaBiome(biomeId) || isCategorySavanna(biomeCategory) || isForcedDesertBiome(biomeId) || isCategoryDesert(biomeCategory)) {
        // Savanna/Mesa/Desert share the updated palette horizon color.
        return vec3(235.0, 213.0, 185.0) / 255.0;
    }
    return fallbackFog;
}

vec3 getForcedBiomeSkyColorCat(int biomeId, int biomeCategory, vec3 fallbackSky) {
    // Backward-compatible single sky color (zenith).
    // Layered callers should use *Horizon/*Mid/*Zenith functions below.
    if (isForcedSnowyBiome(biomeId) || isCategorySnowy(biomeCategory)) return vec3(176.0, 191.0, 245.0) / 255.0;
    if (isForcedJungleBiome(biomeId) || isCategoryJungle(biomeCategory)) return vec3(122.0, 211.0, 255.0) / 255.0;
    if (isForcedSwampyBiome(biomeId) || isCategorySwampy(biomeCategory)) return vec3(144.0, 199.0, 90.0) / 255.0;
    if (isForcedSavannaBiome(biomeId) || isCategorySavanna(biomeCategory) || isForcedDesertBiome(biomeId) || isCategoryDesert(biomeCategory)) {
        return vec3(191.0, 198.0, 255.0) / 255.0;
    }
    return fallbackSky;
}

vec3 getForcedBiomeSkyHorizonCat(int biomeId, int biomeCategory, vec3 fallbackHorizon) {
    if (isForcedSnowyBiome(biomeId) || isCategorySnowy(biomeCategory)) return vec3(230.0, 241.0, 252.0) / 255.0;
    if (isForcedJungleBiome(biomeId) || isCategoryJungle(biomeCategory)) return vec3(81.0, 189.0, 92.0) / 255.0;
    if (isForcedSwampyBiome(biomeId) || isCategorySwampy(biomeCategory)) return vec3(66.0, 128.0, 75.0) / 255.0;
    // Savanna/Mesa/Desert use the shared updated palette.
    if (isForcedSavannaBiome(biomeId) || isCategorySavanna(biomeCategory) || isForcedDesertBiome(biomeId) || isCategoryDesert(biomeCategory)) {
        return vec3(235.0, 213.0, 185.0) / 255.0;
    }
    return fallbackHorizon;
}

vec3 getForcedBiomeSkyMidCat(int biomeId, int biomeCategory, vec3 fallbackMid) {
    if (isForcedSnowyBiome(biomeId) || isCategorySnowy(biomeCategory)) return vec3(184.0, 202.0, 242.0) / 255.0;
    if (isForcedJungleBiome(biomeId) || isCategoryJungle(biomeCategory)) return vec3(154.0, 194.0, 110.0) / 255.0;
    // User-provided swamp values were malformed; using the valid first middle triplet.
    if (isForcedSwampyBiome(biomeId) || isCategorySwampy(biomeCategory)) return vec3(83.0, 77.0, 102.0) / 255.0;
    if (isForcedSavannaBiome(biomeId) || isCategorySavanna(biomeCategory) || isForcedDesertBiome(biomeId) || isCategoryDesert(biomeCategory)) {
        return vec3(214.0, 206.0, 224.0) / 255.0;
    }
    return fallbackMid;
}

vec3 getForcedBiomeSkyZenithCat(int biomeId, int biomeCategory, vec3 fallbackZenith) {
    if (isForcedSnowyBiome(biomeId) || isCategorySnowy(biomeCategory)) return vec3(176.0, 191.0, 245.0) / 255.0;
    if (isForcedJungleBiome(biomeId) || isCategoryJungle(biomeCategory)) return vec3(122.0, 211.0, 255.0) / 255.0;
    if (isForcedSwampyBiome(biomeId) || isCategorySwampy(biomeCategory)) return vec3(144.0, 199.0, 90.0) / 255.0;
    if (isForcedSavannaBiome(biomeId) || isCategorySavanna(biomeCategory) || isForcedDesertBiome(biomeId) || isCategoryDesert(biomeCategory)) {
        return vec3(191.0, 198.0, 255.0) / 255.0;
    }
    return fallbackZenith;
}

#endif // INCLUDE_BIOME_OVERRIDES_GLSL
