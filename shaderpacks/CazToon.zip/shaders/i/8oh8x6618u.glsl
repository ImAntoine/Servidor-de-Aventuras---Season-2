// ILV Water Reflections - Ported exactly from I Like Vanilla shader
#ifndef ILV_REFLECTIONS_GLSL
#define ILV_REFLECTIONS_GLSL

// ============================================================================
// Utility functions from ILV common.glsl
// ============================================================================

vec4 startMat(vec3 pos) {
    return vec4(pos.xyz, 1.0);
}

vec3 endMat(vec4 pos) {
    return pos.xyz / pos.w;
}

// Bayer dithering from ILV
float ilv_bayer2  (vec2 a) { a = 0.5 * floor(a); return fract(1.5 * fract(a.y) + a.x); }
float ilv_bayer4  (vec2 a) { return 0.25 * ilv_bayer2  (0.5 * a) + ilv_bayer2(a); }
float ilv_bayer8  (vec2 a) { return 0.25 * ilv_bayer4  (0.5 * a) + ilv_bayer2(a); }
float ilv_bayer16 (vec2 a) { return 0.25 * ilv_bayer8  (0.5 * a) + ilv_bayer2(a); }
float ilv_bayer32 (vec2 a) { return 0.25 * ilv_bayer16 (0.5 * a) + ilv_bayer2(a); }
float ilv_bayer64 (vec2 a) { return 0.25 * ilv_bayer32 (0.5 * a) + ilv_bayer2(a); }

// Pack/unpack from ILV
float ilv_pack_2x8(vec2 v) {
    return dot(floor(255.0 * v + 0.5), vec2(1.0 / 65535.0, 256.0 / 65535.0));
}
float ilv_pack_2x8(float x, float y) { return ilv_pack_2x8(vec2(x, y)); }

vec2 ilv_unpack_2x8(float pack) {
    vec2 xy; xy.x = modf((65535.0 / 256.0) * pack, xy.y);
    return xy * vec2(256.0 / 255.0, 1.0 / 255.0);
}

// Octahedral normal encoding/decoding from ILV
vec2 ilv_encodeNormal(vec3 v) {
    v /= abs(v.x) + abs(v.y) + abs(v.z);
    v.xy = (v.z >= 0.0) ? v.xy : (1.0 - abs(v.yx)) * (vec2(v.x >= 0.0, v.y >= 0.0) * 2.0 - 1.0);
    return v.xy * 0.5 + 0.5;
}

vec3 ilv_decodeNormal(vec2 v) {
    vec2 f = v * 2.0 - 1.0;
    vec3 n = vec3(f, 1.0 - abs(f.x) - abs(f.y));
    float t = max(-n.z, 0.0);
    n.xy += vec2(n.x >= 0.0 ? -t : t, n.y >= 0.0 ? -t : t);
    return normalize(n);
}

// Screen to view conversion from ILV
vec3 ilv_screenToView(vec3 pos) {
    vec4 iProjDiag = vec4(
        gbufferProjectionInverse[0].x,
        gbufferProjectionInverse[1].y,
        gbufferProjectionInverse[2].zw
    );
    vec3 p3 = pos * 2.0 - 1.0;
    vec4 viewPos = iProjDiag * p3.xyzz + gbufferProjectionInverse[3];
    return viewPos.xyz / viewPos.w;
}

// ============================================================================
// Sky color for reflections - ILV style (view-space)
// ============================================================================

// rainStrength — declared here only if the including file hasn't declared it already
#ifndef RAIN_STRENGTH_DECLARED
#define RAIN_STRENGTH_DECLARED
uniform float rainStrength;
#endif

vec3 ilv_getSkyColor(vec3 viewDir) {
    #ifdef END_SHADER
    vec3 worldDir = normalize(mat3(gbufferModelViewInverse) * viewDir);
    float height = max(worldDir.y, 0.0);
    
    vec3 horizonColor = vec3(END_SKY_HORIZON_R, END_SKY_HORIZON_G, END_SKY_HORIZON_B);
    vec3 midColor = vec3(END_SKY_MID_R, END_SKY_MID_G, END_SKY_MID_B);
    vec3 zenithColor = vec3(END_SKY_ZENITH_R, END_SKY_ZENITH_G, END_SKY_ZENITH_B);

    float midSmooth = smoothstep(0.25, 0.65, height);
    vec3 sky = mix(mix(horizonColor, midColor, smoothstep(0.0, 0.25, height)), zenithColor, midSmooth);
    
    if (worldDir.y < 0.0) {
        float belowFade = smoothstep(0.0, -0.4, worldDir.y);
        #ifdef END_FOG_ENABLED
        vec3 voidColor = vec3(END_FOG_R, END_FOG_G, END_FOG_B);
        #else
        vec3 voidColor = horizonColor * 0.3;
        #endif
        sky = mix(horizonColor, voidColor, belowFade);
    }
    
    return sky * END_SKY_BRIGHTNESS * 0.5; // Dimmer for reflections
    #else
    // Time of day calculation
    float angle = fract(sunAngle);
    float dayPercent = smoothstep(0.02, 0.10, angle) * smoothstep(0.48, 0.40, angle);
    float sunriseSunsetPercent = smoothstep(0.40, 0.46, angle) * smoothstep(0.58, 0.52, angle)
                               + smoothstep(0.94, 1.0, angle) + smoothstep(0.06, 0.0, angle);

    // Sky colors
    vec3 DAY_COLOR = vec3(0.4, 0.65, 1.0);
    vec3 NIGHT_COLOR = vec3(0.01, 0.012, 0.025);
    vec3 HORIZON_DAY_COLOR = vec3(0.7, 0.85, 1.0);
    vec3 HORIZON_NIGHT_COLOR = vec3(0.02, 0.025, 0.05);
    vec3 HORIZON_SUNRISE_COLOR = vec3(1.0, 0.6, 0.35);
    vec3 HORIZON_SUNSET_COLOR = vec3(1.0, 0.5, 0.3);

    // ILV uses gbufferModelView[1].xyz for up direction in view space
    float upDot = dot(viewDir, gbufferModelView[1].xyz);
    vec3 skCol = mix(NIGHT_COLOR, DAY_COLOR, dayPercent);

    // For below-horizon rays (upDot < 0): smoothly darken toward ground color
    // instead of hard-clamping to horizon, which creates a visible line on water.
    float belowHorizon = max(-upDot, 0.0);
    float groundFade = smoothstep(0.0, 0.15, belowHorizon); // fade in below horizon
    float upDotClamped = max(upDot, 0.0);

    vec3 horizonColor = mix(HORIZON_NIGHT_COLOR, HORIZON_DAY_COLOR, dayPercent);

    float horizonAmount = 1.0 - upDotClamped;
    horizonAmount *= horizonAmount;
    horizonAmount *= horizonAmount;
    horizonAmount = 1.0 - horizonAmount;
    skCol = mix(horizonColor, skCol, horizonAmount);

    // Below-horizon: blend toward a dark ground/water color
    vec3 groundColor = mix(HORIZON_NIGHT_COLOR, HORIZON_DAY_COLOR, dayPercent) * 0.15;
    skCol = mix(skCol, groundColor, groundFade);

    // Sun/sunset color - shadowLightPosition is already in view space
    float sunDot = dot(viewDir, normalize(shadowLightPosition)) * 0.5 + 0.5;
    sunDot = 1.0 - (1.0 - sunDot) * (1.0 - sunDot);
    sunDot *= 1.0 - upDotClamped;
    sunDot *= 1.0 - (1.0 - sunriseSunsetPercent) * (1.0 - sunriseSunsetPercent);
    skCol = mix(skCol, sunAngle > 0.25 && sunAngle < 0.75 ? HORIZON_SUNSET_COLOR : HORIZON_SUNRISE_COLOR, sunDot);

    // Apply brightness
    skCol = min(skCol, 1.0);
    skCol = 1.0 - (skCol - 1.0) * (skCol - 1.0);
    skCol *= 1.2;
    skCol *= 0.3 + 0.7 * dayPercent;

    // Sample volumetric clouds in reflection direction (lightweight version)
    // Use fixed Y=63 for ray origin so cloud reflections don't scale with camera height.
    // Keep camera XZ so the pattern stays spatially correct.
    // cloudRainFade matches composite8.fsh — clouds vanish from reflections as weather fog appears.
    float cloudRainFade = 1.0 - smoothstep(0.15, 0.70, rainStrength);
    float pxSkylight = texelFetch(colortex1, ivec2(gl_FragCoord.xy), 0).b;
    float cloudSkyGate = step(12.0 / 15.0, pxSkylight);
    #ifdef CLOUDS_3D_ENABLED
    {
        vec3 worldDir = normalize(mat3(gbufferModelViewInverse) * viewDir);
        // Only sample if looking upward (clouds are above)
        if (worldDir.y > 0.01) {
            float gameTimeSec = (float(worldDay) * 24000.0 + float(worldTime)) / 20.0;
            vec3 sunDirWorld = normalize(mat3(gbufferModelViewInverse) * shadowLightPosition);
            vec3 reflOrigin = vec3(cameraPosition.x, 63.0, cameraPosition.z);
            vec4 cloudResult = renderCloudReflection(worldDir, gameTimeSec, reflOrigin, sunAngle, sunDirWorld, gl_FragCoord.xy, frameCounter);
            cloudResult.a *= cloudRainFade * cloudSkyGate;
            if (cloudResult.a > 0.001) {
                skCol = mix(skCol, cloudResult.rgb, cloudResult.a);
            }
        }
    }
    #endif

    // Sample vanilla clouds in reflection direction
    #ifdef CLOUDS_VANILLA_ENABLED
    {
        vec3 worldDir = normalize(mat3(gbufferModelViewInverse) * viewDir);
        if (worldDir.y > 0.01) {
            float gameTimeSec = (float(worldDay) * 24000.0 + float(worldTime)) / 20.0;
            vec3 sunDirWorld = normalize(mat3(gbufferModelViewInverse) * shadowLightPosition);
            vec3 reflOrigin = vec3(cameraPosition.x, 63.0, cameraPosition.z);
            float vanHitT = 0.0;
            vec4 vanResult = renderVanillaClouds(worldDir, gameTimeSec, reflOrigin, sunAngle, sunDirWorld, 30000.0, gl_FragCoord.xy, frameCounter, vanHitT);
            vanResult.a *= cloudRainFade * cloudSkyGate;
            if (vanResult.a > 0.001) {
                skCol = mix(skCol, vanResult.rgb, vanResult.a);
            }
        }
    }
    #endif

    return skCol;
    #endif
}

// ============================================================================
// Raytrace function - EXACT copy from ILV lib/reflections.glsl
// ============================================================================

void ilv_raytrace(out vec2 reflectionPos, out int error, vec3 viewPos, vec3 reflectionDir, vec3 normal) {
    
    // basic setup
    vec3 screenPos = endMat(gbufferProjection * startMat(viewPos)) * 0.5 + 0.5;
    vec3 nextScreenPos = endMat(gbufferProjection * startMat(viewPos + reflectionDir * sqrt(length(viewPos)) / 4.0)) * 0.5 + 0.5;
    
    // calculate the optimal stepVector that will stop at the screen edge
    vec3 stepVector = nextScreenPos - screenPos;
    stepVector /= length(stepVector.xy);
    if (abs(stepVector.x) > 0.0001) {
        float clampedStepX = clamp(stepVector.x, -screenPos.x, 1.0 - screenPos.x);
        stepVector.yz *= clampedStepX / stepVector.x;
        stepVector.x = clampedStepX;
    }
    if (abs(stepVector.y) > 0.0001) {
        float clampedStepY = clamp(stepVector.y, -screenPos.y, 1.0 - screenPos.y);
        stepVector.xz *= clampedStepY / stepVector.y;
        stepVector.y = clampedStepY;
    }
    stepVector /= (REFLECTION_ITERATIONS - 8); // ensure that the ray will reach the edge of the screen 8 steps early, allows for fine-tuning to not be cut short
    
    float dither = ilv_bayer64(gl_FragCoord.xy);
    dither = fract(dither + 1.61803398875 * mod(float(frameCounter), 3600.0));
    screenPos += stepVector * dither * REFLECTION_DITHER_AMOUNT;
    
    int hitCount = 0;
    for (int i = 0; i < REFLECTION_ITERATIONS; i++) {
        // If the ray passes through entity/display pixels, stop and treat as blocker.
        ivec2 stepTexel = ivec2(clamp(screenPos.xy, vec2(0.0), vec2(0.999999)) * vec2(viewWidth, viewHeight));
        float stepMarker = texelFetch(colortex1, stepTexel, 0).a;
        if (stepMarker > 0.001 && stepMarker < 0.999) {
            reflectionPos = screenPos.xy;
            error = 2;
            return;
        }
        
        float realDepth = min(texture(depthtex2, screenPos.xy).r, texture(depthtex0, screenPos.xy).r);
        float realToScreen = screenPos.z - realDepth;
        
        if (realToScreen > 0.0 && realToScreen < sqrt(stepVector.z) * 0.5) {
            hitCount ++;
            if (hitCount >= 5) { // converged on point
                reflectionPos = screenPos.xy;
                error = 0;
                return;
            }
            screenPos -= stepVector;
            stepVector *= 0.5;
        } else {
            screenPos += stepVector;
        }
    }
    
    error = 1;
}

// ============================================================================
// Add reflection - EXACT copy from ILV lib/reflections.glsl
// ============================================================================

void ilv_addReflection(inout vec3 color, vec3 viewPos, vec3 normal, vec2 lmcoord, float reflectionStrength) {
    
    vec3 reflectionDirection = reflect(normalize(viewPos), normalize(normal));
    vec2 reflectionPos;
    int error;
    ilv_raytrace(reflectionPos, error, viewPos, reflectionDirection, normal);
    
    float fresnel = 1.0 - abs(dot(normalize(viewPos), normal));
    fresnel *= fresnel;
    fresnel *= fresnel;
    
    // Apply reflection fade brightness control
    float fresnelMod = mix(0.3, 1.0, fresnel) * WATER_REFLECTION_FADE;
    fresnelMod = clamp(fresnelMod, 0.0, 1.0);
    reflectionStrength *= fresnelMod;
    
    vec3 skyColor = ilv_getSkyColor(reflectionDirection);
    
    // Make sky reflection brighter
    skyColor *= 1.5;
    
    if (isEyeInWater == 1) {
        skyColor = 0.08 + 0.125 * skyColor;
        skyColor += vec3(0.0, 0.03, 0.3);
    }
    
    const float inputColorWeight = 0.2;
    
    vec3 reflectionColor;
    if (error == 2) {
        reflectionColor = color;
    } else if (error == 0) {
        float hitMarker = texture(colortex1, reflectionPos).a;
        bool hitEntityLike = (hitMarker > 0.001 && hitMarker < 0.999);
        // Check if SSR hit landed on sky (depth == 1.0)
        // If so, use sky+cloud color since colortex0 doesn't include clouds yet
        float hitDepth = min(texture(depthtex2, reflectionPos).r, texture(depthtex0, reflectionPos).r);
        if (hitEntityLike) {
            // Translucent/display entities can be missing in this color buffer;
            // treat as blocker so reflections do not leak through to background.
            reflectionColor = color;
        } else if (hitDepth > 0.9999) {
            reflectionColor = skyColor; // Sky with clouds already included
        } else {
            reflectionColor = texture(colortex0, reflectionPos).rgb;
        }
        // Simple edge fade - blend to sky near screen edges
        float edgeDist = max(abs(reflectionPos.x * 2.0 - 1.0), abs(reflectionPos.y * 2.0 - 1.0));
        float edgeFade = 1.0 - smoothstep(0.7, 1.0, edgeDist);
        reflectionColor = mix(skyColor, reflectionColor, edgeFade);
    } else {
        reflectionColor = skyColor;
    }
    reflectionColor *= (1.0 - inputColorWeight) + color * inputColorWeight;
    color = mix(color, reflectionColor, reflectionStrength);
    
}

// Material reflection — SSR with sky/environment fallback
void ilv_addMaterialReflection(inout vec3 color, vec3 viewPos, vec3 normal, float reflectionStrength) {
    vec3 reflectionDirection = reflect(normalize(viewPos), normalize(normal));
    vec2 reflectionPos;
    int error;
    ilv_raytrace(reflectionPos, error, viewPos, reflectionDirection, normal);

    // Sky/environment color as fallback when SSR fails or hits sky
    vec3 skyColor = ilv_getSkyColor(reflectionDirection) * 0.8;

    if (error == 2) {
        color = mix(color, color, reflectionStrength);
    } else if (error == 0) {
        float hitMarker = texture(colortex1, reflectionPos).a;
        bool hitEntityLike = (hitMarker > 0.001 && hitMarker < 0.999);
        float hitDepth = min(texture(depthtex2, reflectionPos).r, texture(depthtex0, reflectionPos).r);
        if (hitEntityLike) {
            // Block reflection on display/translucent entity hits to avoid
            // showing geometry behind them in SSR.
            color = mix(color, color, reflectionStrength);
        } else if (hitDepth < 0.9999) {
            vec3 reflectionColor = texture(colortex0, reflectionPos).rgb;

            // Edge fade near screen borders — blend to sky fallback
            float edgeDist = max(abs(reflectionPos.x * 2.0 - 1.0), abs(reflectionPos.y * 2.0 - 1.0));
            float edgeFade = 1.0 - smoothstep(0.6, 0.95, edgeDist);

            vec3 blended = mix(skyColor, reflectionColor, edgeFade);
            color = mix(color, blended, reflectionStrength);
        } else {
            // SSR hit sky — use sky fallback at reduced strength
            color = mix(color, skyColor, reflectionStrength * 0.5);
        }
    } else {
        // SSR missed — use sky/environment fallback at reduced strength
        color = mix(color, skyColor, reflectionStrength * 0.4);
    }
}

#endif
