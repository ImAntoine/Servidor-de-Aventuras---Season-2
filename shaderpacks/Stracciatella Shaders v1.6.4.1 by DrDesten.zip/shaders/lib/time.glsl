#if ! defined INCLUDE_TIME_GLSL_D7F0
#define INCLUDE_TIME_GLSL_D7F0

#if TIME_MODE == 1
#if ! defined INCLUDE_UNIFORM_int_worldTime
#define INCLUDE_UNIFORM_int_worldTime
uniform int worldTime; 
#endif

#if ! defined INCLUDE_UNIFORM_int_worldDay
#define INCLUDE_UNIFORM_int_worldDay
uniform int worldDay; 
#endif
int worldTimeTotal = (worldDay & 255) * 24000 + worldTime;
float time = worldTimeTotal * (1./24.);

#elif TIME_MODE == 2
#if ! defined INCLUDE_UNIFORM_int_frameCounter
#define INCLUDE_UNIFORM_int_frameCounter
uniform int frameCounter; 
#endif
float time = frameCounter / float(TIME_MODE_FRAME_RATE);

#else
#if ! defined INCLUDE_UNIFORM_float_frameTimeCounter
#define INCLUDE_UNIFORM_float_frameTimeCounter
uniform float frameTimeCounter; 
#endif
float time = frameTimeCounter;

#endif

#endif