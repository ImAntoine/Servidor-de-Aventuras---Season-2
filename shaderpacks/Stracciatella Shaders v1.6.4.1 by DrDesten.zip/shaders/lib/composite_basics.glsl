#if ! defined INCLUDE_COMPOSITE_BASICS_GLSL_CC2F
#define INCLUDE_COMPOSITE_BASICS_GLSL_CC2F
#if ! defined INCLUDE_UNIFORM_sampler2D_colortex0
#define INCLUDE_UNIFORM_sampler2D_colortex0
uniform sampler2D colortex0; // Color
#endif

#if ! defined INCLUDE_UNIFORM_sampler2D_depthtex0
#define INCLUDE_UNIFORM_sampler2D_depthtex0
uniform sampler2D depthtex0; // Depth
#endif

#if ! defined INCLUDE_UNIFORM_vec2_screenSize
#define INCLUDE_UNIFORM_vec2_screenSize
uniform vec2 screenSize; 
#endif

#if ! defined INCLUDE_UNIFORM_vec2_screenSizeInverse
#define INCLUDE_UNIFORM_vec2_screenSizeInverse
uniform vec2 screenSizeInverse; 
#endif
vec3 getAlbedo(vec2 coord) {
    return texture(colortex0, coord).rgb;
}

float getDepth(vec2 coord) {
    return texture(depthtex0, coord).x;
}

#endif