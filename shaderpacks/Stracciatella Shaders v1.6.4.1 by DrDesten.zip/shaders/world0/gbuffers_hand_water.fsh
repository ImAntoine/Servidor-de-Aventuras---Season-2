#version 150 compatibility
#extension GL_ARB_explicit_attrib_location : enable
#define HAND_WATER
#define FRAG
#define OVERWORLD
#include "/gbuffers_hand.fsh"
