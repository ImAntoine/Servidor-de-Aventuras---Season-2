#version 150 compatibility
#extension GL_ARB_explicit_attrib_location : enable
#define CUTOUT
#define VERT
#define OVERWORLD
#include "/gbuffers_terrain.vsh"
