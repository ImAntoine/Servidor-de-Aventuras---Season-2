#if ! defined INCLUDE_GBUFFERS_BASIC_VSH_6FCF
#define INCLUDE_GBUFFERS_BASIC_VSH_6FCF

#include "/lib/settings.glsl"
#include "/core/math.glsl"
#include "/lib/utils.glsl"
#include "/lib/vertex_transform_simple.glsl"

out vec2 lmcoord;
flat out vec4 glcolor;

void main() {
	gl_Position = getPosition();
	lmcoord     = getLmCoord();
	glcolor     = gl_Color;
}

#endif