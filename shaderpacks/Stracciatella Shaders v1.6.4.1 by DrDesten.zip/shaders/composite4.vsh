#if ! defined INCLUDE_COMPOSITE4_VSH_02FB
#define INCLUDE_COMPOSITE4_VSH_02FB

#include "/lib/settings.glsl"
#include "/lib/vertex_transform_composite.glsl"

#if defined COLORED_LIGHTS_TEXTURE_SIZE_COMPATIBILTY

out vec2 coord;

void main() {
	gl_Position = getPosition();
	coord       = gl_Vertex.xy;
}
#else

void main() {
	gl_Position = getPosition();
}

#endif 

#endif