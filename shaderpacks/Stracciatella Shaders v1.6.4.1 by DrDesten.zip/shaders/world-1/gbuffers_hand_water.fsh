#version 150 compatibility
#extension GL_ARB_explicit_attrib_location : enable
#define HAND_WATER
#define FRAG
#define NETHER
#include "/gbuffers_hand.fsh"
