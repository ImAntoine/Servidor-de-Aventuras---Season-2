#version 150 compatibility
#extension GL_ARB_explicit_attrib_location : enable
#define LIT
#define VERT
#define NETHER
#include "/gbuffers_textured.vsh"
