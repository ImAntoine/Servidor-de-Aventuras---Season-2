#version 150 compatibility
#extension GL_ARB_explicit_attrib_location : enable
#define FRAG
#define NETHER
#include "/composite3.fsh"
